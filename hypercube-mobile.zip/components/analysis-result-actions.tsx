import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { HC } from '@/constants/hypercube';
import { PrimaryButton, Panel } from '@/components/hypercube-ui';
import type { AnalysisFeedback } from '@/shared/ai';

export function AnalysisFeedbackPanel({ feedback, onFeedback }: { feedback: AnalysisFeedback | null; onFeedback: (value: AnalysisFeedback) => void }) {
  return <Panel style={styles.feedbackPanel}><Text style={styles.feedbackTitle}>Was this analysis useful?</Text><Text style={styles.feedbackBody}>Your response helps Hypercube tune the next review toward clearer evidence.</Text><View style={styles.feedbackRow}><FeedbackButton icon="thumbs-up-outline" label="Helpful" selected={feedback === 'helpful'} onPress={() => onFeedback('helpful')} /><FeedbackButton icon="help-circle-outline" label="Need more context" selected={feedback === 'needs_more_context'} onPress={() => onFeedback('needs_more_context')} /></View></Panel>;
}

function FeedbackButton({ icon, label, selected, onPress }: { icon: keyof typeof Ionicons.glyphMap; label: string; selected: boolean; onPress: () => void }) {
  return <Pressable accessibilityRole="button" accessibilityState={{ selected }} accessibilityLabel={label} onPress={onPress} style={[styles.feedbackButton, selected && styles.feedbackButtonActive]}><Ionicons name={icon} size={16} color={selected ? HC.white : HC.blue} /><Text style={[styles.feedbackText, selected && styles.feedbackTextActive]}>{label}</Text></Pressable>;
}

export function AnalysisActionFooter({ showRetry, exporting, onCreateCase, onRetry, onSave, onExport }: { showRetry: boolean; exporting: boolean; onCreateCase: () => void; onRetry: () => void; onSave: () => void; onExport: () => void }) {
  return <View style={styles.actions}><PrimaryButton label="Create case" icon="briefcase-outline" onPress={onCreateCase} />{showRetry ? <Pressable accessibilityRole="button" accessibilityLabel="Retry AI analysis" onPress={onRetry}><Text style={styles.secondaryAction}>Retry analysis</Text></Pressable> : null}<Pressable accessibilityRole="button" accessibilityLabel="Save AI analysis" onPress={onSave}><Text style={styles.secondaryAction}>Save analysis</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Export AI analysis" accessibilityState={{ disabled: exporting }} disabled={exporting} onPress={onExport}><Text style={styles.secondaryAction}>{exporting ? 'Preparing export…' : 'Export report'}</Text></Pressable></View>;
}

const styles = StyleSheet.create({
  feedbackPanel: { marginTop: 10, backgroundColor: '#F7FBFF' },
  feedbackTitle: { color: HC.text, fontSize: 14, fontWeight: '800' },
  feedbackBody: { color: HC.muted, fontSize: 12, lineHeight: 17, marginTop: 5 },
  feedbackRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  feedbackButton: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 16, borderWidth: 1, borderColor: '#DDE5F0', backgroundColor: HC.white },
  feedbackButtonActive: { backgroundColor: HC.navy, borderColor: HC.navy },
  feedbackText: { color: HC.blue, fontSize: 12, fontWeight: '800' },
  feedbackTextActive: { color: HC.white },
  actions: { marginTop: 22, gap: 16, alignItems: 'center' },
  secondaryAction: { color: HC.blue, fontSize: 14, fontWeight: '800' },
});
