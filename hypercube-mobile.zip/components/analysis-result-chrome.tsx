import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Eyebrow } from '@/components/hypercube-ui';
import { ScreenState } from '@/components/ui/screen-state';
import { HC } from '@/constants/hypercube';

export function AnalysisResultHeader({ onBack, onShare }: { onBack: () => void; onShare: () => void }) {
  return <View style={styles.header}><Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={onBack} hitSlop={10}><Ionicons name="chevron-back" size={24} color={HC.text} /></Pressable><View style={styles.headerCenter}><Eyebrow>Hypercube / Review console</Eyebrow><Text style={styles.title}>Scan result</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Share scan result" onPress={onShare} hitSlop={10}><Ionicons name="share-outline" size={21} color={HC.text} /></Pressable></View>;
}

export function AnalysisLoadingState() {
  return <ScreenState kind="loading" dark title="Reading product signals" description="Comparing visible details and provenance context." />;
}

export function AnalysisErrorPanel({ message, onRetry }: { message: string; onRetry: () => void }) {
  return <ScreenState kind="error" title="Review could not complete" description={message} actionLabel="Retry analysis" onAction={onRetry} />;
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 },
  headerCenter: { alignItems: 'center', gap: 4 },
  title: { color: HC.text, fontSize: 24, fontWeight: '900' },
  loadingHero: { minHeight: 230, alignItems: 'center', justifyContent: 'center', gap: 10 },
  loadingTitle: { color: HC.white, fontSize: 17, fontWeight: '800' },
  loadingSub: { color: 'rgba(255,255,255,0.68)', fontSize: 12, textAlign: 'center', lineHeight: 18, maxWidth: 250 },
  errorPanel: { marginTop: 10, backgroundColor: '#FFF8EA', borderColor: '#F5DFA5' },
  errorHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  errorTitle: { color: HC.text, fontSize: 14, fontWeight: '800' },
  errorBody: { color: HC.muted, fontSize: 12, lineHeight: 18, marginTop: 8 },
  retryButton: { alignSelf: 'flex-start', marginTop: 12, paddingHorizontal: 13, paddingVertical: 9, borderRadius: 14, backgroundColor: HC.navy },
  retryText: { color: HC.white, fontSize: 12, fontWeight: '800' },
  pressed: { opacity: 0.8, transform: [{ scale: 0.98 }] },
});
