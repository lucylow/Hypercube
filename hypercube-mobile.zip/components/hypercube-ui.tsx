import { Ionicons } from '@expo/vector-icons';
import { ReactNode } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { HC } from '@/constants/hypercube';

export function Eyebrow({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return <Text style={[styles.eyebrow, light && { color: 'rgba(255,255,255,0.58)' }]}>{children}</Text>;
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <View style={styles.rowBetween}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {action ? <Pressable onPress={onAction} hitSlop={8}><Text style={styles.actionText}>{action}</Text></Pressable> : null}
    </View>
  );
}

export function StatusPill({ label, tone = 'neutral' }: { label: string; tone?: 'success' | 'warning' | 'danger' | 'neutral' }) {
  const colors = { success: HC.success, warning: HC.warning, danger: HC.danger, neutral: HC.blue };
  return <View style={[styles.pill, { backgroundColor: `${colors[tone]}1A` }]}><View style={[styles.dot, { backgroundColor: colors[tone] }]} /><Text style={[styles.pillText, { color: colors[tone] }]}>{label}</Text></View>;
}

export function Panel({ children, dark = false, style }: { children: ReactNode; dark?: boolean; style?: object }) {
  return <View style={[styles.panel, dark && styles.darkPanel, style]}>{children}</View>;
}

export function PrimaryButton({ label, onPress, icon, disabled = false, accessibilityLabel }: { label: string; onPress: () => void; icon?: keyof typeof Ionicons.glyphMap; disabled?: boolean; accessibilityLabel?: string }) {
  return <Pressable accessibilityRole="button" accessibilityLabel={accessibilityLabel ?? label} accessibilityState={{ disabled }} disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.primaryButton, disabled && styles.disabledButton, pressed && !disabled && styles.pressed]}>
    {icon ? <Ionicons name={icon} size={19} color={HC.ink} /> : null}
    <Text style={styles.primaryText}>{label}</Text>
  </Pressable>;
}

export function IconButton({ name, onPress, color = HC.text, background = HC.paper }: { name: keyof typeof Ionicons.glyphMap; onPress: () => void; color?: string; background?: string }) {
  return <Pressable accessibilityRole="button" accessibilityLabel={name.replace('.', ' ')} onPress={onPress} style={({ pressed }) => [styles.iconButton, { backgroundColor: background }, pressed && styles.pressed]}><Ionicons name={name} size={20} color={color} /></Pressable>;
}

export function ScanOrb({ onPress }: { onPress: () => void }) {
  return <Pressable accessibilityRole="button" accessibilityLabel="Scan product" onPress={onPress} style={({ pressed }) => [styles.scanOrb, pressed && { transform: [{ scale: 0.96 }] }]}>
    <View style={styles.scanOrbInner}><Ionicons name="scan-outline" size={38} color={HC.ink} /></View>
    <Text style={styles.scanOrbLabel}>Scan product</Text>
  </Pressable>;
}

const styles = StyleSheet.create({
  eyebrow: { color: HC.muted, fontSize: 11, fontWeight: '800', letterSpacing: 1.2, textTransform: 'uppercase' },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { color: HC.text, fontSize: 18, fontWeight: '800' },
  actionText: { color: HC.blue, fontSize: 13, fontWeight: '700' },
  panel: { backgroundColor: HC.white, borderRadius: 22, borderWidth: 1, borderColor: HC.line, padding: 18 },
  darkPanel: { backgroundColor: HC.navy, borderColor: 'rgba(255,255,255,0.08)' },
  pill: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 6 },
  dot: { width: 6, height: 6, borderRadius: 3 },
  pillText: { fontSize: 12, fontWeight: '800' },
  primaryButton: { minHeight: 52, borderRadius: 16, paddingHorizontal: 18, backgroundColor: HC.cyan, flexDirection: 'row', gap: 9, alignItems: 'center', justifyContent: 'center' },
  primaryText: { color: HC.ink, fontSize: 15, fontWeight: '800' },
  disabledButton: { opacity: 0.58 },
  iconButton: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  pressed: { opacity: 0.86, transform: [{ scale: 0.98 }] },
  scanOrb: { width: 154, height: 154, borderRadius: 77, backgroundColor: 'rgba(66,232,208,0.16)', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(66,232,208,0.38)' },
  scanOrbInner: { width: 92, height: 92, borderRadius: 46, backgroundColor: HC.cyan, alignItems: 'center', justifyContent: 'center' },
  scanOrbLabel: { color: HC.cyan, marginTop: 10, fontSize: 13, fontWeight: '800' },
});
