import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Panel, StatusPill } from '@/components/hypercube-ui';
import { HC } from '@/constants/hypercube';
import { qualityTone, signalTone, type ResultTone } from '@/shared/analysis-result';
import type { AuthenticityAnalysis } from '@/shared/ai';

const toneColor: Record<ResultTone, string> = {
  success: HC.success,
  warning: HC.warning,
  danger: HC.danger,
  neutral: HC.blue,
};

export function SignalRow({ title, body, status }: { title: string; body: string; status: AuthenticityAnalysis['signals'][number]['status'] }) {
  const tone = signalTone(status);
  const color = toneColor[tone];
  const icon = tone === 'success' ? 'checkmark-circle-outline' : tone === 'danger' ? 'alert-circle-outline' : tone === 'warning' ? 'warning-outline' : 'information-circle-outline';
  return <Panel style={styles.signal}><View style={[styles.signalIcon, { backgroundColor: `${color}18` }]}><Ionicons name={icon} size={21} color={color} /></View><View style={styles.flex}><Text style={styles.signalTitle}>{title}</Text><Text style={styles.signalBody}>{body}</Text></View></Panel>;
}

export function EvidenceQualityPanels({ analysis }: { analysis: AuthenticityAnalysis }) {
  return <>
    <Panel style={styles.qualityPanel}><View style={styles.qualityHeader}><Text style={styles.actionLabel}>Evidence quality</Text><StatusPill label={analysis.evidenceQuality} tone={qualityTone(analysis.evidenceQuality)} /></View><Text style={styles.actionBody}>{analysis.evidenceQuality === 'strong' ? 'The available evidence supports a more confident comparison.' : analysis.evidenceQuality === 'moderate' ? 'The result is useful, but additional reference evidence could change the confidence.' : 'Confidence is intentionally capped because the evidence set is incomplete.'}</Text></Panel>
    <Panel style={styles.photoQualityPanel}><View style={styles.qualityHeader}><Text style={styles.actionLabel}>Photo quality</Text><StatusPill label={analysis.photoQuality.grade} tone={qualityTone(analysis.photoQuality.grade)} /></View><Text style={styles.actionBody}>{analysis.photoQuality.usableForAnalysis ? 'The photo can be used for analysis, but review the capture notes below.' : 'The photo is not reliable enough for a final visual judgment.'}</Text>{analysis.photoQuality.visualChecks && <View style={styles.checkGrid}>{Object.entries(analysis.photoQuality.visualChecks).map(([key, value]) => <View key={key} style={styles.checkCell}><Text style={styles.checkLabel}>{key.replace(/([A-Z])/g, ' $1')}</Text><Text style={styles.checkValue}>{value}</Text></View>)}</View>}{analysis.photoQuality.issues.map((issue, index) => <Text key={`photo-issue-${index}`} style={styles.detailText}>• {issue}</Text>)}</Panel>
    {analysis.crossPhotoConsistency && <Panel style={styles.consistencyPanel}><View style={styles.qualityHeader}><Text style={styles.actionLabel}>Cross-photo consistency</Text><StatusPill label={analysis.crossPhotoConsistency.status} tone={analysis.crossPhotoConsistency.status === 'consistent' ? 'success' : analysis.crossPhotoConsistency.status === 'mixed' ? 'warning' : 'neutral'} /></View>{analysis.crossPhotoConsistency.issues.map((issue, index) => <Text key={`consistency-${index}`} style={styles.detailText}>• {issue}</Text>)}</Panel>}
    {analysis.referenceComparison && <Panel style={styles.referencePanel}><View style={styles.qualityHeader}><Text style={styles.actionLabel}>Reference comparison</Text><StatusPill label={analysis.referenceComparison.status} tone={analysis.referenceComparison.status === 'matched' ? 'success' : analysis.referenceComparison.status === 'mismatch' ? 'warning' : 'neutral'} /></View>{analysis.referenceComparison.issues.map((issue, index) => <Text key={`reference-${index}`} style={styles.detailText}>• {issue}</Text>)}</Panel>}
    {analysis.reviewMetadata && <Panel style={styles.reviewTrailPanel}><View style={styles.qualityHeader}><Text style={styles.actionLabel}>Review trail</Text><Text style={styles.reviewTrailCount}>{analysis.reviewMetadata.reviewedIndexes.length}/{analysis.reviewMetadata.imageCount} checked</Text></View><Text style={styles.detailText}>The evidence set was reviewed before AI comparison. Actions recorded: {analysis.reviewMetadata.actions.length ? analysis.reviewMetadata.actions.join(', ') : 'none'}.</Text>{analysis.provenanceHash && <Text style={styles.provenanceText}>Input provenance SHA-256: {analysis.provenanceHash}</Text>}</Panel>}
    <Panel style={styles.detailsPanel}><Text style={styles.actionLabel}>Observed details</Text>{analysis.observedDetails.map((item, index) => <Text key={`observed-${index}`} style={styles.detailText}>• {item}</Text>)}<Text style={[styles.actionLabel, { marginTop: 14 }]}>Best next evidence</Text>{analysis.missingEvidence.map((item, index) => <Text key={`missing-${index}`} style={styles.detailText}>• {item}</Text>)}</Panel>
  </>;
}

export function NextEvidencePanel({ analysis, onCapture }: { analysis: AuthenticityAnalysis; onCapture: () => void }) {
  return <Panel style={styles.nextActionPanel}><View style={styles.nextActionHeader}><View style={styles.nextActionIcon}><Ionicons name="camera-outline" size={19} color={HC.blue} /></View><View style={styles.flex}><Text style={styles.actionLabel}>Next best evidence</Text><Text style={styles.nextActionTitle}>{analysis.nextBestAction.title}</Text></View></View><Text style={styles.nextActionBody}>{analysis.nextBestAction.rationale}</Text><Text style={styles.nextActionType}>Capture type · {analysis.nextBestAction.evidenceType}</Text><Pressable accessibilityRole="button" accessibilityLabel={`Capture next evidence: ${analysis.nextBestAction.title}`} onPress={onCapture} style={({ pressed }) => [styles.captureAction, pressed && styles.pressed]}><Ionicons name="scan-outline" size={16} color={HC.white} /><Text style={styles.captureActionText}>Capture next evidence</Text></Pressable></Panel>;
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  pressed: { opacity: 0.8, transform: [{ scale: 0.98 }] },
  signal: { flexDirection: 'row', gap: 12, alignItems: 'center', paddingVertical: 14 },
  signalIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  signalTitle: { color: HC.text, fontSize: 14, fontWeight: '800' },
  signalBody: { color: HC.muted, fontSize: 12, lineHeight: 17, marginTop: 4 },
  qualityPanel: { marginTop: 12, backgroundColor: '#F7FBFF' },
  photoQualityPanel: { marginTop: 10, backgroundColor: '#FFF9EC', borderColor: '#F5DFA5' },
  consistencyPanel: { marginTop: 10, backgroundColor: '#F7FBFF', borderColor: '#CBE4FA' },
  referencePanel: { marginTop: 10, backgroundColor: '#FFF9EC', borderColor: '#F5DFA5' },
  reviewTrailPanel: { marginTop: 10, backgroundColor: '#F4F8F5', borderColor: '#CBE8D5' },
  reviewTrailCount: { color: HC.success, fontSize: 11, fontWeight: '800' },
  provenanceText: { color: HC.muted, fontSize: 10, lineHeight: 14, marginTop: 8 },
  qualityHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  actionLabel: { color: HC.blue, fontSize: 10, letterSpacing: 1, fontWeight: '800', textTransform: 'uppercase' },
  actionBody: { color: HC.text, fontSize: 14, lineHeight: 20, fontWeight: '700', marginTop: 6 },
  detailsPanel: { marginTop: 10 },
  detailText: { color: HC.muted, fontSize: 12, lineHeight: 18, marginTop: 6 },
  checkGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: 11 },
  checkCell: { width: '48%', borderRadius: 10, backgroundColor: '#FFFDF7', paddingHorizontal: 9, paddingVertical: 8 },
  checkLabel: { color: HC.muted, fontSize: 9, fontWeight: '800', textTransform: 'capitalize' },
  checkValue: { color: HC.text, fontSize: 11, fontWeight: '800', marginTop: 3, textTransform: 'capitalize' },
  nextActionPanel: { marginTop: 10, backgroundColor: '#EEF7FF', borderColor: '#CBE4FA' },
  nextActionHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  nextActionIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: '#DDF0FF', alignItems: 'center', justifyContent: 'center' },
  nextActionTitle: { color: HC.text, fontSize: 15, lineHeight: 19, fontWeight: '800', marginTop: 4 },
  nextActionBody: { color: HC.muted, fontSize: 12, lineHeight: 18, marginTop: 10 },
  nextActionType: { color: HC.blue, fontSize: 11, fontWeight: '800', marginTop: 9 },
  captureAction: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: HC.navy, paddingHorizontal: 13, paddingVertical: 10, borderRadius: 15, marginTop: 13 },
  captureActionText: { color: HC.white, fontSize: 12, fontWeight: '800' },
});
