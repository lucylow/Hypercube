import { Ionicons } from '@expo/vector-icons';
import { ActivityIndicator, Pressable, StyleSheet, Text } from 'react-native';
import { Panel } from '@/components/hypercube-ui';
import { HC } from '@/constants/hypercube';
import { UI } from '@/constants/ui';

type ScreenStateProps =
  | { kind: 'loading'; title: string; description?: string; dark?: boolean }
  | { kind: 'error'; title: string; description: string; actionLabel?: string; onAction?: () => void }
  | { kind: 'empty'; title: string; description?: string; icon?: keyof typeof Ionicons.glyphMap };

export function ScreenState(props: ScreenStateProps) {
  const { kind, title, description } = props;
  return <Panel dark={kind === 'loading' && 'dark' in props && props.dark} style={[styles.panel, kind === 'loading' && styles.loadingPanel, kind === 'error' && styles.errorPanel]}>
    {kind === 'loading' ? <ActivityIndicator accessibilityLabel="Loading" color={HC.cyan} size="large" /> : <Ionicons name={kind === 'error' ? 'warning-outline' : props.icon ?? 'file-tray-outline'} size={25} color={kind === 'error' ? HC.warning : HC.blue} />}
    <Text style={styles.title}>{title}</Text>
    {description ? <Text style={styles.description}>{description}</Text> : null}
    {kind === 'error' && props.onAction ? <Pressable accessibilityRole="button" accessibilityLabel={props.actionLabel ?? 'Retry'} onPress={props.onAction} style={({ pressed }) => [styles.action, pressed && styles.pressed]}><Text style={styles.actionText}>{props.actionLabel ?? 'Retry'}</Text></Pressable> : null}
  </Panel>;
}

const styles = StyleSheet.create({
  panel: { alignItems: 'center', justifyContent: 'center', gap: UI.spacing.sm, paddingVertical: UI.spacing.xxl, paddingHorizontal: UI.spacing.xl },
  loadingPanel: { minHeight: 230 },
  errorPanel: { marginTop: UI.spacing.md, backgroundColor: '#FFF8EA', borderColor: '#F5DFA5' },
  title: { color: HC.text, fontSize: 16, lineHeight: 21, fontWeight: '800', textAlign: 'center' },
  description: { color: HC.muted, fontSize: 12, lineHeight: 18, textAlign: 'center', maxWidth: 280 },
  action: { marginTop: UI.spacing.xs, borderRadius: UI.radius.md, backgroundColor: HC.navy, paddingHorizontal: UI.spacing.md, paddingVertical: UI.spacing.sm },
  actionText: { color: HC.white, fontSize: 12, fontWeight: '800' },
  pressed: { opacity: 0.8, transform: [{ scale: 0.98 }] },
});
