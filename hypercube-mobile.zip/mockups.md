# Hypercube Mobile Mockups

The visual set is designed as twenty standalone portrait screens for the first mobile product pass. Fifteen image mockups were generated during this build using the Hypercube icon, deep-ink/cyan/violet palette, and forensic mobile-intelligence direction. Five additional screens are fully specified below and can be generated when the image quota resets.

## Generated visual assets

| # | Screen | Asset URL |
|---:|---|---|
| 1 | Welcome / sign in | `/manus-storage/hypercube-mockup-01-welcome_7d7573fa.png` |
| 2 | Home dashboard | `/manus-storage/hypercube-mockup-02-home_6d8c6130.png` |
| 3 | Scan mode | `/manus-storage/hypercube-mockup-03-scan_3f65d625.png` |
| 4 | Camera permission | `/manus-storage/hypercube-mockup-04-permission_c2826aa0.png` |
| 5 | Guided capture | `/manus-storage/hypercube-mockup-05-guided-capture_a7f7a204.png` |
| 6 | Capture review | `/manus-storage/hypercube-mockup-06-review_0f54e083.png` |
| 7 | Analysis in progress | `/manus-storage/hypercube-mockup-07-progress_508af43c.png` |
| 8 | Low-risk result | `/manus-storage/hypercube-mockup-08-low-risk_c66f42b3.png` |
| 9 | High-risk result | `/manus-storage/hypercube-mockup-09-high-risk_32a1245e.png` |
| 10 | Result evidence | `/manus-storage/hypercube-mockup-10-evidence_f423c61e.png` |
| 11 | Product profile | `/manus-storage/hypercube-mockup-11-product_448141f8.png` |
| 12 | Cases list | `/manus-storage/hypercube-mockup-12-cases_ea78c3a4.png` |
| 13 | Case detail | `/manus-storage/hypercube-mockup-13-case-detail_8199f6ba.png` |
| 14 | Add evidence | `/manus-storage/hypercube-mockup-14-add-evidence_f26f5da4.png` |
| 15 | Incident map | `/manus-storage/hypercube-mockup-15-map_8e3477f7.png` |

## Remaining specified screens

The remaining five screens are incident detail, Library, Notifications, Account, and Subscription/usage. Their content and visual requirements are already defined in `design.md` and can be generated as a second batch without changing the design system.

The generated icon is available at `/manus-storage/hypercube-icon_b7936a7e.png` and is wired into the Expo configuration and local icon/splash assets.
