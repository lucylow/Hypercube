# Project TODO

- [x] Generate Hypercube app logo and copy it to all required Expo icon/splash locations
- [x] Update app.config.ts branding fields with the Hypercube display name and logo URL
- [ ] Create 20 mobile UI mockups for the agreed screen set
- [x] Apply Hypercube design tokens and iOS-style visual system
- [x] Add bottom navigation for Home, Scan, Cases, Map, and Account
- [x] Implement Home dashboard with scan CTA and recent activity
- [x] Implement Scan mode with QR/barcode and photo-capture entry points
- [ ] Implement guided capture and capture-review flows
- [x] Implement analysis-in-progress state with deterministic local demo data
- [x] Implement low-risk and high-risk authenticity result states
- [x] Implement result evidence detail screen
- [ ] Implement product profile screen
- [x] Implement Cases list with filters and status chips
- [x] Implement Case detail with evidence timeline and notes
- [x] Implement Add evidence flow
- [x] Implement Incident Map and incident detail states
- [ ] Implement Library search/history
- [ ] Implement Notifications screen
- [x] Implement Account, organization, and subscription/usage screens
- [ ] Add local state and persistence for demo scans/cases
- [x] Add deterministic unit tests for risk bands, case creation, and navigation data
- [x] Run TypeScript, lint, and test validation
- [x] Capture mobile preview screenshots and review responsive layout

- [x] Audit Expo SDK compatibility, route registration, and project configuration
- [x] Fix Expo Camera permission and web/native fallback behavior
- [x] Fix React Native runtime issues and unsafe event handlers
- [x] Improve route flows and remove dead-end interactions
- [x] Re-run TypeScript, lint, unit tests, and Expo configuration validation
- [ ] Save an improved Expo-compatible checkpoint

- [x] Audit remaining Expo runtime warnings and route edge cases
- [x] Improve camera lifecycle, scan reset, and accessibility behavior
- [x] Remove remaining dead-end or placeholder interactions
- [x] Revalidate Expo Doctor, lint, TypeScript, tests, and web export
- [ ] Save the next stable Expo checkpoint

- [x] Inspect latest Expo logs, dependency state, and route behavior
- [x] Improve remaining React Native interaction and platform fallbacks
- [x] Re-run Expo Doctor, lint, TypeScript, tests, and web export
- [ ] Save the updated Expo checkpoint

- [x] Audit current Expo logs, dependency state, and native/web edge cases
- [x] Improve the next highest-risk React Native interaction or platform fallback
- [x] Re-run Expo Doctor, lint, TypeScript, tests, and web export
- [ ] Save the latest stable Expo checkpoint

- [x] Audit latest Expo logs, dependencies, and remaining mobile interaction gaps
- [x] Implement the next targeted React Native/Expo improvement
- [x] Re-run lint, TypeScript, tests, Expo Doctor, and web export
- [ ] Save the newest stable Expo checkpoint

- [x] Audit latest Expo logs, dependencies, and remaining interaction gaps
- [x] Implement the next targeted Expo-compatible React Native improvement
- [x] Re-run lint, TypeScript, tests, Expo Doctor, and web export
- [ ] Save the latest Expo checkpoint

- [x] Audit latest Expo logs, dependencies, and remaining interaction gaps
- [x] Implement the next targeted Expo-compatible React Native improvement
- [x] Re-run lint, TypeScript, tests, Expo Doctor, and web export
- [ ] Save the latest Expo checkpoint

- [x] Audit latest Expo logs, dependencies, and remaining interaction gaps
- [x] Implement the next targeted Expo-compatible React Native improvement
- [x] Re-run lint, TypeScript, tests, Expo Doctor, and web export
- [ ] Save the latest Expo checkpoint

- [x] Audit latest Expo logs, dependencies, and remaining interaction gaps
- [x] Implement the next targeted Expo-compatible React Native improvement
- [x] Re-run lint, TypeScript, tests, Expo Doctor, and web export
- [ ] Save the latest Expo checkpoint

- [x] Define local evidence record, photo item, and sync-state types
- [x] Add local persistence for evidence notes, types, and photo URIs
- [x] Add local file copying for picked/captured evidence images
- [x] Create multi-photo evidence review route
- [x] Add retake, remove, and reorder controls
- [x] Add upload progress, retry, and pending-sync states
- [x] Add deterministic tests for evidence persistence and reorder behavior
- [x] Validate the workflow with Expo Doctor, lint, TypeScript, tests, and web export
- [ ] Save the local-first evidence checkpoint

- [x] Audit existing AI, tRPC, storage, and scan-result integration points
- [x] Define structured authenticity-analysis output and confidence rules
- [x] Add server-side multimodal analysis with safe fallback behavior
- [x] Add secure image upload/URL handling for AI vision inputs
- [x] Integrate AI loading, success, fallback, and error states in the Expo client
- [x] Render evidence-based signals and explanations in scan results
- [x] Add deterministic tests for AI response normalization and fallback results
- [x] Validate the AI workflow with lint, TypeScript, tests, Expo Doctor, and web export
- [ ] Save the AI feature checkpoint

- [x] Audit current AI result quality, fallback behavior, and scan-result UX
- [x] Add richer evidence fields and output quality gates
- [x] Add analyst feedback context to AI analysis
- [x] Improve AI explanation and uncertainty presentation in Expo
- [x] Add deterministic tests for AI quality gates and feedback normalization
- [x] Validate AI features with lint, TypeScript, tests, Expo Doctor, and web export
- [ ] Save the AI quality checkpoint

- [x] Audit the latest AI checkpoint and remaining review-quality gaps
- [x] Add the next evidence-grounded AI review and feedback improvement
- [x] Add resilient normalization and client fallback coverage
- [x] Validate AI features with lint, TypeScript, tests, Expo Doctor, and web export
- [x] Save the latest AI checkpoint

- [x] Audit the latest AI checkpoint and identify the next review-quality gap
- [x] Implement the next evidence-grounded AI workflow improvement
- [x] Add resilient normalization and client fallback coverage
- [x] Validate AI features with lint, TypeScript, tests, Expo Doctor, and web export
- [x] Save the latest AI checkpoint

- [x] Audit the current AI contract, prompt, and result UX
- [x] Implement the next AI quality and analyst-workflow improvement
- [x] Strengthen model output validation and evidence grounding
- [x] Validate the AI feature across tests and Expo compatibility checks
- [x] Save the AI improvement checkpoint

- [x] Audit the current AI output and investigator workflow
- [x] Implement actionable next-best-evidence guidance in the AI contract and UI
- [x] Add robust fallback guidance for unavailable model responses
- [x] Validate the new AI workflow across Expo checks and deterministic tests
- [x] Save the AI improvement checkpoint

- [x] Audit scan routing and current AI focus state
- [x] Implement focus-preserving guided re-capture and AI handoff
- [x] Add deterministic coverage for focus and follow-up parameters
- [x] Validate the follow-up AI workflow across Expo checks and tests
- [x] Save the AI improvement checkpoint

- [x] Audit the current focus-aware scan flow and evidence requirements
- [x] Implement a focus-specific guided capture checklist and handoff
- [x] Add deterministic coverage for guided capture requirements
- [x] Validate the guided AI evidence workflow across Expo checks and tests
- [x] Save the AI improvement checkpoint

- [x] Audit the current image handoff and evidence-capture paths
- [x] Implement Expo-safe photo quality assessment and user guidance
- [x] Add deterministic coverage for blur, glare, framing, and readability rules
- [x] Validate quality checks across deterministic tests and Expo compatibility
- [x] Save the AI improvement checkpoint

- [x] Audit the current mobile UI and identify the highest-impact UX gaps
- [x] Implement targeted UI/UX improvements in the core scan and result flows
- [x] Improve accessibility, hierarchy, and interaction feedback
- [x] Validate responsive layout and Expo compatibility
- [x] Save the UI/UX improvement checkpoint

- [x] Inspect current Expo, TypeScript, lint, and development-server errors
- [x] Reproduce and isolate the failing path
- [x] Apply a targeted fix and add regression coverage
- [x] Revalidate Expo, runtime, and core test behavior
- [x] Save the repaired checkpoint

- [x] Inspect fresh logs and reproduce remaining errors
- [x] Apply the smallest targeted repair with regression coverage
- [x] Run full Expo validation and confirm runtime health
- [x] Save the repaired checkpoint

- [x] Add scan-to-result smoke tests for native camera and web fallback paths
- [x] Improve AI result loading animations and error handling UX
- [x] Add save and device export for AI-generated results
- [x] Validate smoke tests, unit tests, Expo compatibility, and responsive rendering
- [x] Save the combined feature checkpoint

- [x] Audit recent code changes for maintainability and runtime risks
- [x] Implement targeted code-quality and resilience improvements
- [x] Add regression tests for extracted logic
- [x] Run complete Expo validation
- [x] Save the code-quality checkpoint

- [x] Audit the dense scan-result screen for reusable boundaries and state risks
- [x] Extract reusable AI result components and pure action helpers
- [x] Add regression coverage for extracted logic
- [x] Run complete Expo validation
- [x] Save the maintainability checkpoint

- [x] Audit remaining scan-result presentation and action boundaries
- [x] Extract reusable result panels and typed action helpers
- [x] Add regression coverage for extracted logic
- [x] Run complete Expo validation
- [x] Save the maintainability checkpoint

- [x] Audit remaining result-screen state preparation and action controls
- [x] Extract typed view-model helpers and reusable feedback/action components
- [x] Add regression coverage for extracted logic
- [x] Run complete Expo validation
- [x] Save the maintainability checkpoint

- [x] Audit remaining result-header and error-state duplication
- [x] Extract reusable header, loading, and retryable error components
- [x] Add regression coverage for extracted logic
- [x] Run complete Expo validation
- [x] Save the maintainability checkpoint

- [x] Audit duplicated styles and shared UI opportunities
- [x] Implement targeted reusable styling and component improvements
- [x] Add regression coverage for reusable UI behavior
- [x] Run complete Expo validation
- [x] Save the code-quality checkpoint

- [x] Audit shared styling and repeated loading/error/empty states
- [x] Implement shared tokens and reusable screen-state components
- [x] Add regression coverage for reusable UI behavior
- [x] Run complete Expo validation
- [x] Save the code-quality checkpoint

- [x] Audit the Cases and evidence flows for repeated state and spacing logic
- [x] Implement shared state and token usage in the selected flow
- [x] Add regression coverage for reusable UI behavior
- [x] Run complete Expo validation
- [x] Save the code-quality checkpoint

- [x] Audit Map and evidence-review state, spacing, and interaction patterns
- [x] Implement shared state, token, and accessibility improvements in both flows
- [x] Add regression coverage for reusable UI behavior
- [x] Run complete Expo validation
- [x] Save the code-quality checkpoint

- [x] Audit remaining status mappings and core-screen state patterns
- [x] Implement shared status helpers and core-screen primitive adoption
- [x] Add regression coverage for reusable UI behavior
- [x] Run complete Expo validation
- [x] Save the code-quality checkpoint

- [x] Audit case-detail and usage status presentation
- [x] Implement shared status labels and helper adoption
- [x] Add regression coverage for reusable status behavior
- [x] Run complete Expo validation
- [x] Save the code-quality checkpoint

- [x] Inspect fresh diagnostics and reproduce the reported errors
- [x] Apply targeted repairs and add regression coverage
- [x] Run full Expo validation and confirm runtime health
- [x] Save the repaired checkpoint

- [x] Audit incomplete product functionality and choose the highest-value workflow
- [x] Implement the selected workflow and connect its navigation and persistence
- [x] Add regression coverage for the new workflow
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit Library state, storage, and saved-review actions
- [x] Implement Library sorting and confirmed history deletion
- [x] Add regression coverage for the new Library management behavior
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current Library deletion flow and persistence boundaries
- [x] Implement undo recovery and bulk-select deletion
- [x] Add regression coverage for the new Library management behavior
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current selection-mode behavior and visible-record boundaries
- [x] Implement select-all-visible and clear-selection actions
- [x] Add regression coverage for the new Library selection behavior
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current export contracts and Library selection state
- [x] Implement filtered and selected review-set export
- [x] Add regression coverage for the new review-set export behavior
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit existing review-set export contracts and formatting
- [x] Implement CSV export for filtered and selected reviews
- [x] Add regression coverage for the new CSV export behavior
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current export state and persistence boundaries
- [x] Implement export history and retryable handoff status
- [x] Add regression coverage for the new export-history behavior
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit export-history persistence, routing, and current Library presentation
- [x] Implement dedicated export-history screen and management actions
- [x] Add regression coverage for the new export-history workflow
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current Export history screen and persistence actions
- [x] Implement per-entry deletion and export-history sorting
- [x] Add regression coverage for the new export-history management behavior
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current Export history list and deletion boundaries
- [x] Implement multi-select export-history deletion controls
- [x] Add regression coverage for the new export-history selection behavior
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and identify the highest-value gap
- [x] Implement the selected React Native functionality improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Review Expo background-task, network, storage, and export guidance
- [x] Design shared evidence sync progress, recovery, and metadata export contracts
- [x] Implement bulk selected-draft metadata export
- [x] Implement per-draft sync progress and structured recovery guidance
- [x] Implement network-aware background retry for evidence drafts
- [x] Add regression coverage for the requested evidence workflow
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [ ] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [ ] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit the full-screen evidence viewer and read relevant Expo guidance
- [x] Implement pinch-to-zoom and pan inspection controls
- [x] Implement capture/upload/integrity metadata overlays
- [x] Implement platform-safe share and export for selected evidence photos
- [x] Add regression coverage for the viewer helpers
- [x] Run complete Expo validation
- [x] Save the viewer enhancements checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [x] Audit current mobile workflows and select the next functionality gap
- [x] Implement the selected investigator workflow improvement
- [x] Add regression coverage for the selected functionality
- [x] Run complete Expo validation
- [x] Save the functionality checkpoint

- [ ] Audit existing monetization UI, backend routes, dependencies, and Stripe configuration
- [x] Implement server-created Stripe Checkout sessions with server-authoritative entitlements
- [x] Implement verified Stripe webhook reconciliation with idempotency safeguards
- [x] Add an Expo-safe billing screen with plan, checkout, and entitlement states
- [x] Add payment regression coverage and robust unavailable-service fallbacks
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [x] Save the Stripe monetization checkpoint

- [x] Add Free $0, Professional $29/month, and Team $99/month plan presentation
- [x] Keep live checkout unavailable until server Stripe credentials are configured

- [x] Audit the current Stripe billing foundation and select the next monetization gap
- [x] Implement a server-created Stripe Customer Portal session
- [x] Add entitlement refresh and payment-recovery state handling
- [x] Add billing-management controls to the Expo usage screen
- [x] Add Stripe regression coverage
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [ ] Save the Stripe management checkpoint

- [x] Audit current billing persistence, webhook events, and account presentation
- [x] Extend billing data for durable billing-event history and payment recovery states
- [x] Reconcile invoice and payment events server-side with idempotent handling
- [x] Surface live entitlement and payment-recovery status in the Account tab
- [x] Add deterministic Stripe webhook and billing-state regression coverage
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [ ] Save the monetization processing checkpoint

- [x] Audit plan limits, evidence workflows, and current entitlement contracts
- [x] Implement server-authoritative usage limits and durable usage counters
- [x] Add upgrade prompts and plan-aware gating to mobile workflows
- [x] Add deterministic monetization coverage
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [ ] Save the usage-entitlement monetization checkpoint

- [x] Audit subscription lifecycle states, webhook coverage, and billing UI gaps
- [x] Implement authoritative subscription lifecycle and recovery state handling
- [x] Improve billing recovery UX and plan lifecycle messaging in Expo
- [x] Add Stripe lifecycle regression coverage
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [ ] Save the Stripe lifecycle checkpoint

- [x] Audit current computer-vision contract, capture quality, and scan-result UX
- [x] Strengthen visual evidence quality and structured analysis outputs
- [x] Improve investigator-facing vision results, uncertainty, and next-capture guidance
- [x] Add deterministic computer-vision regression coverage
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [ ] Save the computer-vision checkpoint

- [x] Audit current single-image vision contract and evidence capture flow
- [x] Implement multi-image analysis inputs and conservative cross-photo normalization
- [x] Improve mobile capture and result UX for evidence sets and consistency findings
- [x] Add deterministic multi-image vision regression coverage
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [ ] Save the multi-image computer-vision checkpoint

- [x] Audit the current multi-photo route and evidence review components
- [x] Implement evidence-set review state and per-image quality guidance
- [x] Add retake, remove, reorder, and analysis handoff interactions across Expo paths
- [x] Add deterministic evidence-review regression coverage
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [ ] Save the evidence-review computer-vision checkpoint

- [x] Audit evidence review persistence and audit-event contracts
- [x] Persist review checklist, ordering, and image-set provenance metadata
- [x] Surface traceable review state in computer-vision handoff and audit exports
- [x] Add deterministic auditability regression coverage
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [ ] Save the persisted evidence-review checkpoint

- [x] Audit current reference-image inputs, analysis provenance, and export contracts
- [x] Implement reference-image comparison and deterministic provenance hashing
- [x] Surface reference comparison findings and provenance verification in mobile results
- [x] Add deterministic computer-vision provenance coverage
- [x] Run complete TypeScript, Vitest, lint, Expo Doctor, and web export validation
- [ ] Save the reference-comparison checkpoint
