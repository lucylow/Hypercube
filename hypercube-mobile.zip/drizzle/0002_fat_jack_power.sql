CREATE TABLE `billingEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stripeEventId` varchar(255) NOT NULL,
	`eventType` varchar(128) NOT NULL,
	`stripeCustomerId` varchar(255),
	`userId` int,
	`outcome` enum('processed','ignored','failed') NOT NULL DEFAULT 'processed',
	`occurredAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `billingEvents_id` PRIMARY KEY(`id`),
	CONSTRAINT `billingEvents_stripeEventId_unique` UNIQUE(`stripeEventId`)
);
--> statement-breakpoint
ALTER TABLE `billingSubscriptions` ADD `paymentStatus` enum('unknown','paid','failed','requires_action') DEFAULT 'unknown' NOT NULL;--> statement-breakpoint
ALTER TABLE `billingSubscriptions` ADD `lastPaymentFailureAt` timestamp;--> statement-breakpoint
ALTER TABLE `billingSubscriptions` ADD `lastBillingEventType` varchar(128);