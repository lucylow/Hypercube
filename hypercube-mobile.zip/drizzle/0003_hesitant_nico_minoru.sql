CREATE TABLE `billingUsage` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`periodStart` timestamp NOT NULL,
	`evidenceDrafts` int NOT NULL DEFAULT 0,
	`evidencePhotos` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `billingUsage_id` PRIMARY KEY(`id`),
	CONSTRAINT `billingUsage_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `billingUsageClaims` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`caseId` varchar(120) NOT NULL,
	`photoCount` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `billingUsageClaims_id` PRIMARY KEY(`id`)
);
