import { int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const billingSubscriptions = mysqlTable("billingSubscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }).unique(),
  plan: mysqlEnum("plan", ["free", "professional", "team"]).default("free").notNull(),
  status: mysqlEnum("status", ["inactive", "incomplete", "trialing", "active", "past_due", "paused", "canceled", "unavailable"]).default("inactive").notNull(),
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  paymentStatus: mysqlEnum("paymentStatus", ["unknown", "paid", "failed", "requires_action"]).default("unknown").notNull(),
  lastPaymentFailureAt: timestamp("lastPaymentFailureAt"),
  lastBillingEventType: varchar("lastBillingEventType", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BillingSubscription = typeof billingSubscriptions.$inferSelect;
export type InsertBillingSubscription = typeof billingSubscriptions.$inferInsert;

export const billingEvents = mysqlTable("billingEvents", {
  id: int("id").autoincrement().primaryKey(),
  stripeEventId: varchar("stripeEventId", { length: 255 }).notNull().unique(),
  eventType: varchar("eventType", { length: 128 }).notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  userId: int("userId"),
  outcome: mysqlEnum("outcome", ["processed", "ignored", "failed"]).default("processed").notNull(),
  occurredAt: timestamp("occurredAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BillingEvent = typeof billingEvents.$inferSelect;
export type InsertBillingEvent = typeof billingEvents.$inferInsert;

export const billingUsage = mysqlTable("billingUsage", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  periodStart: timestamp("periodStart").notNull(),
  evidenceDrafts: int("evidenceDrafts").default(0).notNull(),
  evidencePhotos: int("evidencePhotos").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const billingUsageClaims = mysqlTable("billingUsageClaims", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  caseId: varchar("caseId", { length: 120 }).notNull(),
  photoCount: int("photoCount").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userCaseUnique: uniqueIndex("billingUsageClaims_user_case_unique").on(table.userId, table.caseId),
}));

export type BillingUsage = typeof billingUsage.$inferSelect;
export type BillingUsageClaim = typeof billingUsageClaims.$inferSelect;
export type InsertBillingUsage = typeof billingUsage.$inferInsert;
export type InsertBillingUsageClaim = typeof billingUsageClaims.$inferInsert;
