CREATE TABLE `billingSubscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`stripeCustomerId` varchar(255),
	`stripeSubscriptionId` varchar(255),
	`plan` enum('free','professional','team') NOT NULL DEFAULT 'free',
	`status` enum('inactive','trialing','active','past_due','canceled','unavailable') NOT NULL DEFAULT 'inactive',
	`currentPeriodEnd` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `billingSubscriptions_id` PRIMARY KEY(`id`),
	CONSTRAINT `billingSubscriptions_userId_unique` UNIQUE(`userId`),
	CONSTRAINT `billingSubscriptions_stripeSubscriptionId_unique` UNIQUE(`stripeSubscriptionId`)
);
