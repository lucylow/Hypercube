# Hypercube Mobile Interface Design

## Product direction

Hypercube Mobile is a first-party-feeling iOS-style field tool for counterfeit intelligence. The experience treats **Scan** as the primary action and uses plain-language risk guidance instead of claiming that AI can prove authenticity. The main audience is a consumer or collector who wants a fast product check, with a secondary workflow for brand investigators who need evidence, cases, locations, and team review.

The interface assumes portrait orientation, 9:16 screens, and one-handed use. Primary actions sit in the lower half of the screen or in the thumb-reachable bottom navigation. Content is progressive: a user sees the result and recommended next step before technical evidence details.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Welcome / sign in | Hypercube brand promise, email sign-in, organization access, privacy reassurance, and a short explanation of scan-based verification. |
| Home | Greeting, dominant Scan Product CTA, recent scan summary, open case count, and a short “what to look for” trust card. |
| Scan mode | Camera view with QR/barcode detection, framing guides, flash control, gallery import, and switch to guided photo capture. |
| Scan permission | Clear camera-access explanation and a single action to continue to system permission. |
| Guided capture | Four capture steps: front, logo/label, serial/packaging, and optional detail. Includes image-quality guidance. |
| Capture review | Thumbnail strip, retake/remove actions, product context fields, and “Analyze evidence” CTA. |
| Analysis in progress | Queued/processing state, upload progress, privacy note, and option to keep browsing while analysis continues. |
| Authenticity result | Risk band, confidence, human-readable reasons, scan metadata, and next actions: save, create case, share, scan another. |
| Result evidence | Expandable findings for logo match, OCR/serial, packaging, seller/source, and image-quality signals. |
| Product profile | Brand, model/SKU, serial, provenance, scan history, known-good reference indicators, and create-case action. |
| Cases | Filterable list of open, needs-review, and resolved cases with risk/status chips. |
| Case detail | Case title, risk summary, evidence gallery, seller/source, location, timeline, assignee, notes, and status changes. |
| Add evidence | Camera/gallery upload, note field, evidence type, timestamp, and save-to-case action. |
| Incident map | Clustered incident markers, map/list toggle, filters by brand/status, and tap-through to case detail. |
| Incident detail | Location, nearby incidents, product/case summary, and evidence timeline. |
| Library | Searchable history of scans, products, and saved evidence. |
| Notifications | Analysis complete, case assignment, review requests, and export status. |
| Account | Profile, organization, role, plan/usage, privacy, help, and sign out. |
| Organization / team | Members, roles, brand workspaces, invite action, and audit-log entry point. |
| Subscription / usage | Scan allowance, plan summary, usage history, and upgrade/manage subscription CTA. |
| Settings / privacy | Camera and photo permissions, data retention, analytics consent, security, and support links. |

## Key user flows

### Consumer authenticity check

1. User opens Home and taps **Scan Product**.
2. The app presents QR/barcode scanning immediately, with a secondary path for product photos.
3. User scans a code or chooses guided capture.
4. The app prompts for front, logo/label, and packaging/serial images, with feedback for glare and framing.
5. User reviews images and taps **Analyze evidence**.
6. The app shows a queued/processing state, then a risk band such as **Low risk — confidence 84%**, **Needs review**, or **High risk — inspect**.
7. User opens evidence reasons, saves the scan, shares the result, or creates a case.

### Brand investigator case creation

1. User opens a result with multiple suspicious findings.
2. User taps **Create case**.
3. The app pre-fills product, scan, seller/source, location, and evidence metadata.
4. User adds a note and assigns the case to a teammate.
5. Case status becomes **Open** and appears in Cases and Map.
6. User adds more evidence, updates status, and reviews the append-only timeline.

### Incident review

1. User opens Cases or Map.
2. User filters by brand, risk, status, or time range.
3. User taps an incident cluster or case row.
4. The app shows the product, evidence, location, source, and timeline.
5. User adds evidence or changes status to **Needs review** or **Resolved**.

## Visual design system

Hypercube uses a deep ink foundation with an electric cyan signal color and a warm violet secondary accent. The visual language is technical but not dystopian: rounded cards, thin data-grid dividers, restrained gradients, and high-contrast status signals. The app should feel like a trustworthy Apple utility rather than a crypto wallet.

| Token | Choice | Use |
|---|---|---|
| Ink | `#07111F` | Primary dark background and navigation surfaces |
| Navy | `#0C1C31` | Elevated cards and camera overlays |
| Signal cyan | `#42E8D0` | Primary CTA, verified/active controls, scan reticle |
| Electric blue | `#5E8BFF` | Links, secondary actions, data visualizations |
| Violet | `#8D7CFF` | Brand accent, onboarding glow, selected category |
| Paper | `#F6F8FB` | Light-mode background and surfaces |
| Ink text | `#102033` | Primary light-mode text |
| Muted text | `#7B8798` | Secondary labels and metadata |
| Success | `#29C987` | Low-risk and verified signals |
| Warning | `#F2B84B` | Needs-review states |
| Danger | `#FF6F7D` | High-risk states and destructive actions |

Typography uses a large, semibold page title, compact uppercase eyebrow labels for data categories, and generous line height for explanations. Cards use 16–22 px radii, buttons use 14–16 px radii rather than excessive pills, and touch targets remain at least 44 px.

## Interaction principles

Every major action gives immediate press feedback and a clear loading or completion state. Scanner actions use light haptics, successful analysis uses a success notification, and failure states explain how to recover. Technical terms such as NFT, DID, or DAO remain secondary; the first screen should explain what the user can decide, not how the infrastructure works.

## Mockup set

The 20 visual mockups will cover: welcome/sign in, Home, Scan, scan permission, guided capture, capture review, analysis in progress, low-risk result, high-risk result, evidence details, Product profile, Cases, Case detail, Add evidence, Incident map, incident detail, Library, Notifications, Account, and Subscription/usage. These screens are the visual source of truth for the first implementation pass.
