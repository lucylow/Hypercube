import type { Request, Response } from 'express';
import type Stripe from 'stripe';
import { getBillingSubscription, recordBillingEvent, upsertBillingSubscription } from './db';
import { verifyStripeEvent } from './stripe-billing';

function planFromMetadata(metadata: Stripe.Metadata | null | undefined): 'professional' | 'team' {
  return metadata?.plan === 'team' ? 'team' : 'professional';
}

export function statusFromStripe(status: Stripe.Subscription.Status): 'inactive' | 'incomplete' | 'trialing' | 'active' | 'past_due' | 'paused' | 'canceled' | 'unavailable' {
  if (status === 'incomplete') return 'incomplete';
  if (status === 'trialing') return 'trialing';
  if (status === 'active') return 'active';
  if (status === 'paused') return 'paused';
  if (status === 'past_due' || status === 'unpaid') return 'past_due';
  if (status === 'canceled' || status === 'incomplete_expired') return 'canceled';
  return 'inactive';
}

export function paymentStatusFromInvoiceEvent(eventType: string): 'paid' | 'failed' | 'requires_action' | null {
  if (eventType === 'invoice.paid') return 'paid';
  if (eventType === 'invoice.payment_failed') return 'failed';
  if (eventType === 'invoice.payment_action_required') return 'requires_action';
  return null;
}

function customerIdFromObject(object: Stripe.Event.Data.Object): string | null {
  if ('customer' in object) {
    const customer = object.customer as string | { id: string } | null | undefined;
    return typeof customer === 'string' ? customer : customer?.id ?? null;
  }
  return null;
}

export async function handleStripeWebhook(req: Request, res: Response) {
  const signature = req.headers['stripe-signature'];
  const rawBody = (req as Request & { rawBody?: Buffer }).rawBody ?? Buffer.from(JSON.stringify(req.body ?? {}));
  let event: Stripe.Event;
  try {
    event = verifyStripeEvent(rawBody, Array.isArray(signature) ? signature[0] : signature) as Stripe.Event;
    if (!event) return res.status(503).json({ error: 'Stripe webhook verification is not configured.' });
  } catch {
    return res.status(400).json({ error: 'Invalid Stripe webhook signature.' });
  }

  try {
    const customerId = customerIdFromObject(event.data.object);
    let userId: number | null = null;
    let outcome: 'processed' | 'ignored' = 'ignored';

    if (event.type === 'checkout.session.completed' || event.type === 'checkout.session.async_payment_succeeded') {
      const session = event.data.object as Stripe.Checkout.Session;
      userId = Number(session.metadata?.userId ?? session.client_reference_id);
      const subscriptionId = typeof session.subscription === 'string' ? session.subscription : session.subscription?.id;
      const sessionCustomerId = typeof session.customer === 'string' ? session.customer : session.customer?.id;
      if (Number.isInteger(userId) && userId > 0) {
        await upsertBillingSubscription({ userId, stripeCustomerId: sessionCustomerId ?? null, stripeSubscriptionId: subscriptionId ?? null, plan: planFromMetadata(session.metadata), status: 'active', paymentStatus: 'unknown', lastBillingEventType: event.type, currentPeriodEnd: null });
        outcome = 'processed';
      }
    }

    if (event.type === 'customer.subscription.created' || event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.deleted' || event.type === 'customer.subscription.paused' || event.type === 'customer.subscription.resumed') {
      const subscription = event.data.object as Stripe.Subscription;
      const subscriptionCustomerId = typeof subscription.customer === 'string' ? subscription.customer : subscription.customer.id;
      const existing = await getBillingSubscriptionByCustomerId(subscriptionCustomerId);
      if (existing) {
        userId = existing.userId;
        const subscriptionStatus = event.type === 'customer.subscription.deleted' ? 'canceled' : statusFromStripe(subscription.status);
        await upsertBillingSubscription({
          userId: existing.userId,
          stripeCustomerId: subscriptionCustomerId,
          stripeSubscriptionId: subscription.id,
          plan: existing.plan === 'team' ? 'team' : 'professional',
          status: subscriptionStatus,
          paymentStatus: subscriptionStatus === 'active' || subscriptionStatus === 'trialing' ? 'paid' : existing.paymentStatus,
          lastBillingEventType: event.type,
          currentPeriodEnd: ((subscription as unknown as { current_period_end?: number }).current_period_end) ? new Date(((subscription as unknown as { current_period_end: number }).current_period_end) * 1000) : null,
        });
        outcome = 'processed';
      }
    }

    if (event.type === 'invoice.paid' || event.type === 'invoice.payment_failed' || event.type === 'invoice.payment_action_required') {
      const invoice = event.data.object as Stripe.Invoice;
      const invoiceCustomerId = typeof invoice.customer === 'string' ? invoice.customer : invoice.customer?.id;
      if (invoiceCustomerId) {
        const existing = await getBillingSubscriptionByCustomerId(invoiceCustomerId);
        if (existing) {
          userId = existing.userId;
          const invoicePaymentStatus = paymentStatusFromInvoiceEvent(event.type);
          const paid = invoicePaymentStatus === 'paid';
          const actionRequired = invoicePaymentStatus === 'requires_action';
          await upsertBillingSubscription({
            userId: existing.userId,
            stripeCustomerId: invoiceCustomerId,
            stripeSubscriptionId: existing.stripeSubscriptionId,
            plan: existing.plan,
            status: paid ? 'active' : 'past_due',
            paymentStatus: invoicePaymentStatus ?? 'failed',
            lastPaymentFailureAt: paid ? null : new Date(event.created * 1000),
            lastBillingEventType: event.type,
            currentPeriodEnd: existing.currentPeriodEnd,
          });
          outcome = 'processed';
        }
      }
    }

    const recorded = await recordBillingEvent({ stripeEventId: event.id, eventType: event.type, stripeCustomerId: customerId, userId, outcome, occurredAt: new Date(event.created * 1000) });
    return res.json({ received: true, duplicate: !recorded });
  } catch {
    return res.status(500).json({ error: 'Webhook reconciliation failed.' });
  }
}

async function getBillingSubscriptionByCustomerId(customerId: string) {
  const { getDb } = await import('./db');
  const { billingSubscriptions } = await import('../drizzle/schema');
  const { eq } = await import('drizzle-orm');
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(billingSubscriptions).where(eq(billingSubscriptions.stripeCustomerId, customerId)).limit(1);
  return rows[0];
}
