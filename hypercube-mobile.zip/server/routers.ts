import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { createHash } from "node:crypto";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { analyzeAuthenticity } from "./ai-analysis";
import { storageGetSignedUrl, storagePut } from "./storage";
import { evidencePhotoExtension, parseEvidencePhotoDataUrl } from "../shared/evidence-upload";
import { claimEvidenceUsage, getBillingSubscription, getBillingUsage } from "./db";
import { BILLING_PLANS, createCustomerPortalSession, createHostedCheckout, isStripeConfigured, type PaidPlanKey } from "./stripe-billing";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  evidence: router({
    getPhotoDownloadUrl: protectedProcedure
      .input(z.object({ remoteKey: z.string().min(1).max(500) }))
      .mutation(async ({ input }) => ({ signedUrl: await storageGetSignedUrl(input.remoteKey) })),

    uploadPhoto: protectedProcedure
      .input(z.object({
        caseId: z.string().min(1).max(120),
        photoId: z.string().min(1).max(120),
        dataUrl: z.string().max(8_500_000),
      }))
      .mutation(async ({ input, ctx }) => {
        const { mimeType, base64 } = parseEvidencePhotoDataUrl(input.dataUrl);
        const bytes = Buffer.from(base64, 'base64');
        const stored = await storagePut(`evidence/${ctx.user.id}/${input.caseId}/${input.photoId}.${evidencePhotoExtension(mimeType)}`, bytes, mimeType);
        return { photoId: input.photoId, ...stored, integrityHash: createHash('sha256').update(bytes).digest('hex') };
      }),

    syncDraft: protectedProcedure
      .input(z.object({
        caseId: z.string().min(1).max(120),
        evidenceType: z.string().min(1).max(80),
        note: z.string().max(1200),
        photoCount: z.number().int().min(0).max(100),
        photoUrls: z.array(z.string().max(500)).max(100).default([]),
        updatedAt: z.string().datetime(),
      }))
      .mutation(async ({ input, ctx }) => {
        const subscription = await getBillingSubscription(ctx.user.id);
        const plan = BILLING_PLANS[subscription?.plan ?? 'free'];
        const claim = await claimEvidenceUsage({ userId: ctx.user.id, caseId: input.caseId, photoCount: input.photoCount, evidenceDraftLimit: plan.evidenceDraftLimit, evidencePhotoLimit: plan.evidencePhotoLimit });
        if (!claim.allowed) return { accepted: false as const, reason: claim.reason, upgradeRequired: true as const };
        return { accepted: true as const, duplicate: claim.duplicate, caseId: input.caseId, receivedAt: new Date().toISOString(), receiptId: `evidence-${ctx.user.id}-${Date.now()}`, actorId: ctx.user.id, usage: claim.usage };
      }),
  }),

  billing: router({
    plans: publicProcedure.query(() => Object.values(BILLING_PLANS)),
    entitlement: protectedProcedure.query(async ({ ctx }) => {
      const subscription = await getBillingSubscription(ctx.user.id);
      const effectivePlan = subscription?.plan ?? 'free';
      const usage = await getBillingUsage(ctx.user.id);
      const plan = BILLING_PLANS[effectivePlan];
      return { ...(subscription ?? { userId: ctx.user.id, plan: 'free' as const, status: 'inactive' as const, currentPeriodEnd: null, stripeCustomerId: null, stripeSubscriptionId: null, paymentStatus: 'unknown' as const, lastPaymentFailureAt: null, lastBillingEventType: null }), usage: usage ?? { userId: ctx.user.id, periodStart: new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1)), evidenceDrafts: 0, evidencePhotos: 0 }, limits: { evidenceDraftLimit: plan.evidenceDraftLimit, evidencePhotoLimit: plan.evidencePhotoLimit } };
    }),
    createCheckout: protectedProcedure
      .input(z.object({ plan: z.enum(['professional', 'team']), successUrl: z.string().url(), cancelUrl: z.string().url() }))
      .mutation(async ({ ctx, input }) => {
        if (!isStripeConfigured()) return { available: false as const, reason: 'Stripe is not configured on the server yet.' };
        const session = await createHostedCheckout({ userId: ctx.user.id, email: ctx.user.email, plan: input.plan as PaidPlanKey, successUrl: input.successUrl, cancelUrl: input.cancelUrl });
        if (!session?.url) return { available: false as const, reason: 'Stripe Checkout is temporarily unavailable.' };
        return { available: true as const, checkoutUrl: session.url, sessionId: session.id };
      }),
    createPortal: protectedProcedure
      .input(z.object({ returnUrl: z.string().url() }))
      .mutation(async ({ ctx, input }) => {
        const subscription = await getBillingSubscription(ctx.user.id);
        if (!isStripeConfigured() || !subscription?.stripeCustomerId) return { available: false as const, reason: 'Subscription management is available after a verified Stripe subscription is linked.' };
        const session = await createCustomerPortalSession({ stripeCustomerId: subscription.stripeCustomerId, returnUrl: input.returnUrl });
        if (!session?.url) return { available: false as const, reason: 'Subscription management is temporarily unavailable.' };
        return { available: true as const, portalUrl: session.url };
      }),
  }),

  ai: router({
    analyzeAuthenticity: publicProcedure
      .input(z.object({
        productName: z.string().max(120).optional(),
        code: z.string().max(160).optional(),
        evidenceType: z.string().max(80).optional(),
        note: z.string().max(1200).optional(),
        imageDataUrl: z.string().max(5000000).optional(),
        imageDataUrls: z.array(z.string().max(5000000)).max(3).optional(),
        referenceImageDataUrls: z.array(z.string().max(5000000)).max(3).optional(),
        reviewMetadata: z.object({ imageCount: z.number().int().min(0).max(4), reviewedIndexes: z.array(z.number().int().min(0).max(3)).max(4), reviewStartedAt: z.string().max(40), reviewCompletedAt: z.string().max(40).optional(), actions: z.array(z.string().max(80)).max(10) }).optional(),
        focus: z.enum(['overall', 'logo', 'packaging', 'serial', 'provenance']).optional(),
        feedback: z.enum(['helpful', 'needs_more_context']).optional(),
      }))
      .mutation(({ input }) => analyzeAuthenticity(input)),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
