import { createHash } from 'node:crypto';
import { invokeLLM } from './_core/llm';
import { fallbackAuthenticityAnalysis, normalizeAuthenticityAnalysis, type AnalysisFeedback, type AnalysisFocus, type AuthenticityAnalysis, type EvidenceReviewMetadata } from '../shared/ai';

const MODEL = 'gemini-3-flash-preview';

type AnalyzeInput = {
  productName?: string;
  code?: string;
  evidenceType?: string;
  note?: string;
  imageDataUrl?: string;
  imageDataUrls?: string[];
  referenceImageDataUrls?: string[];
  focus?: AnalysisFocus;
  feedback?: AnalysisFeedback;
  reviewMetadata?: EvidenceReviewMetadata;
};

function contentToText(content: string | Array<{ type: string; text?: string }>): string {
  if (typeof content === 'string') return content;
  return content.map((part) => part.text ?? '').join('\n');
}

export async function analyzeAuthenticity(input: AnalyzeInput): Promise<AuthenticityAnalysis> {
  const imageDataUrls = [input.imageDataUrl, ...(input.imageDataUrls ?? [])].filter((value): value is string => Boolean(value)).slice(0, 4);
  const referenceImageDataUrls = (input.referenceImageDataUrls ?? []).filter((value): value is string => Boolean(value)).slice(0, 3);
  const usedVision = imageDataUrls.length > 0;
  const provenanceHasher = createHash('sha256');
  provenanceHasher.update(JSON.stringify({ focus: input.focus ?? 'overall', imageCount: imageDataUrls.length, referenceImageCount: referenceImageDataUrls.length, reviewMetadata: input.reviewMetadata ?? null }));
  imageDataUrls.forEach((value) => provenanceHasher.update(value));
  referenceImageDataUrls.forEach((value) => provenanceHasher.update(value));
  const provenanceHash = provenanceHasher.digest('hex');
  const focus = input.focus ?? 'overall';
  const focusLabel = focus === 'overall' ? 'the overall authenticity picture' : `the ${focus} signal in particular`;
  const feedbackInstruction = input.feedback === 'needs_more_context'
    ? 'The analyst asked for more context. Be extra explicit about uncertainty and prioritize the next evidence capture.'
    : input.feedback === 'helpful'
      ? 'The analyst found the prior explanation helpful. Preserve its clarity while checking the evidence again.'
      : 'No analyst feedback has been provided yet.';
  const textContext = [
    `Product: ${input.productName?.trim() || 'Unknown product'}`,
    `Scanned code: ${input.code?.trim() || 'Not provided'}`,
    `Evidence type: ${input.evidenceType?.trim() || 'Product detail'}`,
    `Investigator note: ${input.note?.trim() || 'None'}`,
    `Analyst focus: ${focusLabel}`,
    `Analyst feedback: ${feedbackInstruction}`,
    input.reviewMetadata ? `Evidence review metadata: ${JSON.stringify(input.reviewMetadata)}` : 'Evidence review metadata: Not supplied',
    referenceImageDataUrls.length ? `Reference images supplied: ${referenceImageDataUrls.length}. These are comparison aids, not proof of authenticity.` : 'Reference images supplied: None',
  ].join('\n');
  const outputInstructions = 'Return JSON with exactly these fields: verdict (low_risk, needs_review, or high_risk), confidence (0-100 integer), evidenceQuality (strong, moderate, or weak), summary, signals (array of up to 6 objects with title, status positive/warning/critical/neutral, and explanation), observedDetails (array of concrete visible or supplied details), missingEvidence (array of evidence that would improve confidence), recommendedAction, nextBestAction (object with title, rationale, and evidenceType), photoQuality (object with grade strong, moderate, or weak, issues array, usableForAnalysis boolean, and visualChecks object with sharpness, lighting, framing, and identifierReadability each set to strong, moderate, or weak), crossPhotoConsistency (object with status consistent, mixed, or insufficient and issues array), referenceComparison (object with status matched, mismatch, insufficient, or unavailable and issues array), and limitations (array of strings). Separate observed facts from hypotheses. Inspect the supplied photo for blur, glare, poor framing, cropping, low light, and unreadable identifiers before judging authenticity. Rate sharpness, lighting, framing, and identifier readability independently; do not infer readability when text or codes are not visibly legible. photoQuality issues must name concrete capture problems when present. When multiple images are supplied, compare overlapping product details across images and report whether they are consistent, mixed, or insufficient without treating camera angle or lighting changes as counterfeit evidence. Every warning or critical signal must point to a visible or explicitly supplied detail; if it cannot, mark it neutral and request the missing evidence. Do not claim legal certainty. Treat missing evidence conservatively. If no image is supplied, do not make visual claims and return needs_review. Never infer a serial number, QR/NFC value, logo detail, seller identity, or provenance record that is not visible or explicitly supplied.';
  const content = [{ type: 'text' as const, text: `Analyze this product for counterfeit risk, focusing on ${focusLabel}.\n\n${textContext}\n\n${outputInstructions}` }];
  for (const imageDataUrl of imageDataUrls) content.push({ type: 'image_url' as const, image_url: { url: imageDataUrl, detail: 'auto' } } as never);
  if (referenceImageDataUrls.length) content.push({ type: 'text' as const, text: 'The following image(s) are investigator-supplied reference aids. Compare visible packaging, logo, and layout details cautiously; do not assume they are verified brand originals.' } as never);
  for (const imageDataUrl of referenceImageDataUrls) content.push({ type: 'image_url' as const, image_url: { url: imageDataUrl, detail: 'auto' } } as never);

  try {
    const response = await invokeLLM({
      model: MODEL,
      messages: [
        { role: 'system', content: 'You are Hypercube, a careful brand-protection analyst. Visual similarity is a risk signal, not proof of authenticity. Separate observed details from assumptions, explain uncertainty, and recommend the next best evidence capture. Never invent reference data, serial values, provenance, seller facts, or visual details.' },
        { role: 'user', content },
      ],
      maxTokens: 1800,
      responseFormat: { type: 'json_object' },
    });
    const raw = response.choices[0]?.message?.content;
    if (!raw) throw new Error('AI returned an empty analysis.');
    const parsed = JSON.parse(contentToText(raw));
    return normalizeAuthenticityAnalysis(parsed, { model: response.model || MODEL, usedVision, focus, imageCount: imageDataUrls.length, referenceImageCount: referenceImageDataUrls.length, reviewMetadata: input.reviewMetadata, provenanceHash });
  } catch (error) {
    return fallbackAuthenticityAnalysis({ model: MODEL, usedVision, focus, reason: error instanceof Error ? error.message.slice(0, 160) : 'The analysis service could not complete this review.' });
  }
}
