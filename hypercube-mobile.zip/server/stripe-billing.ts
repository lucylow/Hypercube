import Stripe from 'stripe';

export const BILLING_PLANS = {
  free: { key: 'free', name: 'Free', amountCents: 0, interval: 'month' as const, evidenceDraftLimit: 5, evidencePhotoLimit: 25, description: 'A simple starting point for occasional verification.' },
  professional: { key: 'professional', name: 'Professional', amountCents: 2900, interval: 'month' as const, evidenceDraftLimit: 100, evidencePhotoLimit: 1000, description: 'For investigators reviewing products and managing evidence.' },
  team: { key: 'team', name: 'Team', amountCents: 9900, interval: 'month' as const, evidenceDraftLimit: 500, evidencePhotoLimit: 5000, description: 'For brand-protection teams coordinating casework.' },
} as const;

export type PaidPlanKey = 'professional' | 'team';
export type UsageLimits = { evidenceDraftLimit: number; evidencePhotoLimit: number };

export function getPlanUsageLimits(plan: string): UsageLimits {
  const selected = getPlan(plan) ?? BILLING_PLANS.free;
  return { evidenceDraftLimit: selected.evidenceDraftLimit, evidencePhotoLimit: selected.evidencePhotoLimit };
}

export function canClaimEvidenceUsage(usage: { evidenceDrafts: number; evidencePhotos: number }, limits: UsageLimits, photoCount: number) {
  return usage.evidenceDrafts + 1 <= limits.evidenceDraftLimit && usage.evidencePhotos + photoCount <= limits.evidencePhotoLimit;
}

let stripeClient: Stripe | null | undefined;

export function getStripeClient(): Stripe | null {
  if (stripeClient !== undefined) return stripeClient;
  const secretKey = process.env.HYPERCUBE_STRIPE_SECRET_KEY;
  stripeClient = secretKey ? new Stripe(secretKey) : null;
  return stripeClient;
}

export function isStripeConfigured(): boolean {
  return Boolean(process.env.HYPERCUBE_STRIPE_SECRET_KEY && process.env.HYPERCUBE_STRIPE_WEBHOOK_SECRET);
}

export function getPlan(plan: string) {
  return BILLING_PLANS[plan as keyof typeof BILLING_PLANS] ?? null;
}

export async function createHostedCheckout(input: { userId: number; email?: string | null; plan: PaidPlanKey; successUrl: string; cancelUrl: string }) {
  const stripe = getStripeClient();
  const selected = getPlan(input.plan);
  if (!stripe || !selected || selected.amountCents <= 0) return null;

  return stripe.checkout.sessions.create({
    mode: 'subscription',
    customer_email: input.email ?? undefined,
    client_reference_id: String(input.userId),
    metadata: { userId: String(input.userId), plan: input.plan },
    line_items: [{
      quantity: 1,
      price_data: {
        currency: 'usd',
        unit_amount: selected.amountCents,
        recurring: { interval: selected.interval },
        product_data: { name: `Hypercube ${selected.name}`, description: selected.description },
      },
    }],
    success_url: input.successUrl,
    cancel_url: input.cancelUrl,
  });
}

export async function createCustomerPortalSession(input: { stripeCustomerId: string; returnUrl: string }) {
  const stripe = getStripeClient();
  if (!stripe) return null;
  return stripe.billingPortal.sessions.create({ customer: input.stripeCustomerId, return_url: input.returnUrl });
}

export function verifyStripeEvent(rawBody: string | Buffer, signature: string | undefined) {
  const stripe = getStripeClient();
  const webhookSecret = process.env.HYPERCUBE_STRIPE_WEBHOOK_SECRET;
  if (!stripe || !webhookSecret || !signature) return null;
  return stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
}

export function resetStripeClientForTests() {
  stripeClient = undefined;
}
