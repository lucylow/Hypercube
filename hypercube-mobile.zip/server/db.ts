import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { billingEvents, billingSubscriptions, billingUsage, billingUsageClaims, type BillingSubscription, type InsertBillingEvent, type InsertBillingSubscription, users, type User, type InsertUser } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { canClaimEvidenceUsage } from "./stripe-billing";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getBillingSubscription(userId: number): Promise<BillingSubscription | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(billingSubscriptions).where(eq(billingSubscriptions.userId, userId)).limit(1);
  return result[0];
}

export async function upsertBillingSubscription(subscription: InsertBillingSubscription): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot persist billing entitlement: database not available");
    return;
  }
  await db.insert(billingSubscriptions).values(subscription).onDuplicateKeyUpdate({
    set: {
      stripeCustomerId: subscription.stripeCustomerId ?? null,
      stripeSubscriptionId: subscription.stripeSubscriptionId ?? null,
      plan: subscription.plan,
      status: subscription.status,
      currentPeriodEnd: subscription.currentPeriodEnd ?? null,
      paymentStatus: subscription.paymentStatus ?? "unknown",
      lastPaymentFailureAt: subscription.lastPaymentFailureAt ?? null,
      lastBillingEventType: subscription.lastBillingEventType ?? null,
      updatedAt: new Date(),
    },
  });
}

export async function recordBillingEvent(event: InsertBillingEvent): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  try {
    await db.insert(billingEvents).values(event);
    return true;
  } catch (error) {
    const message = error instanceof Error ? error.message.toLowerCase() : "";
    if (message.includes("duplicate") || message.includes("unique")) return false;
    throw error;
  }
}

function currentPeriodStart(now = new Date()) {
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
}

export async function getBillingUsage(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const periodStart = currentPeriodStart();
  const result = await db.select().from(billingUsage).where(eq(billingUsage.userId, userId)).limit(1);
  const existing = result[0];
  if (!existing) {
    return { userId, periodStart, evidenceDrafts: 0, evidencePhotos: 0 };
  }
  if (existing.periodStart.getTime() !== periodStart.getTime()) {
    await db.update(billingUsage).set({ periodStart, evidenceDrafts: 0, evidencePhotos: 0, updatedAt: new Date() }).where(eq(billingUsage.userId, userId));
    return { userId, periodStart, evidenceDrafts: 0, evidencePhotos: 0 };
  }
  return existing;
}

export async function claimEvidenceUsage(input: { userId: number; caseId: string; photoCount: number; evidenceDraftLimit: number; evidencePhotoLimit: number }) {
  const db = await getDb();
  if (!db) return { allowed: false as const, reason: 'Usage controls are temporarily unavailable.' };
  const existingClaim = await db.select().from(billingUsageClaims).where(and(eq(billingUsageClaims.userId, input.userId), eq(billingUsageClaims.caseId, input.caseId))).limit(1);
  const usage = await getBillingUsage(input.userId);
  if (!usage) return { allowed: false as const, reason: 'Usage controls are temporarily unavailable.' };
  if (existingClaim[0]) return { allowed: true as const, duplicate: true as const, usage };
  if (!canClaimEvidenceUsage(usage, { evidenceDraftLimit: input.evidenceDraftLimit, evidencePhotoLimit: input.evidencePhotoLimit }, input.photoCount)) {
    if (usage.evidenceDrafts + 1 > input.evidenceDraftLimit) return { allowed: false as const, reason: `Your plan allows ${input.evidenceDraftLimit} evidence submissions per month. Upgrade to continue.` };
    return { allowed: false as const, reason: `Your plan allows ${input.evidencePhotoLimit} evidence photos per month. Upgrade to continue.` };
  }
  await db.insert(billingUsageClaims).values({ userId: input.userId, caseId: input.caseId, photoCount: input.photoCount });
  if (usage.evidenceDrafts === 0 && usage.evidencePhotos === 0) {
    await db.insert(billingUsage).values({ userId: input.userId, periodStart: usage.periodStart, evidenceDrafts: 1, evidencePhotos: input.photoCount }).onDuplicateKeyUpdate({ set: { evidenceDrafts: 1, evidencePhotos: input.photoCount, updatedAt: new Date() } });
  } else {
    await db.update(billingUsage).set({ evidenceDrafts: usage.evidenceDrafts + 1, evidencePhotos: usage.evidencePhotos + input.photoCount, updatedAt: new Date() }).where(eq(billingUsage.userId, input.userId));
  }
  return { allowed: true as const, duplicate: false as const, usage: { ...usage, evidenceDrafts: usage.evidenceDrafts + 1, evidencePhotos: usage.evidencePhotos + input.photoCount } };
}

// TODO: add feature queries here as your schema grows.
