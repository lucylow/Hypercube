export const UI = {
  spacing: { xs: 4, sm: 8, md: 12, lg: 16, xl: 22, xxl: 30 },
  radius: { sm: 12, md: 15, lg: 16, xl: 22, pill: 999 },
  control: { minHeight: 52, hitSlop: 10 },
} as const;
