export const HC = {
  ink: '#07111F',
  navy: '#0C1C31',
  cyan: '#42E8D0',
  blue: '#5E8BFF',
  violet: '#8D7CFF',
  paper: '#F6F8FB',
  text: '#102033',
  muted: '#7B8798',
  success: '#29C987',
  warning: '#F2B84B',
  danger: '#FF6F7D',
  line: '#DCE4EF',
  white: '#FFFFFF',
} as const;

export const demoCases = [
  { id: 'HYP-1048', product: 'Air Max 90', status: 'Open', risk: 'High risk', location: 'Tokyo', age: '2h ago' },
  { id: 'HYP-1042', product: 'Leather tote', status: 'Needs review', risk: 'Review', location: 'Osaka', age: 'Yesterday' },
  { id: 'HYP-1035', product: 'Wireless headphones', status: 'Resolved', risk: 'Low risk', location: 'Seoul', age: '2d ago' },
];

export const recentScans = [
  { product: 'Air Max 90', result: 'Low risk', score: '84%', time: 'Today, 10:24 AM' },
  { product: 'Leather tote', result: 'Needs review', score: '62%', time: 'Yesterday, 4:18 PM' },
];
