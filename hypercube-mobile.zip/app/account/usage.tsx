import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Linking from 'expo-linking';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { Panel, PrimaryButton } from '@/components/hypercube-ui';
import { HC } from '@/constants/hypercube';
import { UI } from '@/constants/ui';
import { trpc } from '@/lib/trpc';

const fallbackPlans = [
  { key: 'free', name: 'Free', amountCents: 0, description: 'A simple starting point for occasional verification.' },
  { key: 'professional', name: 'Professional', amountCents: 2900, description: 'For investigators reviewing products and managing evidence.' },
  { key: 'team', name: 'Team', amountCents: 9900, description: 'For brand-protection teams coordinating casework.' },
] as const;

export default function UsageScreen() {
  const router = useRouter();
  const [notice, setNotice] = useState<string | null>(null);
  const plansQuery = trpc.billing.plans.useQuery(undefined, { retry: false });
  const entitlementQuery = trpc.billing.entitlement.useQuery(undefined, { retry: false });
  const checkout = trpc.billing.createCheckout.useMutation();
  const portal = trpc.billing.createPortal.useMutation();
  const plans = plansQuery.data?.length ? plansQuery.data : fallbackPlans;
  const currentPlan = entitlementQuery.data?.plan ?? 'free';
  const usage = entitlementQuery.data?.usage;
  const limits = entitlementQuery.data?.limits;
  const usagePercent = usage && limits ? Math.max((usage.evidenceDrafts / limits.evidenceDraftLimit) * 100, (usage.evidencePhotos / limits.evidencePhotoLimit) * 100) : 0;
  const billingStatus = entitlementQuery.data?.status ?? 'inactive';
  const lifecycleNotice = billingStatus === 'past_due' || entitlementQuery.data?.paymentStatus === 'failed' ? 'Payment failed. Open subscription management to update your payment method.' : billingStatus === 'paused' ? 'Subscription paused. Resume billing in subscription management to restore paid access.' : billingStatus === 'incomplete' || entitlementQuery.data?.paymentStatus === 'requires_action' ? 'Payment setup needs action. Complete the secure Stripe flow to activate paid access.' : billingStatus === 'canceled' ? 'Subscription canceled. Choose a paid plan to restore paid access.' : null;

  const openPortal = async () => {
    setNotice(null);
    try {
      const result = await portal.mutateAsync({ returnUrl: Linking.createURL('/account/usage?portal=returned') });
      if (!result.available) {
        setNotice(result.reason);
        return;
      }
      await Linking.openURL(result.portalUrl);
    } catch {
      setNotice('Subscription management is temporarily unavailable. Your current plan is unchanged.');
    }
  };

  const startCheckout = async (plan: 'professional' | 'team') => {
    setNotice(null);
    try {
      const result = await checkout.mutateAsync({
        plan,
        successUrl: Linking.createURL('/account/usage?checkout=success'),
        cancelUrl: Linking.createURL('/account/usage?checkout=cancelled'),
      });
      if (!result.available) {
        setNotice(result.reason);
        return;
      }
      await Linking.openURL(result.checkoutUrl);
    } catch {
      setNotice('Checkout is temporarily unavailable. Your current plan is unchanged.');
    }
  };

  return (
    <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3">
      <ScrollView contentContainerStyle={{ paddingBottom: UI.spacing.xxl }}>
        <View style={styles.header}>
          <Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => router.back()} hitSlop={UI.control.hitSlop}>
            <Ionicons name="chevron-back" size={24} color={HC.text} />
          </Pressable>
          <Text style={styles.title}>Plan and usage</Text>
          <View style={{ width: 24 }} />
        </View>

        <Panel dark style={styles.hero}>
          <Text style={styles.eyebrow}>CURRENT PLAN</Text>
          <Text style={styles.plan}>{plans.find((item) => item.key === currentPlan)?.name ?? 'Free'}</Text>
          <Text style={styles.description}>Billing status is confirmed by the server after Stripe reconciliation.</Text>
          <Text style={styles.usageSummary}>{usage && limits ? `${usage.evidenceDrafts}/${limits.evidenceDraftLimit} evidence submissions · ${usage.evidencePhotos}/${limits.evidencePhotoLimit} photos this month` : 'Loading usage limits…'}</Text>
          <View style={styles.ring}>
          <Text style={styles.ringValue}>{billingStatus === 'active' || billingStatus === 'trialing' ? 'ON' : '—'}</Text>
          <Text style={styles.ringLabel}>{billingStatus.replace('_', ' ')}</Text>
          </View>
        </Panel>

        {lifecycleNotice && <Panel style={styles.recoveryNotice}><Ionicons name="card-outline" size={19} color={HC.warning} /><Text style={styles.recoveryText}>{lifecycleNotice}</Text></Panel>}
        {currentPlan === 'free' && usagePercent >= 80 && <Panel style={styles.upgradeNotice}><Ionicons name="rocket-outline" size={19} color={HC.blue} /><Text style={styles.upgradeText}>You are approaching the Free plan limit. Upgrade before your next evidence handoff.</Text></Panel>}

        {notice && (
          <Panel style={styles.notice}>
            <Ionicons name="information-circle-outline" size={20} color={HC.warning} />
            <Text style={styles.noticeText}>{notice}</Text>
          </Panel>
        )}

        <Text style={styles.sectionTitle}>Choose a plan</Text>
        {plans.map((item) => {
          const paid = item.key !== 'free';
          const selected = item.key === currentPlan;
          return (
            <Panel key={item.key} style={[styles.planCard, selected && styles.planCardSelected]}>
              <View style={styles.planRow}>
                <View style={styles.planCopy}>
                  <Text style={styles.planName}>{item.name}{selected ? ' · Current' : ''}</Text>
                  <Text style={styles.planDescription}>{item.description}</Text>
                </View>
                <Text style={styles.price}>
                  {item.amountCents === 0 ? '$0' : `$${(item.amountCents / 100).toFixed(0)}`}
                  <Text style={styles.perMonth}>/mo</Text>
                </Text>
              </View>
              {paid && !selected && (
                <PrimaryButton
                  label={checkout.isPending ? 'Opening checkout…' : `Choose ${item.name}`}
                  onPress={() => startCheckout(item.key as 'professional' | 'team')}
                  disabled={checkout.isPending}
                  accessibilityLabel={`Choose ${item.name} plan`}
                />
              )}
              {selected && <Text style={styles.currentLabel}>Server entitlement: {entitlementQuery.data?.status ?? 'inactive'}{usage && limits ? ` · ${usage.evidenceDrafts}/${limits.evidenceDraftLimit} submissions used` : ''}</Text>}
            </Panel>
          );
        })}

        <View style={styles.managementRow}>
          {currentPlan !== 'free' && (
            <PrimaryButton
              label={portal.isPending ? 'Opening management…' : 'Manage subscription'}
              onPress={openPortal}
              disabled={portal.isPending}
              accessibilityLabel="Manage subscription"
            />
          )}
          <Pressable accessibilityRole="button" accessibilityLabel="Refresh billing status" onPress={() => entitlementQuery.refetch()} style={styles.refresh}>
            <Ionicons name="refresh-outline" size={16} color={HC.blue} />
            <Text style={styles.refreshText}>Refresh status</Text>
          </Pressable>
        </View>
        <Text style={styles.disclaimer}>Payments open in Stripe Checkout. Hypercube only upgrades access after a verified Stripe webhook confirms the subscription.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: UI.spacing.xl },
  title: { color: HC.text, fontSize: 18, fontWeight: '800' },
  hero: { alignItems: 'center', paddingVertical: UI.spacing.xxl, marginBottom: UI.spacing.md },
  eyebrow: { color: 'rgba(255,255,255,0.55)', fontSize: 10, fontWeight: '800', letterSpacing: 1.1 },
  plan: { color: HC.white, fontSize: 27, fontWeight: '800', marginTop: 8 },
  description: { color: 'rgba(255,255,255,0.62)', fontSize: 13, lineHeight: 19, textAlign: 'center', maxWidth: 280, marginTop: 7 },
  usageSummary: { color: HC.cyan, fontSize: 11, fontWeight: '800', textAlign: 'center', marginTop: 12 },
  upgradeNotice: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm, marginBottom: UI.spacing.md, borderColor: '#BCD4FF', backgroundColor: '#EEF5FF' },
  upgradeText: { flex: 1, color: HC.blue, fontSize: 12, lineHeight: 17, fontWeight: '700' },
  recoveryNotice: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm, marginBottom: UI.spacing.md, borderColor: '#F3D38A', backgroundColor: '#FFF7E6' },
  recoveryText: { flex: 1, color: HC.warning, fontSize: 12, lineHeight: 17, fontWeight: '700' },
  ring: { width: 126, height: 126, borderRadius: 63, borderWidth: 8, borderColor: HC.cyan, alignItems: 'center', justifyContent: 'center', marginTop: 20 },
  ringValue: { color: HC.white, fontSize: 31, fontWeight: '800' },
  ringLabel: { color: 'rgba(255,255,255,0.6)', fontSize: 11 },
  notice: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm, marginBottom: UI.spacing.md },
  noticeText: { flex: 1, color: HC.text, fontSize: 12, lineHeight: 18 },
  sectionTitle: { color: HC.text, fontSize: 16, fontWeight: '800', marginBottom: UI.spacing.sm },
  planCard: { marginBottom: UI.spacing.sm },
  planCardSelected: { borderColor: HC.blue, borderWidth: 1 },
  planRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: UI.spacing.md },
  planCopy: { flex: 1 },
  planName: { color: HC.text, fontSize: 15, fontWeight: '800' },
  planDescription: { color: HC.muted, fontSize: 12, lineHeight: 17, marginTop: 4 },
  price: { color: HC.blue, fontSize: 20, fontWeight: '800' },
  perMonth: { color: HC.muted, fontSize: 11, fontWeight: '600' },
  currentLabel: { color: HC.muted, fontSize: 11, fontWeight: '700', marginTop: UI.spacing.sm },
  managementRow: { gap: UI.spacing.sm, marginTop: UI.spacing.sm },
  refresh: { minHeight: 40, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6 },
  refreshText: { color: HC.blue, fontSize: 12, fontWeight: '800' },
  disclaimer: { color: HC.muted, fontSize: 11, lineHeight: 16, textAlign: 'center', marginTop: UI.spacing.md },
});
