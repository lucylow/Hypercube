import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { Eyebrow, Panel, PrimaryButton, StatusPill } from '@/components/hypercube-ui';
import { HC } from '@/constants/hypercube';
import { UI } from '@/constants/ui';
import { exportCaseSummary } from '@/lib/case-export';
import type { CaseSummary } from '@/shared/case-export';
import { riskLabel, riskTone } from '@/shared/status-tone';

export default function CaseDetailScreen() {
  const router = useRouter();
  const { caseId } = useLocalSearchParams<{ caseId?: string }>();
  const [exporting, setExporting] = React.useState(false);
  const activeCaseId = caseId ?? 'HYP-1048';
  const caseSummary: CaseSummary = {
    id: activeCaseId,
    product: 'Air Max 90',
    risk: 'High risk',
    location: 'Tokyo',
    summary: 'Multiple signals need review.',
    rationale: 'The logo differs from the reference set and the seller source was flagged in a previous incident.',
    assignee: 'Maya Chen',
    status: 'OPEN',
    events: [
      { title: 'Scan completed', body: 'Low-quality QR code capture analyzed', time: 'Today, 10:24 AM' },
      { title: 'Risk elevated', body: 'Seller source flagged for review', time: 'Today, 10:25 AM' },
      { title: 'Case assigned', body: 'Maya Chen added as investigator', time: 'Today, 10:26 AM' },
    ],
  };
  const handleCaseActions = () => Alert.alert('Case actions', 'Choose an action for this investigation.', [
    { text: 'Cancel', style: 'cancel' },
    { text: exporting ? 'Exporting…' : 'Export case summary', onPress: () => { if (exporting) return; setExporting(true); void exportCaseSummary(caseSummary).then((result) => { if (result === 'unavailable') Alert.alert('Export unavailable', 'This device cannot share or download the case summary right now.'); }).catch(() => Alert.alert('Export failed', 'The case summary could not be exported.')).finally(() => setExporting(false)); } },
  ]);
  return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: UI.spacing.xxl }}>
    <View style={styles.header}><Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => router.back()} hitSlop={UI.control.hitSlop}><Ionicons name="chevron-back" size={24} color={HC.text} /></Pressable><Text style={styles.headerTitle}>Case detail</Text><Pressable accessibilityRole="button" accessibilityLabel="Case actions" onPress={handleCaseActions} hitSlop={10}><Ionicons name="ellipsis-horizontal" size={22} color={HC.text} /></Pressable></View>
    <Eyebrow>CASE {caseId ?? 'HYP-1048'}</Eyebrow><Text style={styles.title}>Air Max 90</Text><View style={styles.metaRow}><StatusPill label={riskLabel('High risk')} tone={riskTone('High risk')} /><Text style={styles.location}><Ionicons name="location-outline" size={13} color={HC.muted} /> Tokyo</Text></View>
    <Panel dark style={styles.summary}><Text style={styles.summaryLabel}>CASE SUMMARY</Text><Text style={styles.summaryTitle}>Multiple signals need review.</Text><Text style={styles.summaryBody}>The logo differs from the reference set and the seller source was flagged in a previous incident.</Text><View style={styles.summaryFooter}><Text style={styles.assignee}>Assigned to Maya Chen</Text><Text style={styles.open}>OPEN</Text></View></Panel>
    <Text style={styles.section}>Evidence timeline</Text><View style={{ gap: 0 }}><Timeline icon="scan-outline" title="Scan completed" body="Low-quality QR code capture analyzed" time="Today, 10:24 AM" /><Timeline icon="alert-circle-outline" title="Risk elevated" body="Seller source flagged for review" time="Today, 10:25 AM" /><Timeline icon="person-add-outline" title="Case assigned" body="Maya Chen added as investigator" time="Today, 10:26 AM" /></View>
    <PrimaryButton label="Add evidence" icon="add" onPress={() => router.push({ pathname: '/case/[caseId]/add-evidence', params: { caseId: activeCaseId } })} />
  </ScrollView></ScreenContainer>;
}
function Timeline({ icon, title, body, time }: { icon: keyof typeof Ionicons.glyphMap; title: string; body: string; time: string }) { return <View style={styles.event}><View style={styles.eventIcon}><Ionicons name={icon} size={19} color={HC.blue} /></View><View style={{ flex: 1 }}><Text style={styles.eventTitle}>{title}</Text><Text style={styles.eventBody}>{body}</Text><Text style={styles.eventTime}>{time}</Text></View></View>; }
const styles = StyleSheet.create({ header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: UI.spacing.xxl }, headerTitle: { color: HC.text, fontSize: 17, fontWeight: '800' }, title: { color: HC.text, fontSize: 30, fontWeight: '800', marginTop: 5 }, metaRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 10 }, location: { color: HC.muted, fontSize: 12, fontWeight: '700' }, summary: { marginTop: UI.spacing.xl, marginBottom: UI.spacing.xxl }, summaryLabel: { color: 'rgba(255,255,255,0.55)', fontSize: 10, fontWeight: '800', letterSpacing: 1.2 }, summaryTitle: { color: HC.white, fontSize: 21, lineHeight: 26, fontWeight: '800', marginTop: 9 }, summaryBody: { color: 'rgba(255,255,255,0.64)', fontSize: 13, lineHeight: 19, marginTop: 8 }, summaryFooter: { borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.1)', marginTop: 17, paddingTop: 14, flexDirection: 'row', justifyContent: 'space-between' }, assignee: { color: 'rgba(255,255,255,0.72)', fontSize: 12, fontWeight: '700' }, open: { color: HC.cyan, fontSize: 11, fontWeight: '800' }, section: { color: HC.text, fontSize: 18, fontWeight: '800', marginBottom: 8 }, event: { flexDirection: 'row', gap: 13, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: HC.line }, eventIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#EEF3FF', alignItems: 'center', justifyContent: 'center' }, eventTitle: { color: HC.text, fontSize: 14, fontWeight: '800' }, eventBody: { color: HC.muted, fontSize: 12, marginTop: 4 }, eventTime: { color: HC.muted, fontSize: 11, marginTop: 6 }, });
