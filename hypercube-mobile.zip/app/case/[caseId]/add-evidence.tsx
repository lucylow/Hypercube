import { useLocalSearchParams, useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { useCallback, useEffect, useState } from 'react';
import { Alert, AppState, Image, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/screen-container';
import { Panel, PrimaryButton } from '@/components/hypercube-ui';
import { HC } from '@/constants/hypercube';
import { clearEvidenceDraft, createEvidencePhoto, loadEvidenceDraft, saveEvidenceDraft } from '@/lib/evidence-storage';
import { createEmptyEvidenceDraft, type EvidenceDraft, type EvidenceType } from '@/lib/evidence-model';

export default function AddEvidenceScreen() {
  const router = useRouter();
  const { caseId: rawCaseId } = useLocalSearchParams<{ caseId?: string }>();
  const caseId = rawCaseId ?? 'HYP-1048';
  const [draft, setDraft] = useState<EvidenceDraft>(() => createEmptyEvidenceDraft(caseId));
  const [isLoading, setIsLoading] = useState(true);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'error'>('saved');

  useEffect(() => {
    let mounted = true;
    loadEvidenceDraft(caseId)
      .then((saved) => {
        if (mounted && saved) {
          setDraft(saved);
          if (saved.photos.length > 0 || saved.note.trim().length > 0) {
            setTimeout(() => Alert.alert('Resume saved evidence?', `A local draft for case ${caseId} was found.`, [
              { text: 'Discard draft', style: 'destructive', onPress: () => { void clearEvidenceDraft(caseId).then(() => setDraft(createEmptyEvidenceDraft(caseId))); } },
              { text: 'Resume draft', style: 'default' },
            ]), 0);
          }
        }
      })
      .finally(() => {
        if (mounted) setIsLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, [caseId]);

  const persistDraft = useCallback(async (nextDraft: EvidenceDraft) => {
    setDraft(nextDraft);
    setSaveStatus('saving');
    try {
      await saveEvidenceDraft(nextDraft);
      setSaveStatus('saved');
    } catch {
      setSaveStatus('error');
    }
  }, []);

  useEffect(() => {
    if (isLoading) return;
    setSaveStatus('saving');
    const timeout = setTimeout(() => {
      void saveEvidenceDraft(draft).then(() => setSaveStatus('saved')).catch(() => setSaveStatus('error'));
    }, 450);
    return () => clearTimeout(timeout);
  }, [draft, isLoading]);

  const handlePhotoResult = useCallback(async (result: ImagePicker.ImagePickerResult | ImagePicker.ImagePickerErrorResult) => {
    if (!('canceled' in result) || result.canceled || !result.assets[0]?.uri) return;
    const photo = await createEvidencePhoto(result.assets[0].uri);
    await persistDraft({ ...draft, photos: [...draft.photos, photo], syncState: 'draft', errorMessage: undefined });
  }, [draft, persistDraft]);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', async (nextState) => {
      if (nextState !== 'active') return;
      const pending = await ImagePicker.getPendingResultAsync();
      if (pending) await handlePhotoResult(pending);
    });
    return () => subscription.remove();
  }, [handlePhotoResult]);

  const takeEvidence = async () => {
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (permission.status !== 'granted') {
        Alert.alert('Camera access needed', 'Allow camera access in Settings to capture evidence directly.');
        return;
      }
      const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [4, 3], quality: 0.9 });
      await handlePhotoResult(result);
    } catch {
      Alert.alert('Camera unavailable', 'Hypercube could not open the camera. Please choose an image from your library.');
    }
  };

  const pickEvidence = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: false,
        quality: 0.9,
        allowsMultipleSelection: true,
      });
      if (result.canceled) return;
      let nextDraft = draft;
      for (const asset of result.assets) {
        const photo = await createEvidencePhoto(asset.uri);
        nextDraft = { ...nextDraft, photos: [...nextDraft.photos, photo], syncState: 'draft', errorMessage: undefined };
      }
      await persistDraft(nextDraft);
    } catch {
      Alert.alert('Media unavailable', 'Hypercube could not open your photo library. Please try again.');
    }
  };

  const setEvidenceType = async (evidenceType: EvidenceType) => {
    await persistDraft({ ...draft, evidenceType, syncState: 'draft', errorMessage: undefined });
  };

  const setNote = (note: string) => setDraft((current) => ({ ...current, note, syncState: 'draft', errorMessage: undefined }));
  const persistNote = async () => {
    setSaveStatus('saving');
    try {
      await saveEvidenceDraft(draft);
      setSaveStatus('saved');
    } catch {
      setSaveStatus('error');
    }
  };

  const openReview = async () => {
    await persistNote();
    if (draft.photos.length === 0) {
      Alert.alert('Add a photo first', 'Capture or choose at least one evidence photo before opening review.');
      return;
    }
    router.push({ pathname: '/case/[caseId]/evidence-review', params: { caseId } });
  };

  if (isLoading) {
    return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="items-center justify-center"><Text style={styles.loading}>Loading local evidence draft…</Text></ScreenContainer>;
  }

  return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3"><ScrollView contentContainerStyle={{ paddingBottom: 28 }} keyboardShouldPersistTaps="handled">
    <View style={styles.header}><Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => router.back()} hitSlop={10}><Ionicons name="chevron-back" size={24} color={HC.text} /></Pressable><Text style={styles.title}>Add evidence</Text><Pressable accessibilityRole="button" accessibilityLabel="Open evidence drafts" onPress={() => router.push('/evidence-drafts')} hitSlop={10}><Ionicons name="folder-open-outline" size={22} color={HC.blue} /></Pressable></View>
    <Text style={styles.caseLabel}>CASE {caseId}</Text>
    <Panel style={styles.drop}>
      {draft.photos[0] ? <Image accessibilityLabel="First evidence photo" source={{ uri: draft.photos[0].uri }} style={styles.preview} /> : <View style={styles.dropIcon}><Ionicons name="camera-outline" size={26} color={HC.blue} /></View>}
      <Text style={styles.dropTitle}>{draft.photos.length ? `${draft.photos.length} evidence photo${draft.photos.length === 1 ? '' : 's'} selected` : 'Photo or video'}</Text>
      <Text style={styles.dropBody}>Capture details or choose several images from your library.</Text>
      <View style={styles.mediaActions}><Pressable accessibilityRole="button" accessibilityLabel="Take an evidence photo" onPress={takeEvidence} style={styles.choose}><Ionicons name="camera-outline" size={15} color={HC.cyan} /><Text style={styles.chooseText}>Take photo</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Choose evidence media from library" onPress={pickEvidence} style={styles.chooseSecondary}><Ionicons name="images-outline" size={15} color={HC.ink} /><Text style={styles.chooseSecondaryText}>Library</Text></Pressable></View>
    </Panel>
    <Text style={styles.label}>Evidence type</Text><View style={styles.typeRow}><Pressable accessibilityRole="button" accessibilityState={{ selected: draft.evidenceType === 'Product detail' }} onPress={() => void setEvidenceType('Product detail')} style={draft.evidenceType === 'Product detail' ? styles.typeActive : styles.type}><Ionicons name="cube-outline" size={18} color={draft.evidenceType === 'Product detail' ? HC.cyan : HC.muted} /><Text style={draft.evidenceType === 'Product detail' ? styles.typeActiveText : styles.typeText}>Product detail</Text></Pressable><Pressable accessibilityRole="button" accessibilityState={{ selected: draft.evidenceType === 'Document' }} onPress={() => void setEvidenceType('Document')} style={draft.evidenceType === 'Document' ? styles.typeActive : styles.type}><Ionicons name="document-text-outline" size={18} color={draft.evidenceType === 'Document' ? HC.cyan : HC.muted} /><Text style={draft.evidenceType === 'Document' ? styles.typeActiveText : styles.typeText}>Document</Text></Pressable></View>
    <Text style={styles.label}>Note</Text><TextInput value={draft.note} onChangeText={setNote} onBlur={persistNote} multiline placeholder="Describe what you found" placeholderTextColor={HC.muted} style={styles.input} returnKeyType="done" />
    <PrimaryButton label={draft.photos.length ? 'Review evidence' : 'Save draft'} icon={draft.photos.length ? 'images-outline' : 'checkmark'} onPress={() => void openReview()} />
    <View style={styles.saveStatusRow}><Text style={styles.localStatus}>{saveStatus === 'saving' ? 'Saving draft…' : saveStatus === 'error' ? 'Draft could not be saved' : 'Saved locally on this device'} · {draft.syncState === 'queued' ? 'Ready to sync' : 'Pending review'}</Text>{saveStatus === 'error' && <Pressable accessibilityRole="button" accessibilityLabel="Retry saving evidence draft" onPress={() => void persistNote()} style={({ pressed }) => [styles.retrySave, pressed && { opacity: 0.65 }]}><Ionicons name="refresh-outline" size={14} color={HC.blue} /><Text style={styles.retrySaveText}>Retry</Text></Pressable>}</View>
  </ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({ loading: { color: HC.muted, fontSize: 14 }, header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 26 }, title: { color: HC.text, fontSize: 18, fontWeight: '800' }, caseLabel: { color: HC.muted, fontSize: 11, fontWeight: '800', letterSpacing: 1.1, marginBottom: 12 }, drop: { alignItems: 'center', paddingVertical: 27, borderStyle: 'dashed' }, preview: { width: 180, height: 120, borderRadius: 16, marginBottom: 2 }, dropIcon: { width: 56, height: 56, borderRadius: 20, backgroundColor: '#EEF3FF', alignItems: 'center', justifyContent: 'center' }, dropTitle: { color: HC.text, fontSize: 16, fontWeight: '800', marginTop: 12 }, dropBody: { color: HC.muted, fontSize: 12, textAlign: 'center', marginTop: 5 }, mediaActions: { flexDirection: 'row', gap: 8, marginTop: 16 }, choose: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 13, paddingVertical: 10, borderRadius: 12, backgroundColor: HC.ink }, chooseSecondary: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 13, paddingVertical: 10, borderRadius: 12, backgroundColor: HC.cyan }, chooseText: { color: HC.cyan, fontSize: 12, fontWeight: '800' }, chooseSecondaryText: { color: HC.ink, fontSize: 12, fontWeight: '800' }, label: { color: HC.text, fontSize: 14, fontWeight: '800', marginTop: 24, marginBottom: 10 }, typeRow: { flexDirection: 'row', gap: 10 }, typeActive: { flex: 1, flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: 14, backgroundColor: HC.ink }, type: { flex: 1, flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: 14, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line }, typeActiveText: { color: HC.cyan, fontSize: 12, fontWeight: '800' }, typeText: { color: HC.muted, fontSize: 12, fontWeight: '800' }, input: { minHeight: 120, borderRadius: 16, borderWidth: 1, borderColor: HC.line, backgroundColor: HC.white, padding: 15, color: HC.text, textAlignVertical: 'top', fontSize: 14, marginBottom: 22 }, saveStatusRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 12 }, localStatus: { textAlign: 'center', color: HC.muted, fontSize: 11 }, retrySave: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 3 }, retrySaveText: { color: HC.blue, fontSize: 11, fontWeight: '800' }, });
