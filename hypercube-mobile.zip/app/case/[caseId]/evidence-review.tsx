import { useLocalSearchParams, useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/screen-container';
import { Panel, PrimaryButton, StatusPill } from '@/components/hypercube-ui';
import { ScreenState } from '@/components/ui/screen-state';
import { UI } from '@/constants/ui';
import { evidenceSyncTone } from '@/shared/status-tone';
import { HC } from '@/constants/hypercube';
import { createEvidencePhoto, deleteEvidencePhoto, loadEvidenceDraft, saveEvidenceDraft } from '@/lib/evidence-storage';
import { isEvidenceReadyForUpload, reorderEvidencePhotos, type EvidenceDraft, type EvidencePhoto } from '@/lib/evidence-model';

export default function EvidenceReviewScreen() {
  const router = useRouter();
  const { caseId: rawCaseId } = useLocalSearchParams<{ caseId?: string }>();
  const caseId = rawCaseId ?? 'HYP-1048';
  const [draft, setDraft] = useState<EvidenceDraft | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    let mounted = true;
    loadEvidenceDraft(caseId).then((saved) => {
      if (mounted) setDraft(saved);
    }).finally(() => {
      if (mounted) setLoading(false);
    });
    return () => {
      mounted = false;
    };
  }, [caseId]);

  const updateDraft = async (next: EvidenceDraft) => {
    setDraft(next);
    await saveEvidenceDraft(next);
  };

  const retakePhoto = async (photo: EvidencePhoto) => {
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (permission.status !== 'granted') {
        Alert.alert('Camera access needed', 'Allow camera access in Settings to retake this evidence photo.');
        return;
      }
      const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [4, 3], quality: 0.9 });
      if (!result.canceled && result.assets[0]?.uri && draft) {
        const replacement = await createEvidencePhoto(result.assets[0].uri);
        const photos = draft.photos.map((item) => item.id === photo.id ? replacement : item);
        await deleteEvidencePhoto(photo);
        await updateDraft({ ...draft, photos, syncState: 'draft', errorMessage: undefined });
      }
    } catch {
      Alert.alert('Retake unavailable', 'The camera could not be opened. Please try again.');
    }
  };

  const removePhoto = async (photo: EvidencePhoto) => {
    if (!draft) return;
    await deleteEvidencePhoto(photo);
    await updateDraft({ ...draft, photos: draft.photos.filter((item) => item.id !== photo.id), syncState: 'draft', errorMessage: undefined });
  };

  const movePhoto = async (index: number, offset: -1 | 1) => {
    if (!draft) return;
    const nextIndex = index + offset;
    await updateDraft({ ...draft, photos: reorderEvidencePhotos(draft.photos, index, nextIndex), syncState: 'draft', errorMessage: undefined });
  };

  const uploadDraft = async () => {
    if (!draft || !isEvidenceReadyForUpload(draft)) {
      Alert.alert('Evidence is incomplete', 'Add at least one photo and a note before uploading.');
      return;
    }
    setUploading(true);
    let progress = 0;
    await updateDraft({ ...draft, syncState: 'uploading', uploadProgress: 0, errorMessage: undefined });
    await new Promise<void>((resolve) => {
      const timer = setInterval(() => {
        progress += 20;
        setDraft((current) => current ? { ...current, uploadProgress: progress } : current);
        if (progress >= 100) {
          clearInterval(timer);
          resolve();
        }
      }, 180);
    });
    try {
      const latest = await loadEvidenceDraft(caseId);
      if (!latest) throw new Error('Draft was removed before upload completed.');
      await updateDraft({ ...latest, syncState: 'queued', uploadProgress: 100, errorMessage: undefined });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Upload failed. Try again.';
      const failed = { ...draft, syncState: 'failed' as const, uploadProgress: 0, errorMessage: message };
      setDraft(failed);
      await saveEvidenceDraft(failed);
    } finally {
      setUploading(false);
    }
  };

  if (loading) return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5"><ScreenState kind="loading" title="Loading local evidence" description="Restoring the saved evidence draft from this device." /></ScreenContainer>;
  if (!draft) return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5"><ScreenState kind="error" title="No local draft found" description="This evidence draft is no longer available on this device." actionLabel="Back to case" onAction={() => router.back()} /></ScreenContainer>;

  const statusLabel = draft.syncState === 'queued' ? 'Ready to sync' : draft.syncState === 'failed' ? 'Upload failed' : draft.syncState === 'uploading' ? 'Uploading' : 'Local draft';
  return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3"><FlatList
    data={draft.photos}
    keyExtractor={(item) => item.id}
    showsVerticalScrollIndicator={false}
    contentContainerStyle={{ paddingBottom: UI.spacing.xxl }}
    ListHeaderComponent={<View><View style={styles.header}><Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => router.back()} hitSlop={10}><Ionicons name="chevron-back" size={24} color={HC.text} /></Pressable><Text style={styles.title}>Review evidence</Text><View style={{ width: 24 }} /></View><View style={styles.metaRow}><Text style={styles.caseLabel}>CASE {caseId}</Text><StatusPill label={statusLabel} tone={evidenceSyncTone(draft.syncState)} /></View><Panel style={styles.notePanel}><Text style={styles.noteLabel}>{draft.evidenceType.toUpperCase()}</Text><Text style={styles.note}>{draft.note || 'No note added yet.'}</Text></Panel><Text style={styles.sectionTitle}>Photos · {draft.photos.length}</Text></View>}
    renderItem={({ item, index }) => <PhotoRow photo={item} index={index} total={draft.photos.length} onRetake={() => void retakePhoto(item)} onRemove={() => void removePhoto(item)} onMove={(offset) => void movePhoto(index, offset)} />}
    ListEmptyComponent={<Panel style={styles.empty}><Ionicons name="images-outline" size={28} color={HC.blue} /><Text style={styles.emptyTitle}>No photos yet</Text><Text style={styles.muted}>Return to Add Evidence to capture or choose a photo.</Text></Panel>}
    ListFooterComponent={<View style={styles.footer}>{draft.syncState === 'uploading' ? <View style={styles.progressPanel}><View style={styles.progressHeader}><Text style={styles.progressTitle}>Preparing evidence</Text><Text style={styles.progressValue}>{draft.uploadProgress}%</Text></View><View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${draft.uploadProgress}%` }]} /></View><ActivityIndicator color={HC.blue} style={styles.spinner} /></View> : draft.syncState === 'failed' ? <View style={styles.retryPanel}><Ionicons name="cloud-offline-outline" size={22} color={HC.danger} /><View style={{ flex: 1 }}><Text style={styles.retryTitle}>Upload failed</Text><Text style={styles.muted}>{draft.errorMessage ?? 'The evidence remains safely stored on this device.'}</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Retry evidence upload" onPress={() => void uploadDraft()} style={styles.retryButton}><Text style={styles.retryText}>Retry</Text></Pressable></View> : <PrimaryButton label={draft.syncState === 'queued' ? 'Queued for sync' : 'Upload evidence'} icon={draft.syncState === 'queued' ? 'checkmark-circle' : 'cloud-upload-outline'} onPress={() => void uploadDraft()} disabled={uploading || draft.syncState === 'queued'} />}</View>}
  /></ScreenContainer>;
}

function PhotoRow({ photo, index, total, onRetake, onRemove, onMove }: { photo: EvidencePhoto; index: number; total: number; onRetake: () => void; onRemove: () => void; onMove: (offset: -1 | 1) => void }) {
  return <Panel style={styles.photoCard}><Image accessibilityLabel={`Evidence photo ${index + 1}`} source={{ uri: photo.uri }} style={styles.photo} /><View style={styles.photoBody}><Text style={styles.photoTitle}>Photo {index + 1}</Text><Text style={styles.muted}>Evidence detail</Text><View style={styles.photoActions}><Pressable accessibilityRole="button" accessibilityLabel={`Move photo ${index + 1} earlier`} disabled={index === 0} onPress={() => onMove(-1)} style={styles.iconAction}><Ionicons name="arrow-up" size={15} color={index === 0 ? HC.line : HC.blue} /></Pressable><Pressable accessibilityRole="button" accessibilityLabel={`Move photo ${index + 1} later`} disabled={index === total - 1} onPress={() => onMove(1)} style={styles.iconAction}><Ionicons name="arrow-down" size={15} color={index === total - 1 ? HC.line : HC.blue} /></Pressable><Pressable accessibilityRole="button" accessibilityLabel={`Retake photo ${index + 1}`} onPress={onRetake} style={styles.textAction}><Text style={styles.actionText}>Retake</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={`Remove photo ${index + 1}`} onPress={onRemove} style={styles.textAction}><Text style={styles.removeText}>Remove</Text></Pressable></View></View></Panel>;
}

const styles = StyleSheet.create({ header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: UI.spacing.xl }, title: { color: HC.text, fontSize: 20, fontWeight: '800' }, metaRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, caseLabel: { color: HC.muted, fontSize: 11, fontWeight: '800', letterSpacing: 1.1 }, notePanel: { marginTop: UI.spacing.lg, marginBottom: UI.spacing.xl }, noteLabel: { color: HC.blue, fontSize: 10, letterSpacing: 1.1, fontWeight: '800' }, note: { color: HC.text, fontSize: 15, lineHeight: 21, marginTop: 8 }, sectionTitle: { color: HC.text, fontSize: 18, fontWeight: '800', marginBottom: 10 }, photoCard: { flexDirection: 'row', gap: 12, marginBottom: 10 }, photo: { width: 92, height: 92, borderRadius: 14, backgroundColor: '#EEF3FF' }, photoBody: { flex: 1, justifyContent: 'center' }, photoTitle: { color: HC.text, fontSize: 14, fontWeight: '800' }, muted: { color: HC.muted, fontSize: 12, lineHeight: 18 }, photoActions: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10 }, iconAction: { width: 28, height: 28, alignItems: 'center', justifyContent: 'center', borderRadius: 9, backgroundColor: '#EEF3FF' }, textAction: { paddingHorizontal: 5, paddingVertical: 6 }, actionText: { color: HC.blue, fontSize: 11, fontWeight: '800' }, removeText: { color: HC.danger, fontSize: 11, fontWeight: '800' }, footer: { marginTop: UI.spacing.md }, progressPanel: { backgroundColor: HC.white, borderRadius: 18, padding: 16, borderWidth: 1, borderColor: HC.line }, progressHeader: { flexDirection: 'row', justifyContent: 'space-between' }, progressTitle: { color: HC.text, fontSize: 13, fontWeight: '800' }, progressValue: { color: HC.blue, fontSize: 13, fontWeight: '800' }, progressTrack: { height: 8, borderRadius: 4, backgroundColor: '#E8EEF6', overflow: 'hidden', marginTop: 12 }, progressFill: { height: '100%', borderRadius: 4, backgroundColor: HC.cyan }, spinner: { alignSelf: 'flex-start', marginTop: 12 }, retryPanel: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#FFF4F4', borderWidth: 1, borderColor: '#FFD9D9', borderRadius: 18, padding: 15 }, retryTitle: { color: HC.danger, fontSize: 13, fontWeight: '800', marginBottom: 2 }, retryButton: { paddingHorizontal: 13, paddingVertical: 9, backgroundColor: HC.danger, borderRadius: 11 }, retryText: { color: HC.white, fontSize: 12, fontWeight: '800' }, empty: { alignItems: 'center', paddingVertical: UI.spacing.xxl }, emptyTitle: { color: HC.text, fontWeight: '800', marginTop: 8 }, });
