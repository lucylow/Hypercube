import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Network from 'expo-network';
import { ScreenContainer } from '@/components/screen-container';
import { Panel } from '@/components/hypercube-ui';
import { ScreenState } from '@/components/ui/screen-state';
import { HC } from '@/constants/hypercube';
import { UI } from '@/constants/ui';
import { clearEvidenceDraft, listEvidenceDrafts, saveEvidenceDraft } from '@/lib/evidence-storage';
import { exportEvidenceDraftsCsv, exportEvidenceDraftsJson } from '@/lib/evidence-export';
import type { EvidenceDraft, EvidenceSyncState } from '@/lib/evidence-model';
import { classifyEvidenceSyncError, evidenceSyncErrorLabel } from '@/shared/evidence-sync';
import { syncQueuedEvidenceDrafts } from '@/lib/evidence-background';

export default function EvidenceDraftsScreen() {
  const router = useRouter();
  const [drafts, setDrafts] = useState<EvidenceDraft[]>([]);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'all' | EvidenceSyncState>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState<'json' | 'csv' | null>(null);
  const [syncing, setSyncing] = useState(false);
  const network = Network.useNetworkState();

  const load = useCallback(() => {
    setLoading(true);
    void listEvidenceDrafts().then(setDrafts).finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const syncSummary = useMemo(() => ({
    failed: drafts.filter((draft) => draft.syncState === 'failed').length,
    ready: drafts.filter((draft) => draft.syncState === 'queued').length,
    synced: drafts.filter((draft) => draft.syncState === 'synced').length,
  }), [drafts]);

  const visible = useMemo(() => drafts.filter((draft) => (
    (filter === 'all' || draft.syncState === filter) &&
    `${draft.caseId} ${draft.evidenceType} ${draft.note}`.toLowerCase().includes(query.toLowerCase().trim())
  )), [drafts, filter, query]);

  const toggleVisibleSelection = useCallback(() => {
    const visibleIds = visible.map((draft) => draft.caseId);
    const allVisibleSelected = visibleIds.length > 0 && visibleIds.every((id) => selectedIds.includes(id));
    setSelectedIds((current) => allVisibleSelected
      ? current.filter((id) => !visibleIds.includes(id))
      : Array.from(new Set([...current, ...visibleIds])));
  }, [selectedIds, visible]);

  const toggleSelection = useCallback((caseId: string) => {
    setSelectedIds((current) => current.includes(caseId)
      ? current.filter((id) => id !== caseId)
      : [...current, caseId]);
  }, []);

  const queueDraft = useCallback(async (draft: EvidenceDraft) => {
    const attemptAt = new Date().toISOString();
    const next = { ...draft, syncState: 'queued' as const, errorMessage: undefined, updatedAt: attemptAt, lastAttemptAt: attemptAt };
    await saveEvidenceDraft(next);
    setDrafts((current) => current.map((item) => item.caseId === draft.caseId ? next : item));
  }, []);

  const exportSelected = useCallback(async (format: 'json' | 'csv') => {
    const selected = drafts.filter((draft) => selectedIds.includes(draft.caseId));
    if (!selected.length) return;
    setExporting(format);
    try {
      const result = format === 'json' ? await exportEvidenceDraftsJson(selected, 'selected') : await exportEvidenceDraftsCsv(selected, 'selected');
      if (result === 'unavailable') Alert.alert('Export unavailable', 'Sharing is not available on this device or browser.');
    } catch {
      Alert.alert('Export failed', 'Could not create the selected evidence handoff. Please try again.');
    } finally {
      setExporting(null);
    }
  }, [drafts, selectedIds]);

  const syncNow = useCallback(async () => {
    setSyncing(true);
    try {
      const result = await syncQueuedEvidenceDrafts();
      await new Promise<void>((resolve) => { load(); setTimeout(resolve, 180); });
      if (result === 'offline') Alert.alert('Waiting for connection', 'No internet connection is reachable. The background worker will retry when connectivity returns.');
      else if (result === 'failed') Alert.alert('Some drafts need attention', 'One or more drafts could not sync. Review their recovery guidance and retry when ready.');
      else if (result === 'synced') Alert.alert('Sync complete', 'Queued evidence drafts were handed off successfully.');
      else Alert.alert('Nothing to sync', 'There are no queued or failed drafts waiting for handoff.');
    } catch {
      Alert.alert('Sync unavailable', 'The sync worker could not start. Your local drafts are safe and will remain available.');
    } finally {
      setSyncing(false);
    }
  }, [load]);

  const queueSelected = useCallback(() => {
    const selected = drafts.filter((draft) => selectedIds.includes(draft.caseId) && draft.syncState !== 'queued' && draft.syncState !== 'synced');
    void Promise.all(selected.map(queueDraft)).then(() => setSelectedIds([]));
  }, [drafts, queueDraft, selectedIds]);

  const discardSelected = useCallback(() => {
    if (!selectedIds.length) return;
    Alert.alert('Discard selected drafts?', `Remove ${selectedIds.length} unfinished evidence draft${selectedIds.length === 1 ? '' : 's'}?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Discard', style: 'destructive', onPress: () => {
        void Promise.all(selectedIds.map((id) => clearEvidenceDraft(id))).then(() => {
          setDrafts((current) => current.filter((draft) => !selectedIds.includes(draft.caseId)));
          setSelectedIds([]);
        });
      } },
    ]);
  }, [selectedIds]);

  const discard = useCallback((draft: EvidenceDraft) => {
    Alert.alert('Discard evidence draft?', `Remove the unfinished draft for case ${draft.caseId}?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Discard', style: 'destructive', onPress: () => {
        void clearEvidenceDraft(draft.caseId).then(() => {
          setDrafts((current) => current.filter((item) => item.caseId !== draft.caseId));
          setSelectedIds((current) => current.filter((id) => id !== draft.caseId));
        });
      } },
    ]);
  }, []);

  if (loading) return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5"><ScreenState kind="loading" title="Loading evidence drafts" description="Restoring unfinished local submissions." /></ScreenContainer>;

  return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3"><FlatList
    data={visible}
    keyExtractor={(item) => item.caseId}
    contentContainerStyle={styles.content}
    ListHeaderComponent={<View>
      <View style={styles.header}><View><Text style={styles.eyebrow}>LOCAL WORKSPACE</Text><Text style={styles.title}>Evidence drafts</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => router.back()} hitSlop={UI.control.hitSlop}><Ionicons name="close" size={24} color={HC.text} /></Pressable></View>
      <View style={styles.search}><Ionicons name="search-outline" size={18} color={HC.muted} /><TextInput accessibilityLabel="Search evidence drafts" value={query} onChangeText={setQuery} placeholder="Search case, type, or note" placeholderTextColor={HC.muted} style={styles.input} /></View><View style={styles.syncPanel}><View style={styles.syncCopy}><Text style={styles.syncTitle}>Sync health</Text><Text style={styles.syncMeta}>{network.isInternetReachable ? 'Internet reachable' : network.isConnected ? 'Connected, internet unconfirmed' : 'Offline — local drafts are safe'}</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Sync evidence drafts now" accessibilityState={{ busy: syncing, disabled: syncing }} disabled={syncing} onPress={() => void syncNow()} style={styles.syncButton}><Ionicons name={syncing ? 'hourglass-outline' : 'refresh-outline'} size={15} color={HC.cyan} /><Text style={styles.syncButtonText}>{syncing ? 'Syncing…' : 'Sync now'}</Text></Pressable></View>
      <View style={styles.filters}>{(['all', 'draft', 'failed', 'queued', 'uploading', 'synced'] as const).map((value) => <Pressable key={value} accessibilityRole="button" accessibilityState={{ selected: filter === value }} accessibilityLabel={`Filter drafts by ${value}`} onPress={() => setFilter(value)} style={filter === value ? styles.filterActive : styles.filter}><Text style={filter === value ? styles.filterActiveText : styles.filterText}>{value === 'all' ? 'All' : value === 'draft' ? 'Draft' : value === 'failed' ? 'Failed' : value === 'queued' ? 'Ready' : value === 'uploading' ? 'Uploading' : 'Synced'}</Text></Pressable>)}</View>
      <View style={styles.manageRow}><Pressable accessibilityRole="button" accessibilityLabel="Select all visible evidence drafts" onPress={toggleVisibleSelection} style={styles.manageButton}><Ionicons name="checkmark-done-outline" size={15} color={HC.blue} /><Text style={styles.manageText}>Select visible</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Clear selected evidence drafts" onPress={() => setSelectedIds([])} style={styles.manageButton}><Ionicons name="close-circle-outline" size={15} color={HC.muted} /><Text style={styles.manageMuted}>Clear</Text></Pressable>{selectedIds.length > 0 && <Pressable accessibilityRole="button" accessibilityLabel="Queue selected evidence drafts for sync" onPress={queueSelected} style={styles.manageButton}><Ionicons name="cloud-upload-outline" size={15} color={HC.blue} /><Text style={styles.manageText}>Queue sync</Text></Pressable>}{selectedIds.length > 0 && <Pressable accessibilityRole="button" accessibilityLabel="Export selected evidence drafts as JSON" disabled={Boolean(exporting)} onPress={() => void exportSelected('json')} style={styles.manageButton}><Ionicons name="document-text-outline" size={15} color={HC.blue} /><Text style={styles.manageText}>{exporting === 'json' ? 'Exporting…' : 'JSON'}</Text></Pressable>}{selectedIds.length > 0 && <Pressable accessibilityRole="button" accessibilityLabel="Export selected evidence drafts as CSV" disabled={Boolean(exporting)} onPress={() => void exportSelected('csv')} style={styles.manageButton}><Ionicons name="grid-outline" size={15} color={HC.blue} /><Text style={styles.manageText}>{exporting === 'csv' ? 'Exporting…' : 'CSV'}</Text></Pressable>}{selectedIds.length > 0 && <Pressable accessibilityRole="button" accessibilityLabel="Discard selected evidence drafts" onPress={discardSelected} style={styles.manageDanger}><Ionicons name="trash-outline" size={15} color={HC.danger} /><Text style={styles.manageDangerText}>Discard {selectedIds.length}</Text></Pressable>}</View>
      <View style={styles.summaryRow}><View style={styles.summary}><Text style={styles.summaryValue}>{syncSummary.failed}</Text><Text style={styles.summaryLabel}>Needs attention</Text></View><View style={styles.summary}><Text style={styles.summaryValue}>{syncSummary.ready}</Text><Text style={styles.summaryLabel}>Ready to sync</Text></View><View style={styles.summary}><Text style={styles.summaryValue}>{syncSummary.synced}</Text><Text style={styles.summaryLabel}>Synced</Text></View></View><Text style={styles.count}>{visible.length} matching draft{visible.length === 1 ? '' : 's'}</Text>
    </View>}
    renderItem={({ item }) => <Panel style={selectedIds.includes(item.caseId) ? styles.cardSelected : styles.card}>
      <View style={styles.row}><Pressable accessibilityRole="checkbox" accessibilityState={{ checked: selectedIds.includes(item.caseId) }} accessibilityLabel={`Select evidence draft ${item.caseId}`} onPress={() => toggleSelection(item.caseId)} style={selectedIds.includes(item.caseId) ? styles.checkSelected : styles.check}><Ionicons name={selectedIds.includes(item.caseId) ? 'checkmark' : 'ellipse-outline'} size={17} color={selectedIds.includes(item.caseId) ? HC.cyan : HC.muted} /></Pressable><View style={styles.icon}><Ionicons name="images-outline" size={19} color={HC.blue} /></View><View style={styles.copy}><Text style={styles.case}>CASE {item.caseId}</Text><Text style={styles.meta}>{item.photos.length} photo{item.photos.length === 1 ? '' : 's'} · {item.evidenceType} · Updated {new Date(item.updatedAt).toLocaleString()}</Text>{item.lastAttemptAt && <Text style={styles.attempt}>Last sync attempt {new Date(item.lastAttemptAt).toLocaleString()}</Text>}{item.lastReceiptId && <Text style={styles.receipt}>Receipt {item.lastReceiptId}</Text>}{item.syncHistory?.length ? <Text style={styles.history}>{item.syncHistory[item.syncHistory.length - 1].message}</Text> : null}{item.syncState === 'uploading' && <View accessibilityRole="progressbar" accessibilityLabel={`Sync progress ${item.syncProgress ?? 0} percent`} style={styles.progressTrack}><View style={[styles.progressFill, { width: `${item.syncProgress ?? 0}%` }]} /></View>}{item.errorMessage && <Text accessibilityRole="alert" style={styles.error}>{evidenceSyncErrorLabel(classifyEvidenceSyncError(item.errorMessage))}: {item.errorMessage}</Text>}{item.recoveryHint && <Text style={styles.recovery}>{item.recoveryHint}</Text>}{item.note.trim() ? <Text numberOfLines={2} style={styles.note}>{item.note}</Text> : <Text style={styles.noteMuted}>No note added yet</Text>}</View></View>
      <View style={styles.actions}><Pressable accessibilityRole="button" accessibilityLabel={`View sync history for ${item.caseId}`} onPress={() => router.push({ pathname: '/evidence-drafts/[caseId]', params: { caseId: item.caseId } })} style={styles.historyButton}><Ionicons name="list-outline" size={15} color={HC.blue} /><Text style={styles.historyButtonText}>History</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={`Resume evidence draft for ${item.caseId}`} onPress={() => router.push({ pathname: '/case/[caseId]/add-evidence', params: { caseId: item.caseId } })} style={styles.resume}><Ionicons name="arrow-forward-outline" size={15} color={HC.cyan} /><Text style={styles.resumeText}>Resume</Text></Pressable>{item.syncState !== 'queued' && item.syncState !== 'synced' && <Pressable accessibilityRole="button" accessibilityLabel={`Queue evidence draft ${item.caseId} for sync`} onPress={() => void queueDraft(item)} style={styles.queue}><Ionicons name="cloud-upload-outline" size={15} color={HC.blue} /><Text style={styles.queueText}>Queue</Text></Pressable>}<Pressable accessibilityRole="button" accessibilityLabel={`Discard evidence draft for ${item.caseId}`} onPress={() => discard(item)} style={styles.discard}><Ionicons name="trash-outline" size={15} color={HC.danger} /><Text style={styles.discardText}>Discard</Text></Pressable></View>
    </Panel>}
    ListEmptyComponent={<ScreenState kind="empty" title={drafts.length ? 'No matching drafts' : 'No unfinished drafts'} description={drafts.length ? 'Try another case, evidence type, or note.' : 'Evidence drafts saved on this device will appear here.'} />}
  /></ScreenContainer>;
}

const styles = StyleSheet.create({ content: { paddingBottom: UI.spacing.xxl }, header: { marginBottom: UI.spacing.md }, eyebrow: { color: HC.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.1 }, title: { color: HC.text, fontSize: 27, fontWeight: '800', marginTop: 5 }, search: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line, borderRadius: UI.radius.md, paddingHorizontal: 13, minHeight: 48, marginTop: UI.spacing.md }, filters: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: UI.spacing.md }, summaryRow: { flexDirection: 'row', gap: 8, marginTop: UI.spacing.md }, summary: { flex: 1, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line, borderRadius: UI.radius.sm, paddingVertical: 8, paddingHorizontal: 9 }, summaryValue: { color: HC.text, fontSize: 15, fontWeight: '800' }, summaryLabel: { color: HC.muted, fontSize: 10, marginTop: 2 }, syncPanel: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: UI.spacing.sm, backgroundColor: '#EAFBF8', borderWidth: 1, borderColor: '#BDEDE5', borderRadius: UI.radius.md, padding: UI.spacing.sm, marginTop: UI.spacing.md }, syncCopy: { flex: 1 }, syncTitle: { color: HC.text, fontSize: 12, fontWeight: '800' }, syncMeta: { color: HC.muted, fontSize: 10, marginTop: 3 }, syncButton: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: HC.ink, borderRadius: UI.radius.sm, paddingHorizontal: 10, paddingVertical: 8 }, syncButtonText: { color: HC.cyan, fontSize: 11, fontWeight: '800' }, manageRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: UI.spacing.md }, manageButton: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 6, paddingHorizontal: 8, borderRadius: 9, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line }, manageText: { color: HC.blue, fontSize: 11, fontWeight: '800' }, manageMuted: { color: HC.muted, fontSize: 11, fontWeight: '800' }, manageDanger: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 6, paddingHorizontal: 8, borderRadius: 9, backgroundColor: '#FFF0F0' }, manageDangerText: { color: HC.danger, fontSize: 11, fontWeight: '800' }, filter: { paddingHorizontal: 11, paddingVertical: 7, borderRadius: 99, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line }, filterActive: { paddingHorizontal: 11, paddingVertical: 7, borderRadius: 99, backgroundColor: HC.ink }, filterText: { color: HC.muted, fontSize: 11, fontWeight: '800' }, filterActiveText: { color: HC.cyan, fontSize: 11, fontWeight: '800' }, input: { flex: 1, color: HC.text, fontSize: 14 }, count: { color: HC.muted, fontSize: 12, fontWeight: '700', marginTop: UI.spacing.md }, card: { marginTop: UI.spacing.sm }, cardSelected: { marginTop: UI.spacing.sm, borderColor: HC.blue, borderWidth: 1.5 }, row: { flexDirection: 'row', gap: UI.spacing.sm, alignItems: 'center' }, check: { width: 22, height: 22, alignItems: 'center', justifyContent: 'center' }, checkSelected: { width: 22, height: 22, borderRadius: 7, backgroundColor: HC.ink, alignItems: 'center', justifyContent: 'center' }, icon: { width: 40, height: 40, borderRadius: UI.radius.sm, backgroundColor: '#EEF3FF', alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1 }, case: { color: HC.text, fontSize: 14, fontWeight: '800' }, meta: { color: HC.muted, fontSize: 11, marginTop: 4 }, attempt: { color: HC.blue, fontSize: 10, marginTop: 3 }, receipt: { color: HC.muted, fontSize: 10, marginTop: 2 }, history: { color: HC.muted, fontSize: 10, marginTop: 2 }, progressTrack: { height: 5, backgroundColor: '#DDE5F2', borderRadius: 99, marginTop: 7, overflow: 'hidden' }, progressFill: { height: 5, backgroundColor: HC.blue, borderRadius: 99 }, error: { color: HC.danger, fontSize: 10, fontWeight: '700', marginTop: 3 }, recovery: { color: '#8A5A00', fontSize: 10, marginTop: 3, lineHeight: 14 }, note: { color: HC.text, fontSize: 12, lineHeight: 17, marginTop: 8 }, noteMuted: { color: HC.muted, fontSize: 12, marginTop: 8, fontStyle: 'italic' }, actions: { flexDirection: 'row', gap: UI.spacing.sm, marginTop: UI.spacing.md, paddingTop: UI.spacing.sm, borderTopWidth: 1, borderTopColor: HC.line }, historyButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: '#EEF3FF', borderRadius: UI.radius.sm, paddingVertical: 9 }, historyButtonText: { color: HC.blue, fontSize: 12, fontWeight: '800' }, resume: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: HC.ink, borderRadius: UI.radius.sm, paddingVertical: 9 }, resumeText: { color: HC.cyan, fontSize: 12, fontWeight: '800' }, queue: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: '#EEF3FF', borderRadius: UI.radius.sm, paddingVertical: 9 }, queueText: { color: HC.blue, fontSize: 12, fontWeight: '800' }, discard: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: '#FFF0F0', borderRadius: UI.radius.sm, paddingVertical: 9 }, discardText: { color: HC.danger, fontSize: 12, fontWeight: '800' }, });
