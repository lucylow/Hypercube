import { useRouter, useLocalSearchParams } from 'expo-router';
import * as FileSystem from 'expo-file-system/legacy';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Animated, Easing, Platform, Pressable, ScrollView, Share, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/screen-container';
import { Panel, SectionTitle, StatusPill } from '@/components/hypercube-ui';
import { EvidenceQualityPanels, NextEvidencePanel, SignalRow } from '@/components/analysis-result-panels';
import { AnalysisActionFooter, AnalysisFeedbackPanel } from '@/components/analysis-result-actions';
import { AnalysisErrorPanel, AnalysisLoadingState, AnalysisResultHeader } from '@/components/analysis-result-chrome';
import { HC } from '@/constants/hypercube';
import { trpc } from '@/lib/trpc';
import { saveAnalysisRecord } from '@/lib/analysis-storage';
import { exportAnalysisRecord } from '@/lib/analysis-export';
import { createAnalysisRecord, type AnalysisRecord } from '@/shared/ai-history';
import { fallbackAuthenticityAnalysis, type AnalysisFeedback, type AnalysisFocus, type AuthenticityAnalysis, type EvidenceReviewMetadata } from '@/shared/ai';
import { createAnalysisViewModel } from '@/shared/analysis-view-model';

function parseReviewMetadata(serialized?: string): EvidenceReviewMetadata | undefined {
  if (!serialized) return undefined;
  try {
    const parsed = JSON.parse(serialized);
    if (!parsed || typeof parsed !== 'object' || typeof parsed.reviewStartedAt !== 'string') return undefined;
    return parsed as EvidenceReviewMetadata;
  } catch {
    return undefined;
  }
}

function parsePhotoUris(serialized?: string, fallback?: string): string[] {
  if (serialized) {
    try {
      const parsed = JSON.parse(serialized);
      if (Array.isArray(parsed)) return parsed.filter((item): item is string => typeof item === 'string' && item.length > 0).slice(0, 4);
    } catch {
      // Keep the primary route photo when an older or malformed route is received.
    }
  }
  return fallback ? [fallback] : [];
}

async function toImageDataUrl(uri?: string): Promise<string | undefined> {
  if (!uri) return undefined;
  if (uri.startsWith('data:')) return uri;
  if (Platform.OS === 'web') return undefined;
  const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
  return `data:image/jpeg;base64,${base64}`;
}

export default function ScanResultScreen() {
  const router = useRouter();
  const { code, photoUri, photoUris: photoUrisParam, referenceUris: referenceUrisParam, reviewMetadata: reviewMetadataParam, focus: focusParam } = useLocalSearchParams<{ code?: string; photoUri?: string; photoUris?: string; referenceUris?: string; reviewMetadata?: string; focus?: string }>();
  const photoUris = useMemo(() => parsePhotoUris(photoUrisParam, photoUri), [photoUrisParam, photoUri]);
  const referenceUris = useMemo(() => parsePhotoUris(referenceUrisParam), [referenceUrisParam]);
  const reviewMetadata = useMemo(() => parseReviewMetadata(reviewMetadataParam), [reviewMetadataParam]);
  const initialFocus: AnalysisFocus = focusOptions.some((option) => option.key === focusParam) ? focusParam as AnalysisFocus : 'overall';
  const [analysis, setAnalysis] = useState<AuthenticityAnalysis | null>(null);
  const [isProvisional, setIsProvisional] = useState(false);
  const [focus, setFocus] = useState<AnalysisFocus>(initialFocus);
  const [feedback, setFeedback] = useState<AnalysisFeedback | null>(null);
  const [retryToken, setRetryToken] = useState(0);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const pulse = useRef(new Animated.Value(0)).current;
  const currentRecordRef = useRef<AnalysisRecord | null>(null);
  const analyzeMutation = trpc.ai.analyzeAuthenticity.useMutation();
  const analyzeRef = useRef(analyzeMutation.mutateAsync);
  analyzeRef.current = analyzeMutation.mutateAsync;

  useEffect(() => {
    let active = true;
    setIsProvisional(true);
    setAnalysisError(null);
    const pulseLoop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: 900, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
    ]));
    pulseLoop.start();
    const provisional = fallbackAuthenticityAnalysis({ model: 'local-review', usedVision: photoUris.length > 0, focus, reason: 'Generating a cautious provisional review while the AI service checks the evidence.' });
    setAnalysis({ ...provisional, fallback: false, summary: 'Provisional review while Hypercube compares the evidence.', signals: [{ title: 'AI analysis in progress', status: 'neutral', explanation: 'The model is checking the available scan context and product evidence.' }, { title: 'Evidence preserved', status: 'positive', explanation: 'Your scan metadata and attached photos remain available for investigator review.' }] });
    const run = async () => {
      try {
        const imageDataUrls = (await Promise.all(photoUris.map((uri) => toImageDataUrl(uri)))).filter((value): value is string => Boolean(value));
        const referenceImageDataUrls = (await Promise.all(referenceUris.map((uri) => toImageDataUrl(uri)))).filter((value): value is string => Boolean(value));
        const result = await Promise.race([
          analyzeRef.current({ productName: 'Scanned product', code, evidenceType: photoUris.length > 1 ? 'Product evidence set' : photoUris.length === 1 ? 'Product photo' : 'QR or barcode', imageDataUrl: imageDataUrls[0], imageDataUrls: imageDataUrls.slice(1), referenceImageDataUrls, reviewMetadata, focus, feedback: feedback ?? undefined }),
          new Promise<never>((_, reject) => setTimeout(() => reject(new Error('AI analysis timed out.')), 15000)),
        ]);
        if (active) {
          setIsProvisional(false);
          setAnalysis(result);
          const record = createAnalysisRecord({ code, focus, analysis: result });
          currentRecordRef.current = record;
          void saveAnalysisRecord(record);
        }
      } catch (error) {
        if (active) {
          setIsProvisional(false);
          setAnalysisError(error instanceof Error ? error.message : 'The AI analysis could not be reached.');
          const fallback = fallbackAuthenticityAnalysis({ model: 'local-fallback', usedVision: photoUris.length > 0, focus, reason: error instanceof Error ? error.message : 'The AI analysis could not be reached.' });
          setAnalysis(fallback);
          const record = createAnalysisRecord({ code, focus, analysis: fallback });
          currentRecordRef.current = record;
          void saveAnalysisRecord(record);
        }
      }
    };
    void run();
    return () => {
      active = false;
      pulseLoop.stop();
      pulse.setValue(0);
    };
  }, [code, feedback, focus, photoUris, referenceUris, reviewMetadata, retryToken, pulse]);

  const shareResult = () => {
    if (!analysis) return;
    void Share.share({ message: `Hypercube scan result: ${analysis.verdict.replace('_', ' ')} — confidence ${analysis.confidence}%. ${analysis.summary}` });
  };

  const saveCurrentAnalysis = () => {
    if (!analysis) return;
    const record = currentRecordRef.current ?? createAnalysisRecord({ code, focus, analysis });
    currentRecordRef.current = record;
    void saveAnalysisRecord(record);
    Alert.alert('Analysis saved', 'This AI review is available in local analysis history.');
  };

  const exportCurrentAnalysis = async () => {
    if (!analysis || exporting) return;
    setExporting(true);
    try {
      const record = currentRecordRef.current ?? createAnalysisRecord({ code, focus, analysis });
      currentRecordRef.current = record;
      const result = await exportAnalysisRecord(record);
      if (result === 'shared') Alert.alert('Export ready', 'Choose an app to receive the Hypercube analysis JSON.');
      else if (result === 'downloaded') Alert.alert('Export downloaded', 'The analysis JSON was downloaded to your device.');
      else Alert.alert('Export unavailable', 'This platform cannot open a file share action right now. Save the analysis locally instead.');
    } catch {
      Alert.alert('Export failed', 'Hypercube could not prepare the analysis file. Please try again.');
    } finally {
      setExporting(false);
    }
  };

  const viewModel = analysis ? createAnalysisViewModel({ analysis, focus, isProvisional, feedback, hasError: Boolean(analysisError) }) : null;

  return <ScreenContainer containerClassName="bg-[#EEF3F8]" className="px-5 pt-3"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
    <AnalysisResultHeader onBack={() => router.back()} onShare={shareResult} />
    {!analysis ? <AnalysisLoadingState /> : <>
      <Panel dark style={styles.resultHero}><Animated.View style={[styles.loadingPulse, { opacity: pulse }]} /><View style={[styles.ring, { borderColor: viewModel?.verdict.tone === 'success' ? HC.success : viewModel?.verdict.tone === 'danger' ? HC.danger : HC.warning }]}><Text style={styles.score}>{analysis.confidence}%</Text><Text style={styles.scoreLabel}>confidence</Text></View><StatusPill label={viewModel?.verdict.label ?? 'Needs review'} tone={viewModel?.verdict.tone ?? 'warning'} /><Text style={styles.resultTitle}>{analysis.summary}</Text><Text style={styles.resultSub}>{viewModel?.subtitle}</Text></Panel>
      <View style={styles.aiMeta}><Ionicons name={isProvisional ? 'time-outline' : analysis.fallback ? 'cloud-offline-outline' : 'sparkles-outline'} size={16} color={isProvisional || analysis.fallback ? HC.warning : HC.blue} /><Text style={styles.aiMetaText}>{viewModel?.metaLabel}</Text></View>
      {analysisError ? <AnalysisErrorPanel message={analysisError} onRetry={() => setRetryToken((value) => value + 1)} /> : null}
      <View style={styles.contextBar}><View><Text style={styles.contextLabel}>FOCUS</Text><Text style={styles.contextValue}>{focus}</Text></View><View style={styles.contextDivider} /><View><Text style={styles.contextLabel}>SOURCE</Text><Text style={styles.contextValue}>{viewModel?.sourceLabel}</Text></View><View style={styles.contextDivider} /><View><Text style={styles.contextLabel}>STATE</Text><Text style={styles.contextValue}>{viewModel?.stateLabel}</Text></View></View>
      <Text style={styles.focusLabel}>Ask AI to inspect</Text><View style={styles.focusRow}>{focusOptions.map((option) => <Pressable key={option.key} accessibilityRole="button" accessibilityState={{ selected: focus === option.key }} accessibilityLabel={`Focus analysis on ${option.label}`} onPress={() => { setFocus(option.key); setRetryToken((value) => value + 1); }} style={[styles.focusChip, focus === option.key && styles.focusChipActive]}><Text style={[styles.focusChipText, focus === option.key && styles.focusChipTextActive]}>{option.label}</Text></Pressable>)}</View>
      <SectionTitle title="Why this result" />
      <View style={styles.signalList}>{analysis.signals.map((signal, index) => <SignalRow key={`${signal.title}-${index}`} title={signal.title} body={signal.explanation} status={signal.status} />)}</View>
      <EvidenceQualityPanels analysis={analysis} />
      <Panel style={styles.actionPanel}><Text style={styles.actionLabel}>Recommended next step</Text><Text style={styles.actionBody}>{analysis.recommendedAction}</Text></Panel>
      <NextEvidencePanel analysis={analysis} onCapture={() => router.push({ pathname: '/scan', params: { focus } })} />
      <Panel style={styles.limitations}><Text style={styles.actionLabel}>Review limitations</Text>{analysis.limitations.map((item, index) => <Text key={`${item}-${index}`} style={styles.limitText}>• {item}</Text>)}</Panel>
      <AnalysisFeedbackPanel feedback={feedback} onFeedback={(value) => { setFeedback(value); setRetryToken((current) => current + 1); }} />
      <AnalysisActionFooter showRetry={viewModel?.showRetry ?? false} exporting={exporting} onCreateCase={() => router.push('/cases')} onRetry={() => setRetryToken((current) => current + 1)} onSave={saveCurrentAnalysis} onExport={() => void exportCurrentAnalysis()} />
    </>}
  </ScrollView></ScreenContainer>;
}

const focusOptions: { key: AnalysisFocus; label: string }[] = [
  { key: 'overall', label: 'Overall' },
  { key: 'logo', label: 'Logo' },
  { key: 'packaging', label: 'Packaging' },
  { key: 'serial', label: 'Serial' },
  { key: 'provenance', label: 'Provenance' },
];

const styles = StyleSheet.create({ header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }, headerCenter: { alignItems: 'center', gap: 4 }, title: { color: HC.text, fontSize: 18, fontWeight: '800' }, loadingHero: { alignItems: 'center', paddingVertical: 44, marginBottom: 26 }, loadingPulse: { position: 'absolute', top: 14, width: 150, height: 150, borderRadius: 75, borderWidth: 1, borderColor: HC.cyan, backgroundColor: 'rgba(66,232,208,0.08)', pointerEvents: 'none' }, loadingTitle: { color: HC.white, fontSize: 19, fontWeight: '800', marginTop: 18 }, loadingSub: { color: 'rgba(255,255,255,0.64)', fontSize: 13, marginTop: 7 }, resultHero: { alignItems: 'center', paddingVertical: 24, marginBottom: 12 }, ring: { width: 132, height: 132, borderRadius: 66, borderWidth: 9, alignItems: 'center', justifyContent: 'center', marginBottom: 17 }, score: { color: HC.white, fontSize: 30, fontWeight: '800' }, scoreLabel: { color: 'rgba(255,255,255,0.6)', fontSize: 11, marginTop: 1 }, resultTitle: { color: HC.white, fontSize: 20, lineHeight: 25, fontWeight: '800', textAlign: 'center', marginTop: 15 }, resultSub: { color: 'rgba(255,255,255,0.64)', fontSize: 13, lineHeight: 19, textAlign: 'center', marginTop: 8, maxWidth: 290 }, aiMeta: { flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'center', marginBottom: 12 }, aiMetaText: { color: HC.muted, fontSize: 11, fontWeight: '700' }, contextBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 11, marginBottom: 4 }, contextLabel: { color: HC.muted, fontSize: 9, fontWeight: '800', letterSpacing: 1 }, contextValue: { color: HC.text, fontSize: 11, fontWeight: '800', marginTop: 3, textTransform: 'capitalize' }, contextDivider: { width: 1, height: 26, backgroundColor: HC.line }, signalList: { gap: 10, marginTop: 12 }, signal: { flexDirection: 'row', gap: 12, alignItems: 'center', paddingVertical: 14 }, signalIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }, signalTitle: { color: HC.text, fontSize: 14, fontWeight: '800' }, signalBody: { color: HC.muted, fontSize: 12, lineHeight: 17, marginTop: 4 }, actionPanel: { marginTop: 18, backgroundColor: '#E9FBF5', borderColor: '#BDEFE2' }, nextActionPanel: { marginTop: 10, backgroundColor: '#EEF7FF', borderColor: '#CBE4FA' }, nextActionHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 }, nextActionIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: '#DDF0FF', alignItems: 'center', justifyContent: 'center' }, nextActionTitle: { color: HC.text, fontSize: 15, lineHeight: 19, fontWeight: '800', marginTop: 4 }, nextActionBody: { color: HC.muted, fontSize: 12, lineHeight: 18, marginTop: 10 }, nextActionType: { color: HC.blue, fontSize: 11, fontWeight: '800', marginTop: 9 }, captureAction: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: HC.navy, paddingHorizontal: 13, paddingVertical: 10, borderRadius: 15, marginTop: 13 }, captureActionText: { color: HC.white, fontSize: 12, fontWeight: '800' }, actionLabel: { color: HC.blue, fontSize: 10, letterSpacing: 1, fontWeight: '800', textTransform: 'uppercase' }, actionBody: { color: HC.text, fontSize: 14, lineHeight: 20, fontWeight: '700', marginTop: 6 }, limitations: { marginTop: 10 }, limitText: { color: HC.muted, fontSize: 12, lineHeight: 18, marginTop: 6 }, focusLabel: { color: HC.text, fontSize: 13, fontWeight: '800', marginTop: 20, marginBottom: 8 }, focusRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 4 }, focusChip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 18, borderWidth: 1, borderColor: '#DDE5F0', backgroundColor: HC.white }, focusChipActive: { backgroundColor: HC.navy, borderColor: HC.navy }, focusChipText: { color: HC.muted, fontSize: 12, fontWeight: '700' }, focusChipTextActive: { color: HC.white }, errorPanel: { marginTop: 10, backgroundColor: '#FFF9EC', borderColor: '#F5DFA5' }, errorHeader: { flexDirection: 'row', alignItems: 'center', gap: 7 }, errorTitle: { color: '#8C5A00', fontSize: 14, fontWeight: '800' }, errorBody: { color: HC.muted, fontSize: 12, lineHeight: 18, marginTop: 7 }, retryButton: { alignSelf: 'flex-start', backgroundColor: HC.navy, paddingHorizontal: 13, paddingVertical: 9, borderRadius: 14, marginTop: 12 }, retryText: { color: HC.white, fontSize: 12, fontWeight: '800' }, qualityPanel: { marginTop: 12, backgroundColor: '#F7FBFF' }, photoQualityPanel: { marginTop: 10, backgroundColor: '#FFF9EC', borderColor: '#F5DFA5' }, qualityHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, detailsPanel: { marginTop: 10 }, feedbackPanel: { marginTop: 10, backgroundColor: '#F7FBFF' }, feedbackTitle: { color: HC.text, fontSize: 14, fontWeight: '800' }, feedbackBody: { color: HC.muted, fontSize: 12, lineHeight: 17, marginTop: 5 }, feedbackRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 }, feedbackButton: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 16, borderWidth: 1, borderColor: '#DDE5F0', backgroundColor: HC.white }, feedbackButtonActive: { backgroundColor: HC.navy, borderColor: HC.navy }, feedbackText: { color: HC.blue, fontSize: 12, fontWeight: '800' }, feedbackTextActive: { color: HC.white }, detailText: { color: HC.muted, fontSize: 12, lineHeight: 18, marginTop: 6 }, actions: { marginTop: 22, gap: 16, alignItems: 'center' }, secondaryAction: { color: HC.blue, fontSize: 14, fontWeight: '800' }, });
