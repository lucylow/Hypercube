import { useLocalSearchParams, useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { useMemo, useState } from 'react';
import { Alert, FlatList, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/screen-container';
import { Panel, PrimaryButton } from '@/components/hypercube-ui';
import { HC } from '@/constants/hypercube';
import { UI } from '@/constants/ui';
import type { AnalysisFocus } from '@/shared/ai';
import { createScanResultRoute } from '@/shared/scan-routing';

function parseUris(value?: string): string[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === 'string' && item.length > 0).slice(0, 4) : [];
  } catch {
    return [];
  }
}

export default function PhotoReviewScreen() {
  const router = useRouter();
  const { photoUris: serializedUris, focus: focusParam } = useLocalSearchParams<{ photoUris?: string; focus?: string }>();
  const focus = (focusParam as AnalysisFocus | undefined) ?? 'overall';
  const [photos, setPhotos] = useState(() => parseUris(serializedUris));
  const [checked, setChecked] = useState<Record<number, boolean>>({});
  const [reviewStartedAt] = useState(() => new Date().toISOString());
  const [actions, setActions] = useState<string[]>([]);
  const [referenceUris, setReferenceUris] = useState<string[]>([]);
  const [busyIndex, setBusyIndex] = useState<number | null>(null);
  const checkedCount = Object.values(checked).filter(Boolean).length;
  const allChecked = photos.length > 0 && checkedCount === photos.length;
  const readinessLabel = useMemo(() => allChecked ? 'Ready for AI comparison' : `${checkedCount}/${photos.length} photos reviewed`, [allChecked, checkedCount, photos.length]);

  const replacePhoto = async (index: number) => {
    setBusyIndex(index);
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (permission.status !== 'granted') {
        Alert.alert('Camera access needed', 'Allow camera access to retake this evidence photo.');
        return;
      }
      const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [4, 3], quality: 0.9 });
      if (!result.canceled && result.assets[0]?.uri) {
        setPhotos((current) => current.map((photo, photoIndex) => photoIndex === index ? result.assets[0].uri : photo));
        setChecked((current) => ({ ...current, [index]: false }));
        setActions((current) => [...current, `retake:${index}`].slice(-10));
      }
    } catch {
      Alert.alert('Retake unavailable', 'The camera could not be opened. Please try again.');
    } finally {
      setBusyIndex(null);
    }
  };

  const movePhoto = (index: number, offset: -1 | 1) => {
    const nextIndex = index + offset;
    if (nextIndex < 0 || nextIndex >= photos.length) return;
    setActions((current) => [...current, `reorder:${index}:${nextIndex}`].slice(-10));
    setPhotos((current) => {
      const next = [...current];
      const [moved] = next.splice(index, 1);
      next.splice(nextIndex, 0, moved);
      return next;
    });
    setChecked((current) => {
      const next = { ...current };
      const moved = next[index];
      next[index] = next[nextIndex] ?? false;
      next[nextIndex] = moved ?? false;
      return next;
    });
  };

  const removePhoto = (index: number) => {
    if (photos.length === 1) {
      Alert.alert('Keep one photo', 'An evidence set needs at least one image. Retake this photo instead.');
      return;
    }
    setPhotos((current) => current.filter((_, photoIndex) => photoIndex !== index));
    setChecked({});
    setActions((current) => [...current, `remove:${index}`].slice(-10));
  };

  const pickReference = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [4, 3], quality: 0.9, selectionLimit: 3, allowsMultipleSelection: true });
      if (!result.canceled) {
        const next = result.assets.map((asset) => asset.uri).filter(Boolean).slice(0, 3);
        setReferenceUris(next);
        setActions((current) => [...current, `reference_set:${next.length}`].slice(-10));
      }
    } catch {
      Alert.alert('Reference unavailable', 'The reference image could not be selected.');
    }
  };

  const analyze = () => {
    if (!photos.length) return;
    router.push(createScanResultRoute({ photoUri: photos[0], photoUris: photos, referenceUris, focus, reviewMetadata: { imageCount: photos.length, reviewedIndexes: Object.keys(checked).filter((key) => checked[Number(key)]).map(Number), reviewStartedAt, reviewCompletedAt: new Date().toISOString(), actions } }));
  };

  return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3"><FlatList
    data={photos}
    keyExtractor={(item, index) => `${item}-${index}`}
    showsVerticalScrollIndicator={false}
    contentContainerStyle={{ paddingBottom: UI.spacing.xxl }}
    ListHeaderComponent={<View><View style={styles.header}><Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => router.back()} hitSlop={10}><Ionicons name="chevron-back" size={24} color={HC.text} /></Pressable><Text style={styles.title}>Review evidence set</Text><View style={{ width: 24 }} /></View><Text style={styles.subtitle}>Confirm each image is sharp, well lit, fully framed, and useful for the selected {focus} review.</Text><Panel style={styles.statusPanel}><Ionicons name={allChecked ? 'checkmark-circle' : 'eye-outline'} size={20} color={allChecked ? HC.success : HC.blue} /><View style={styles.flex}><Text style={styles.statusTitle}>{readinessLabel}</Text><Text style={styles.statusBody}>The AI will compare overlapping details without treating camera-angle differences as counterfeit evidence.</Text></View></Panel><Panel style={styles.referencePanel}><View style={styles.referenceHeader}><View style={styles.flex}><Text style={styles.statusTitle}>Optional reference images</Text><Text style={styles.statusBody}>Use a known example or brand-provided aid. The AI treats it as a comparison aid, not proof.</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Choose reference images" onPress={() => void pickReference()} style={styles.referenceButton}><Text style={styles.referenceButtonText}>{referenceUris.length ? `${referenceUris.length} added` : 'Add'}</Text></Pressable></View></Panel><Text style={styles.sectionTitle}>Photos · {photos.length}/4</Text></View>}
    renderItem={({ item, index }) => <Panel style={styles.photoCard}><Image accessibilityLabel={`Evidence photo ${index + 1}`} source={{ uri: item }} style={styles.photo} /><View style={styles.photoBody}><View style={styles.photoHeader}><Text style={styles.photoTitle}>Photo {index + 1}</Text><Pressable accessibilityRole="checkbox" accessibilityState={{ checked: Boolean(checked[index]) }} accessibilityLabel={`Mark photo ${index + 1} reviewed`} onPress={() => { setChecked((current) => ({ ...current, [index]: !current[index] })); setActions((current) => [...current, `review:${index}`].slice(-10)); }} style={[styles.reviewButton, checked[index] && styles.reviewButtonChecked]}><Ionicons name={checked[index] ? 'checkmark' : 'eye-outline'} size={13} color={checked[index] ? HC.ink : HC.blue} /><Text style={[styles.reviewText, checked[index] && styles.reviewTextChecked]}>{checked[index] ? 'Reviewed' : 'Review'}</Text></Pressable></View><Text style={styles.muted}>Check focus · glare · framing · identifier context</Text><View style={styles.photoActions}><Pressable accessibilityRole="button" accessibilityLabel={`Move photo ${index + 1} earlier`} disabled={index === 0} onPress={() => movePhoto(index, -1)} style={styles.iconAction}><Ionicons name="arrow-up" size={15} color={index === 0 ? HC.line : HC.blue} /></Pressable><Pressable accessibilityRole="button" accessibilityLabel={`Move photo ${index + 1} later`} disabled={index === photos.length - 1} onPress={() => movePhoto(index, 1)} style={styles.iconAction}><Ionicons name="arrow-down" size={15} color={index === photos.length - 1 ? HC.line : HC.blue} /></Pressable><Pressable accessibilityRole="button" accessibilityLabel={`Retake photo ${index + 1}`} onPress={() => void replacePhoto(index)} disabled={busyIndex !== null} style={styles.textAction}><Text style={styles.actionText}>{busyIndex === index ? 'Opening…' : 'Retake'}</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={`Remove photo ${index + 1}`} onPress={() => removePhoto(index)} style={styles.textAction}><Text style={styles.removeText}>Remove</Text></Pressable></View></View></Panel>}
    ListEmptyComponent={<Panel style={styles.empty}><Ionicons name="images-outline" size={28} color={HC.blue} /><Text style={styles.emptyTitle}>No evidence photos</Text><Text style={styles.muted}>Go back and select at least one product photo.</Text></Panel>}
    ListFooterComponent={<View style={styles.footer}><PrimaryButton label={allChecked ? 'Analyze evidence set' : 'Analyze with review notes'} icon="sparkles-outline" onPress={analyze} disabled={!photos.length || busyIndex !== null} /><Text style={styles.disclaimer}>Visual comparison is a risk signal, not proof of authenticity. Review the evidence and limitations before acting.</Text></View>}
  /></ScreenContainer>;
}

const styles = StyleSheet.create({ header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: UI.spacing.md }, title: { color: HC.text, fontSize: 20, fontWeight: '800' }, subtitle: { color: HC.muted, fontSize: 13, lineHeight: 19, marginBottom: UI.spacing.md },   statusPanel: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, backgroundColor: '#EEF7FF', borderColor: '#CBE4FA', marginBottom: UI.spacing.lg }, referencePanel: { marginBottom: UI.spacing.lg, backgroundColor: '#FFF9EC', borderColor: '#F5DFA5' }, referenceHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 }, referenceButton: { backgroundColor: HC.blue, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 }, referenceButtonText: { color: HC.white, fontSize: 11, fontWeight: '800' }, flex: { flex: 1 }, statusTitle: { color: HC.text, fontSize: 13, fontWeight: '800' }, statusBody: { color: HC.muted, fontSize: 11, lineHeight: 16, marginTop: 4 }, sectionTitle: { color: HC.text, fontSize: 18, fontWeight: '800', marginBottom: 10 }, photoCard: { flexDirection: 'row', gap: 12, marginBottom: 10 }, photo: { width: 100, height: 100, borderRadius: 14, backgroundColor: '#EEF3FF' }, photoBody: { flex: 1, justifyContent: 'center' }, photoHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 6 }, photoTitle: { color: HC.text, fontSize: 14, fontWeight: '800' }, muted: { color: HC.muted, fontSize: 11, lineHeight: 17 }, reviewButton: { flexDirection: 'row', alignItems: 'center', gap: 4, borderRadius: 10, paddingHorizontal: 7, paddingVertical: 5, backgroundColor: '#EEF3FF' }, reviewButtonChecked: { backgroundColor: HC.cyan }, reviewText: { color: HC.blue, fontSize: 10, fontWeight: '800' }, reviewTextChecked: { color: HC.ink }, photoActions: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 9 }, iconAction: { width: 27, height: 27, alignItems: 'center', justifyContent: 'center', borderRadius: 8, backgroundColor: '#EEF3FF' }, textAction: { paddingHorizontal: 4, paddingVertical: 6 }, actionText: { color: HC.blue, fontSize: 11, fontWeight: '800' }, removeText: { color: HC.danger, fontSize: 11, fontWeight: '800' }, footer: { marginTop: UI.spacing.md }, disclaimer: { color: HC.muted, fontSize: 11, lineHeight: 16, textAlign: 'center', marginTop: UI.spacing.md }, empty: { alignItems: 'center', paddingVertical: UI.spacing.xxl }, emptyTitle: { color: HC.text, fontWeight: '800', marginTop: 8 }, });
