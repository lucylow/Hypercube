import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Image, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system/legacy';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { useAnimatedStyle, useSharedValue } from 'react-native-reanimated';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/screen-container';
import { ScreenState } from '@/components/ui/screen-state';
import { HC } from '@/constants/hypercube';
import { UI } from '@/constants/ui';
import { loadEvidenceDraft, saveEvidenceDraft } from '@/lib/evidence-storage';
import { syncQueuedEvidenceDrafts } from '@/lib/evidence-background';
import { createTRPCClient } from '@/lib/trpc';
import { appendExportHistory, type ExportStatus } from '@/lib/export-history';
import { appendEvidenceSyncEvent, buildEvidenceAuditCsv, buildEvidenceAuditExport, filterEvidenceSyncEvents, getEvidencePhotoUploadSummary, queueEvidencePhotoRetry, sortEvidenceSyncEvents, type EvidenceDraft, type EvidencePhoto, type EvidenceSyncEvent, type EvidenceSyncHistoryFilter } from '@/lib/evidence-model';

function ZoomableEvidenceImage({ uri }: { uri: string }) {
  const scale = useSharedValue(1);
  const savedScale = useSharedValue(1);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const savedX = useSharedValue(0);
  const savedY = useSharedValue(0);
  const pinch = Gesture.Pinch().onStart(() => { savedScale.value = scale.value; }).onUpdate((event) => { scale.value = Math.min(4, Math.max(1, savedScale.value * event.scale)); }).onEnd(() => { if (scale.value === 1) { translateX.value = 0; translateY.value = 0; } });
  const pan = Gesture.Pan().onStart(() => { savedX.value = translateX.value; savedY.value = translateY.value; }).onUpdate((event) => { const limit = Math.max(0, (scale.value - 1) * 180); translateX.value = Math.min(limit, Math.max(-limit, savedX.value + event.translationX)); translateY.value = Math.min(limit, Math.max(-limit, savedY.value + event.translationY)); });
  const style = useAnimatedStyle(() => ({ transform: [{ translateX: translateX.value }, { translateY: translateY.value }, { scale: scale.value }] }));
  return <GestureDetector gesture={Gesture.Simultaneous(pinch, pan)}><Animated.View style={[styles.fullPreviewImageFrame, style]}><Image accessibilityLabel="Full-screen evidence photo" source={{ uri }} resizeMode="contain" style={styles.fullPreviewImage} /></Animated.View></GestureDetector>;
}

function eventTone(event: EvidenceSyncEvent): { color: string; icon: keyof typeof Ionicons.glyphMap } {
  if (event.status === 'synced') return { color: HC.success, icon: 'checkmark-circle-outline' };
  if (event.status === 'failed') return { color: HC.danger, icon: 'alert-circle-outline' };
  if (event.status === 'offline') return { color: HC.warning, icon: 'cloud-offline-outline' };
  if (event.status === 'previewed') return { color: HC.blue, icon: 'eye-outline' };
  if (event.status === 'uploading') return { color: HC.blue, icon: 'cloud-upload-outline' };
  return { color: HC.muted, icon: 'time-outline' };
}

export default function EvidenceDraftSyncHistoryScreen() {
  const router = useRouter();
  const { caseId } = useLocalSearchParams<{ caseId: string }>();
  const [draft, setDraft] = useState<EvidenceDraft | null>(null);
  const [loading, setLoading] = useState(true);
  const [previewUrls, setPreviewUrls] = useState<Record<string, string>>({});
  const [previewingId, setPreviewingId] = useState<string | null>(null);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [fullPreviewUrl, setFullPreviewUrl] = useState<string | null>(null);
  const [fullPreviewPhoto, setFullPreviewPhoto] = useState<EvidencePhoto | null>(null);
  const [sharing, setSharing] = useState(false);
  const [shareError, setShareError] = useState(false);
  const [historyFilter, setHistoryFilter] = useState<EvidenceSyncHistoryFilter>('all');
  const [exportingAudit, setExportingAudit] = useState(false);
  const [exportError, setExportError] = useState(false);

  const load = useCallback(() => {
    if (!caseId) return;
    setLoading(true);
    void loadEvidenceDraft(caseId).then(setDraft).finally(() => setLoading(false));
  }, [caseId]);

  useEffect(() => { load(); }, [load]);

  const events = useMemo(() => sortEvidenceSyncEvents(filterEvidenceSyncEvents(draft?.syncHistory ?? [], historyFilter)), [draft, historyFilter]);
  const photoSummary = useMemo(() => draft ? getEvidencePhotoUploadSummary(draft) : null, [draft]);

  const openPhoto = useCallback(async (photoId: string, remoteKey: string) => {
    setPreviewingId(photoId);
    setPreviewError(null);
    try {
      const { signedUrl } = await createTRPCClient().evidence.getPhotoDownloadUrl.mutate({ remoteKey });
      setPreviewUrls((current) => ({ ...current, [photoId]: signedUrl }));
      if (draft) {
        const audited = appendEvidenceSyncEvent(draft, { id: `preview-${photoId}-${Date.now()}`, occurredAt: new Date().toISOString(), status: 'previewed', message: 'Investigator previewed the stored evidence photo.' });
        setDraft(audited);
        await saveEvidenceDraft(audited);
      }
    } catch {
      setPreviewError(photoId);
    } finally {
      setPreviewingId(null);
    }
  }, [draft]);

  const closeFullPreview = useCallback(() => {
    setFullPreviewUrl(null);
    setFullPreviewPhoto(null);
    setShareError(false);
  }, []);

  const sharePhoto = useCallback(async () => {
    if (!fullPreviewPhoto?.remoteKey) return;
    setSharing(true);
    setShareError(false);
    try {
      const { signedUrl } = await createTRPCClient().evidence.getPhotoDownloadUrl.mutate({ remoteKey: fullPreviewPhoto.remoteKey });
      if (Platform.OS === 'web') {
        if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(signedUrl, { dialogTitle: 'Share evidence photo' });
        else window.open(signedUrl, '_blank', 'noopener,noreferrer');
      } else {
        const localUri = `${FileSystem.cacheDirectory ?? FileSystem.documentDirectory}hypercube-${fullPreviewPhoto.id}.jpg`;
        const downloaded = await FileSystem.downloadAsync(signedUrl, localUri);
        if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(downloaded.uri, { dialogTitle: 'Share evidence photo', mimeType: 'image/jpeg' });
        else setShareError(true);
      }
    } catch {
      setShareError(true);
    } finally {
      setSharing(false);
    }
  }, [fullPreviewPhoto]);

  const exportAudit = useCallback(async (format: 'json' | 'csv') => {
    if (!draft) return;
    setExportingAudit(true);
    setExportError(false);
    let exportStatus: ExportStatus = 'failed';
    try {
      const report = format === 'json' ? JSON.stringify(buildEvidenceAuditExport(draft, events), null, 2) : buildEvidenceAuditCsv(draft, events);
      const extension = format === 'json' ? 'json' : 'csv';
      const mimeType = format === 'json' ? 'application/json' : 'text/csv';
      if (Platform.OS === 'web') {
        const blob = new Blob([report], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = `hypercube-${draft.caseId}-audit.${extension}`;
        anchor.click();
        URL.revokeObjectURL(url);
        exportStatus = 'downloaded';
      } else {
        const uri = `${FileSystem.cacheDirectory ?? FileSystem.documentDirectory}hypercube-${draft.caseId}-audit.${extension}`;
        await FileSystem.writeAsStringAsync(uri, report);
        if (await Sharing.isAvailableAsync()) { await Sharing.shareAsync(uri, { dialogTitle: 'Export evidence audit', mimeType }); exportStatus = 'shared'; }
        else { setExportError(true); exportStatus = 'unavailable'; }
      }
    } catch {
      setExportError(true);
    } finally {
      await appendExportHistory({ id: `audit-${Date.now()}`, createdAt: new Date().toISOString(), scope: 'filtered', format, count: events.length, status: exportStatus, caseId: draft.caseId });
      setExportingAudit(false);
    }
  }, [draft, events]);

  const retryPhoto = useCallback(async (photoId: string) => {
    if (!draft) return;
    const queued = queueEvidencePhotoRetry(draft, photoId);
    setDraft(queued);
    await saveEvidenceDraft(queued);
    await syncQueuedEvidenceDrafts();
    load();
  }, [draft, load]);

  if (loading) return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5"><ScreenState kind="loading" title="Loading sync history" description="Restoring the local audit trail." /></ScreenContainer>;
  if (!draft) return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5"><ScreenState kind="empty" title="Draft not found" description="This local evidence draft may have been discarded." /></ScreenContainer>;

  return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3"><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.header}><View><Text style={styles.eyebrow}>SYNC AUDIT</Text><Text style={styles.title}>Case {draft.caseId}</Text><Text style={styles.subtitle}>{draft.evidenceType} · {photoSummary?.uploaded ?? 0}/{photoSummary?.total ?? 0} photos uploaded</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => router.back()} hitSlop={UI.control.hitSlop}><Ionicons name="close" size={24} color={HC.text} /></Pressable></View>
    <View style={styles.receiptPanel}><View style={styles.receiptIcon}><Ionicons name="shield-checkmark-outline" size={20} color={HC.cyan} /></View><View style={styles.receiptCopy}><Text style={styles.receiptLabel}>Latest server receipt</Text><Text style={styles.receiptValue}>{draft.lastReceiptId ?? 'No receipt yet'}</Text><Text style={styles.receiptMeta}>{draft.lastAttemptAt ? `Last attempt ${new Date(draft.lastAttemptAt).toLocaleString()}` : 'No sync attempt recorded'}</Text></View></View>
    {draft.recoveryHint && <View style={styles.guidance}><Ionicons name="information-circle-outline" size={18} color={HC.warning} /><Text style={styles.guidanceText}>{draft.recoveryHint}</Text></View>}
    <Text style={styles.sectionTitle}>Evidence photos</Text>
    <View style={styles.photoList}>{draft.photos.map((photo, index) => { const uploaded = Boolean(photo.remoteUrl); const failed = photo.uploadState === 'failed'; return <View key={photo.id} style={styles.photoRow}><View style={[styles.photoIcon, { backgroundColor: failed ? '#FFF0F0' : uploaded ? '#EAFBF8' : '#EEF3FF' }]}><Ionicons name={failed ? 'alert-circle-outline' : uploaded ? 'checkmark-circle-outline' : 'image-outline'} size={17} color={failed ? HC.danger : uploaded ? HC.success : HC.blue} /></View><View style={styles.photoCopy}><Text style={styles.photoTitle}>Photo {index + 1}</Text><Text style={styles.photoStatus}>{failed ? 'Upload failed — will retry' : uploaded ? 'Uploaded to evidence storage' : photo.uploadState === 'uploading' ? 'Uploading now' : 'Waiting for upload'}</Text>{photo.uploadError && <Text style={styles.photoError}>{photo.uploadError}</Text>}{photo.remoteKey && (previewUrls[photo.id] ? <Pressable accessibilityRole="button" accessibilityLabel={`Open full-screen evidence photo ${index + 1}`} onPress={() => { setFullPreviewPhoto(photo); setFullPreviewUrl(previewUrls[photo.id]); }}><Image accessibilityLabel={`Uploaded evidence photo ${index + 1}`} source={{ uri: previewUrls[photo.id] }} style={styles.photoPreview} /></Pressable> : <Pressable accessibilityRole="button" accessibilityLabel={`Preview uploaded photo ${index + 1}`} disabled={previewingId === photo.id} onPress={() => void openPhoto(photo.id, photo.remoteKey!)} style={styles.photoOpen}>{previewingId === photo.id ? <ActivityIndicator size="small" color={HC.blue} /> : <Ionicons name="eye-outline" size={14} color={HC.blue} />}<Text style={styles.photoOpenText}>{previewingId === photo.id ? 'Loading photo…' : 'Preview photo'}</Text></Pressable>)}{previewError === photo.id && <Text accessibilityRole="alert" style={styles.photoError}>Preview unavailable. The uploaded photo remains safely stored.</Text>}{failed && <Pressable accessibilityRole="button" accessibilityLabel={`Retry upload for photo ${index + 1}`} onPress={() => void retryPhoto(photo.id)} style={styles.photoRetry}><Ionicons name="refresh-outline" size={14} color={HC.cyan} /><Text style={styles.photoRetryText}>Retry photo</Text></Pressable>}</View></View>; })}</View>
    <Text style={styles.sectionTitle}>Attempt history</Text>
    <View style={styles.filterRow}>{(['all', 'handoff', 'photo'] as EvidenceSyncHistoryFilter[]).map((filter) => <Pressable key={filter} accessibilityRole="button" accessibilityState={{ selected: historyFilter === filter }} onPress={() => setHistoryFilter(filter)} style={[styles.filterChip, historyFilter === filter && styles.filterChipActive]}><Text style={[styles.filterChipText, historyFilter === filter && styles.filterChipTextActive]}>{filter === 'all' ? 'All' : filter === 'handoff' ? 'Handoff' : 'Photo activity'}</Text></Pressable>)}</View><View style={styles.auditExportRow}><Pressable accessibilityRole="button" accessibilityLabel="Export filtered evidence audit JSON" disabled={exportingAudit} onPress={() => void exportAudit('json')} style={styles.auditExportButton}><Ionicons name="code-download-outline" size={15} color={HC.cyan} /><Text style={styles.auditExportText}>{exportingAudit ? 'Preparing…' : 'JSON'}</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Export filtered evidence audit CSV" disabled={exportingAudit} onPress={() => void exportAudit('csv')} style={styles.auditExportButton}><Ionicons name="grid-outline" size={15} color={HC.cyan} /><Text style={styles.auditExportText}>{exportingAudit ? 'Preparing…' : 'CSV'}</Text></Pressable></View>{exportError && <Text accessibilityRole="alert" style={styles.shareError}>Audit export is unavailable on this device.</Text>}
    {events.length ? events.map((event) => { const tone = eventTone(event); return <View key={event.id} style={styles.event}><View style={[styles.eventIcon, { backgroundColor: `${tone.color}18` }]}><Ionicons name={tone.icon} size={18} color={tone.color} /></View><View style={styles.eventCopy}><View style={styles.eventTop}><Text style={[styles.eventStatus, { color: tone.color }]}>{event.status.toUpperCase()}</Text><Text style={styles.eventDate}>{new Date(event.occurredAt).toLocaleString()}</Text></View><Text style={styles.eventMessage}>{event.message}</Text>{event.receiptId && <Text style={styles.eventReceipt}>Receipt {event.receiptId}</Text>}</View></View>; }) : <ScreenState kind="empty" title="No sync attempts yet" description="Queue this draft to create an auditable handoff timeline." />}
    <Pressable accessibilityRole="button" accessibilityLabel="Return to evidence drafts" onPress={() => router.back()} style={styles.backButton}><Ionicons name="arrow-back-outline" size={16} color={HC.cyan} /><Text style={styles.backText}>Back to drafts</Text></Pressable>
  </ScrollView><Modal visible={Boolean(fullPreviewUrl)} transparent animationType="fade" onRequestClose={() => setFullPreviewUrl(null)}><View style={styles.fullPreviewBackdrop}><Pressable accessibilityRole="button" accessibilityLabel="Close full-screen photo preview" onPress={closeFullPreview} style={styles.fullPreviewClose}><Ionicons name="close" size={24} color={HC.white} /></Pressable>{fullPreviewUrl && <ZoomableEvidenceImage uri={fullPreviewUrl} />}<View style={styles.metadataPanel}><Text style={styles.metadataTitle}>Evidence metadata</Text><Text style={styles.metadataText}>Captured {fullPreviewPhoto?.createdAt ? new Date(fullPreviewPhoto.createdAt).toLocaleString() : 'Unknown'}</Text><Text style={styles.metadataText}>Upload receipt {draft.lastReceiptId ?? 'Pending server receipt'}</Text><Text selectable style={styles.metadataHash}>SHA-256 {fullPreviewPhoto?.integrityHash ?? 'Unavailable for older upload'}</Text><Pressable accessibilityRole="button" accessibilityLabel="Share or export selected evidence photo" disabled={sharing} onPress={() => void sharePhoto()} style={styles.shareButton}>{sharing ? <ActivityIndicator size="small" color={HC.ink} /> : <Ionicons name="share-outline" size={16} color={HC.ink} />}<Text style={styles.shareButtonText}>{sharing ? 'Preparing export…' : 'Share / Export photo'}</Text></Pressable>{shareError && <Text accessibilityRole="alert" style={styles.shareError}>Sharing is unavailable on this device or browser.</Text>}</View></View></Modal></ScreenContainer>;
}

const styles = StyleSheet.create({ content: { paddingBottom: UI.spacing.xxl }, header: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: UI.spacing.lg }, eyebrow: { color: HC.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.1 }, title: { color: HC.text, fontSize: 27, fontWeight: '800', marginTop: 5 }, subtitle: { color: HC.muted, fontSize: 12, marginTop: 4 }, receiptPanel: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm, backgroundColor: HC.ink, borderRadius: UI.radius.md, padding: UI.spacing.md }, receiptIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#15324A', alignItems: 'center', justifyContent: 'center' }, receiptCopy: { flex: 1 }, receiptLabel: { color: HC.cyan, fontSize: 10, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.8 }, receiptValue: { color: HC.white, fontSize: 13, fontWeight: '800', marginTop: 3 }, receiptMeta: { color: '#B7C5D6', fontSize: 10, marginTop: 4 }, guidance: { flexDirection: 'row', gap: UI.spacing.sm, alignItems: 'flex-start', backgroundColor: '#FFF7E8', borderWidth: 1, borderColor: '#F4D79A', borderRadius: UI.radius.md, padding: UI.spacing.sm, marginTop: UI.spacing.md }, guidanceText: { color: '#8A5A00', flex: 1, fontSize: 12, lineHeight: 17 }, sectionTitle: { color: HC.text, fontSize: 16, fontWeight: '800', marginTop: UI.spacing.xl, marginBottom: UI.spacing.sm }, photoList: { gap: 7 }, photoRow: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line, borderRadius: UI.radius.sm, padding: UI.spacing.sm }, photoIcon: { width: 32, height: 32, borderRadius: 9, alignItems: 'center', justifyContent: 'center' }, photoCopy: { flex: 1 }, photoTitle: { color: HC.text, fontSize: 12, fontWeight: '800' }, photoStatus: { color: HC.muted, fontSize: 10, marginTop: 2 }, photoError: { color: HC.danger, fontSize: 10, marginTop: 2 }, photoOpen: { flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start', backgroundColor: '#EEF3FF', borderRadius: 7, paddingHorizontal: 7, paddingVertical: 5, marginTop: 6 }, photoOpenText: { color: HC.blue, fontSize: 10, fontWeight: '800' }, photoPreview: { width: '100%', height: 180, borderRadius: 10, backgroundColor: '#E8EDF5', marginTop: 7 }, fullPreviewBackdrop: { flex: 1, backgroundColor: 'rgba(3, 12, 25, 0.96)', alignItems: 'center', justifyContent: 'center', padding: 20 }, fullPreviewImageFrame: { width: '100%', height: '58%', alignItems: 'center', justifyContent: 'center' }, fullPreviewImage: { width: '100%', height: '100%' }, fullPreviewClose: { position: 'absolute', top: 54, right: 20, zIndex: 2, width: 42, height: 42, borderRadius: 21, backgroundColor: '#16304A', alignItems: 'center', justifyContent: 'center' }, metadataPanel: { width: '100%', backgroundColor: '#10243A', borderRadius: 14, padding: 14, marginTop: 10 }, metadataTitle: { color: HC.cyan, fontSize: 12, fontWeight: '900', textTransform: 'uppercase', letterSpacing: 0.8 }, metadataText: { color: HC.white, fontSize: 11, marginTop: 5 }, metadataHash: { color: '#B7C5D6', fontSize: 10, marginTop: 6 }, shareButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: HC.cyan, borderRadius: 9, paddingVertical: 10, marginTop: 12 }, shareButtonText: { color: HC.ink, fontSize: 11, fontWeight: '900' }, shareError: { color: '#FFB4B4', fontSize: 10, marginTop: 7, textAlign: 'center' }, photoRetry: { flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start', backgroundColor: HC.ink, borderRadius: 7, paddingHorizontal: 7, paddingVertical: 5, marginTop: 6 }, photoRetryText: { color: HC.cyan, fontSize: 10, fontWeight: '800' }, filterRow: { flexDirection: 'row', gap: 7, marginBottom: 4 }, auditExportRow: { flexDirection: 'row', gap: 7, marginBottom: 4 }, auditExportButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, borderWidth: 1, borderColor: HC.cyan, borderRadius: 9, paddingVertical: 8, marginBottom: 4 }, auditExportText: { color: HC.cyan, fontSize: 11, fontWeight: '800' }, filterChip: { borderWidth: 1, borderColor: HC.line, borderRadius: 99, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: HC.white }, filterChipActive: { backgroundColor: HC.ink, borderColor: HC.ink }, filterChipText: { color: HC.muted, fontSize: 10, fontWeight: '800' }, filterChipTextActive: { color: HC.cyan }, event: { flexDirection: 'row', gap: UI.spacing.sm, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line, borderRadius: UI.radius.md, padding: UI.spacing.sm, marginTop: UI.spacing.sm }, eventIcon: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center' }, eventCopy: { flex: 1 }, eventTop: { flexDirection: 'row', justifyContent: 'space-between', gap: UI.spacing.sm }, eventStatus: { fontSize: 10, fontWeight: '900', letterSpacing: 0.6 }, eventDate: { color: HC.muted, fontSize: 10 }, eventMessage: { color: HC.text, fontSize: 12, lineHeight: 17, marginTop: 5 }, eventReceipt: { color: HC.muted, fontSize: 10, marginTop: 4 }, backButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: HC.ink, borderRadius: UI.radius.sm, paddingVertical: 10, marginTop: UI.spacing.xl }, backText: { color: HC.cyan, fontSize: 12, fontWeight: '800' } });
