import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { HC } from '@/constants/hypercube';

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottom = Platform.OS === 'web' ? 10 : Math.max(insets.bottom, 8);
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: HC.cyan, tabBarInactiveTintColor: '#7B8798', tabBarStyle: { height: 62 + bottom, paddingBottom: bottom, paddingTop: 7, backgroundColor: HC.ink, borderTopColor: 'rgba(255,255,255,0.08)', borderTopWidth: 1 }, tabBarLabelStyle: { fontSize: 10, fontWeight: '700' } }}>
    <Tabs.Screen name="index" options={{ title: 'Home', tabBarIcon: ({ color, size }) => <Ionicons name="home-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="scan" options={{ title: 'Scan', tabBarIcon: ({ color, size }) => <Ionicons name="scan-outline" size={size + 2} color={color} /> }} />
    <Tabs.Screen name="cases" options={{ title: 'Cases', tabBarIcon: ({ color, size }) => <Ionicons name="briefcase-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="map" options={{ title: 'Map', tabBarIcon: ({ color, size }) => <Ionicons name="map-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="account" options={{ title: 'Account', tabBarIcon: ({ color, size }) => <Ionicons name="person-outline" size={size} color={color} /> }} />
  </Tabs>;
}
