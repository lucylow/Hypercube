import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { Eyebrow, Panel } from '@/components/hypercube-ui';
import { HC } from '@/constants/hypercube';
import { trpc } from '@/lib/trpc';

const planNames = { free: 'Free', professional: 'Professional', team: 'Team' } as const;

export default function AccountScreen() {
  const router = useRouter();
  const entitlementQuery = trpc.billing.entitlement.useQuery(undefined, { retry: false });
  const entitlement = entitlementQuery.data;
  const plan = entitlement ? planNames[entitlement.plan] : 'Loading…';
  const paymentNeedsAttention = entitlement?.paymentStatus === 'failed' || entitlement?.paymentStatus === 'requires_action' || entitlement?.status === 'past_due' || entitlement?.status === 'paused' || entitlement?.status === 'incomplete' || entitlement?.status === 'canceled';
  const paymentLabel = entitlement?.paymentStatus === 'requires_action' ? 'Payment action required' : entitlement?.paymentStatus === 'failed' || entitlement?.status === 'past_due' ? 'Payment needs attention' : entitlement?.status === 'paused' ? 'Subscription paused' : entitlement?.status === 'incomplete' ? 'Activation incomplete' : entitlement?.status === 'canceled' ? 'Subscription canceled' : entitlement?.status === 'active' ? 'Billing active' : 'Billing not active';

  return (
    <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 28 }}>
        <Eyebrow>PROFILE / SETTINGS</Eyebrow>
        <Text style={styles.title}>Account</Text>
        <Panel dark style={styles.profile}>
          <View style={styles.avatar}><Text style={styles.avatarText}>AM</Text></View>
          <View style={{ flex: 1 }}><Text style={styles.name}>Alex Morgan</Text><Text style={styles.role}>Brand Investigator</Text><Text style={styles.org}>Northstar Goods</Text></View>
          <Ionicons name="chevron-forward" size={20} color="rgba(255,255,255,0.5)" />
        </Panel>
        <Panel style={[styles.usage, paymentNeedsAttention && styles.usageWarning]}>
          <View style={{ flex: 1 }}>
            <Text style={styles.usageLabel}>PLAN AND BILLING</Text>
            <Text style={styles.plan}>{plan}</Text>
            <Text style={styles.usageText}>{paymentLabel}</Text>
            <Text style={styles.usageMeta}>{entitlement?.currentPeriodEnd ? `Renews ${new Date(entitlement.currentPeriodEnd).toLocaleDateString()}` : 'Usage limits are enforced server-side.'}</Text>
          </View>
          <View style={[styles.usageRing, paymentNeedsAttention && styles.usageRingWarning]}><Ionicons name={paymentNeedsAttention ? 'warning-outline' : entitlement?.status === 'active' ? 'checkmark' : 'remove'} size={24} color={paymentNeedsAttention ? HC.warning : HC.cyan} /></View>
        </Panel>
        {paymentNeedsAttention && <Pressable accessibilityRole="button" accessibilityLabel="Review payment and subscription" onPress={() => router.push('/account/usage')} style={styles.recovery}><Ionicons name="card-outline" size={18} color={HC.warning} /><Text style={styles.recoveryText}>{entitlement?.status === 'canceled' ? 'Choose a plan to restore paid access' : 'Review payment and subscription'}</Text><Ionicons name="arrow-forward" size={17} color={HC.warning} /></Pressable>}
        <Text style={styles.section}>Workspace</Text>
        <Row icon="people-outline" title="Team" subtitle="8 members" /><Row icon="business-outline" title="Organization" subtitle="Northstar Goods" /><Row icon="notifications-outline" title="Notifications" subtitle="On" />
        <Text style={styles.section}>Support</Text>
        <Row icon="shield-checkmark-outline" title="Privacy" subtitle="Permissions and data" /><Row icon="help-circle-outline" title="Help and support" subtitle="Get answers" />
        <Pressable accessibilityRole="button" accessibilityLabel="Manage subscription" onPress={() => router.push('/account/usage')} style={styles.manage}><Text style={styles.manageText}>Manage subscription</Text><Ionicons name="arrow-forward" size={17} color={HC.blue} /></Pressable><Text style={styles.version}>Hypercube Mobile · v1.0.0</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

function Row({ icon, title, subtitle }: { icon: keyof typeof Ionicons.glyphMap; title: string; subtitle: string }) { return <View style={styles.row}><View style={styles.rowIcon}><Ionicons name={icon} size={20} color={HC.blue} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{title}</Text><Text style={styles.rowSub}>{subtitle}</Text></View><Ionicons name="chevron-forward" size={18} color={HC.muted} /></View>; }

const styles = StyleSheet.create({
  title: { color: HC.text, fontSize: 28, fontWeight: '800', marginTop: 5, marginBottom: 20 },
  profile: { flexDirection: 'row', alignItems: 'center', gap: 13, marginBottom: 14 },
  avatar: { width: 52, height: 52, borderRadius: 18, backgroundColor: HC.cyan, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: HC.ink, fontSize: 14, fontWeight: '900' },
  name: { color: HC.white, fontSize: 17, fontWeight: '800' }, role: { color: 'rgba(255,255,255,0.63)', fontSize: 12, marginTop: 3 }, org: { color: HC.cyan, fontSize: 12, fontWeight: '700', marginTop: 5 },
  usage: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, usageWarning: { borderColor: HC.warning, borderWidth: 1 }, usageLabel: { color: HC.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.1 }, plan: { color: HC.text, fontSize: 20, fontWeight: '800', marginTop: 6 }, usageText: { color: HC.muted, fontSize: 12, marginTop: 4 }, usageMeta: { color: HC.muted, fontSize: 11, marginTop: 5 }, usageRing: { width: 68, height: 68, borderRadius: 34, borderWidth: 7, borderColor: HC.cyan, alignItems: 'center', justifyContent: 'center' }, usageRingWarning: { borderColor: HC.warning },
  recovery: { minHeight: 52, flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 14, marginTop: 10, borderRadius: 14, backgroundColor: '#FFF7E6' }, recoveryText: { flex: 1, color: HC.warning, fontSize: 13, fontWeight: '800' },
  section: { color: HC.text, fontSize: 15, fontWeight: '800', marginTop: 27, marginBottom: 8 }, row: { minHeight: 70, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: 1, borderBottomColor: HC.line }, rowIcon: { width: 39, height: 39, borderRadius: 13, backgroundColor: '#EEF3FF', alignItems: 'center', justifyContent: 'center' }, rowTitle: { color: HC.text, fontSize: 14, fontWeight: '800' }, rowSub: { color: HC.muted, fontSize: 12, marginTop: 4 }, manage: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 24, padding: 16, borderRadius: 16, backgroundColor: '#EAF0FF' }, manageText: { color: HC.blue, fontSize: 14, fontWeight: '800' }, version: { color: HC.muted, fontSize: 11, textAlign: 'center', marginTop: 22 },
});
