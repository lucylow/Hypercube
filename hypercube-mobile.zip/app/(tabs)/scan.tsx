import { useLocalSearchParams, useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { useCallback, useEffect, useState } from 'react';
import { useIsFocused } from '@react-navigation/native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Ionicons } from '@expo/vector-icons';
import { Alert, AppState, Pressable, StyleSheet, Text, View } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { HC } from '@/constants/hypercube';
import type { AnalysisFocus } from '@/shared/ai';
import { getCaptureGuide } from '@/shared/capture-guidance';
import { createScanResultRoute } from '@/shared/scan-routing';

const focusOptions: AnalysisFocus[] = ['overall', 'logo', 'packaging', 'serial', 'provenance'];

function isAnalysisFocus(value?: string): value is AnalysisFocus {
  return Boolean(value && focusOptions.includes(value as AnalysisFocus));
}

export default function ScanScreen() {
  const router = useRouter();
  const { focus: focusParam } = useLocalSearchParams<{ focus?: string }>();
  const captureFocus: AnalysisFocus = isAnalysisFocus(focusParam) ? focusParam : 'overall';
  const captureGuide = getCaptureGuide(captureFocus);
  const [checkedSteps, setCheckedSteps] = useState<Record<number, boolean>>({});
  const [permission, requestPermission] = useCameraPermissions();
  const [torch, setTorch] = useState(false);
  const [scanned, setScanned] = useState(false);
  const handlePhotoResult = useCallback((result: ImagePicker.ImagePickerResult | ImagePicker.ImagePickerErrorResult) => {
    if ('canceled' in result && !result.canceled && result.assets[0]?.uri) {
      const photoUris = result.assets.map((asset) => asset.uri).filter(Boolean).slice(0, 4);
      router.push({ pathname: '/scan/photo-review', params: { photoUris: JSON.stringify(photoUris), focus: captureFocus } });
    }
  }, [captureFocus, router]);
  const pickProductPhoto = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.9,
        allowsMultipleSelection: true,
        selectionLimit: 4,
      });
      handlePhotoResult(result);
    } catch {
      Alert.alert('Photo unavailable', 'Hypercube could not open your photo library. Please try again.');
    }
  };
  const isFocused = useIsFocused();
  const hasCamera = permission?.granted;
  useEffect(() => {
    if (isFocused) {
      setScanned(false);
      setCheckedSteps({});
    }
  }, [isFocused, captureFocus]);
  useEffect(() => {
    const subscription = AppState.addEventListener('change', async (nextState) => {
      if (nextState !== 'active') return;
      const pending = await ImagePicker.getPendingResultAsync();
      if (pending) handlePhotoResult(pending);
    });
    return () => subscription.remove();
  }, [handlePhotoResult]);
  const handleBarcode = ({ data }: { data: string }) => {
    if (scanned) return;
    setScanned(true);
    router.push(createScanResultRoute({ code: data, focus: captureFocus }));
  };
  return <ScreenContainer edges={['top', 'left', 'right', 'bottom']} containerClassName="bg-[#07111F]">
    <View style={styles.container}>
      {hasCamera && isFocused ? <CameraView style={StyleSheet.absoluteFill} facing="back" barcodeScannerSettings={{ barcodeTypes: ['qr', 'ean13', 'ean8', 'code128'] }} enableTorch={torch} onBarcodeScanned={scanned ? undefined : handleBarcode} /> : <View style={styles.fallback}><View style={styles.fallbackIcon}><Ionicons name="camera-outline" size={30} color={HC.cyan} /></View><Text style={styles.fallbackTitle}>Scan a product</Text><Text style={styles.fallbackBody}>Use your camera to scan a QR code or capture product evidence.</Text><Pressable accessibilityRole="button" accessibilityLabel="Allow camera access" onPress={requestPermission} style={styles.permissionButton}><Text style={styles.permissionText}>{permission ? 'Allow camera access' : 'Loading camera'}</Text></Pressable></View>}
      <View style={styles.header}><Pressable accessibilityRole="button" accessibilityLabel="Close scanner" onPress={() => router.back()} style={styles.close}><Ionicons name="close" size={23} color={HC.white} /></Pressable><View style={styles.mode}><Text style={styles.modeText}>QR / BARCODE</Text></View><Pressable accessibilityRole="button" accessibilityLabel={torch ? 'Turn torch off' : 'Turn torch on'} accessibilityState={{ checked: torch }} onPress={() => setTorch((current) => !current)} style={styles.close}><Ionicons name={torch ? 'flash' : 'flash-outline'} size={21} color={torch ? HC.cyan : HC.white} /></Pressable></View>
      <View style={styles.reticle}><View style={[styles.corner, styles.tl]} /><View style={[styles.corner, styles.tr]} /><View style={[styles.corner, styles.bl]} /><View style={[styles.corner, styles.br]} /></View>
      <View style={styles.bottom}>{captureFocus !== 'overall' && <View style={styles.guideCard}><Text style={styles.guideTitle}>{captureGuide.title}</Text><Text style={styles.guideTip}>{captureGuide.tip}</Text>{captureGuide.steps.map((step, index) => <Pressable key={step} accessibilityRole="checkbox" accessibilityState={{ checked: Boolean(checkedSteps[index]) }} accessibilityLabel={`Capture checklist: ${step}`} onPress={() => setCheckedSteps((current) => ({ ...current, [index]: !current[index] }))} style={styles.guideStep}><View style={[styles.checkbox, checkedSteps[index] && styles.checkboxChecked]}>{checkedSteps[index] && <Ionicons name="checkmark" size={12} color={HC.ink} />}</View><Text style={[styles.guideStepText, checkedSteps[index] && styles.guideStepTextChecked]}>{step}</Text></Pressable>)}</View>}<Text accessibilityRole="header" style={styles.instruction}>{captureFocus === 'overall' ? 'Center the code in the frame' : `Capture evidence for ${captureFocus}`}</Text><Pressable accessibilityRole="button" accessibilityLabel="Use demo AI result" onPress={() => router.push(createScanResultRoute({ focus: captureFocus }))} style={({ pressed }) => [styles.demoButton, pressed && { opacity: 0.8 }]}><Ionicons name="sparkles-outline" size={18} color={HC.ink} /><Text style={styles.demoText}>Use demo result</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Choose product photos" onPress={pickProductPhoto}><Text style={styles.photoLink}>Choose product photos</Text></Pressable></View>
    </View>
  </ScreenContainer>;
}
const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: HC.ink }, fallback: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 38, backgroundColor: HC.ink }, fallbackIcon: { width: 70, height: 70, borderRadius: 24, backgroundColor: 'rgba(66,232,208,0.12)', alignItems: 'center', justifyContent: 'center', marginBottom: 20 }, fallbackTitle: { color: HC.white, fontSize: 27, fontWeight: '800' }, fallbackBody: { color: 'rgba(255,255,255,0.64)', textAlign: 'center', lineHeight: 20, fontSize: 14, marginTop: 10, maxWidth: 280 }, permissionButton: { backgroundColor: HC.cyan, borderRadius: 15, paddingHorizontal: 20, paddingVertical: 14, marginTop: 26 }, permissionText: { color: HC.ink, fontWeight: '800' }, header: { position: 'absolute', top: 16, left: 18, right: 18, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, close: { width: 44, height: 44, borderRadius: 15, backgroundColor: 'rgba(7,17,31,0.62)', alignItems: 'center', justifyContent: 'center' }, mode: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, backgroundColor: 'rgba(7,17,31,0.62)' }, modeText: { color: HC.cyan, fontSize: 10, letterSpacing: 1.2, fontWeight: '800' }, reticle: { position: 'absolute', left: 36, right: 36, top: '32%', height: 210 }, corner: { position: 'absolute', width: 30, height: 30, borderColor: HC.cyan }, tl: { left: 0, top: 0, borderLeftWidth: 3, borderTopWidth: 3 }, tr: { right: 0, top: 0, borderRightWidth: 3, borderTopWidth: 3 }, bl: { left: 0, bottom: 0, borderLeftWidth: 3, borderBottomWidth: 3 }, br: { right: 0, bottom: 0, borderRightWidth: 3, borderBottomWidth: 3 }, bottom: { position: 'absolute', left: 22, right: 22, bottom: 25, alignItems: 'center' }, guideCard: { alignSelf: 'stretch', backgroundColor: 'rgba(7,17,31,0.86)', borderWidth: 1, borderColor: 'rgba(66,232,208,0.34)', borderRadius: 18, padding: 13, marginBottom: 14 }, guideTitle: { color: HC.white, fontSize: 13, fontWeight: '800' }, guideTip: { color: 'rgba(255,255,255,0.64)', fontSize: 11, lineHeight: 15, marginTop: 5, marginBottom: 7 }, guideStep: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 5 }, checkbox: { width: 19, height: 19, borderRadius: 6, borderWidth: 1, borderColor: 'rgba(255,255,255,0.42)', alignItems: 'center', justifyContent: 'center' }, checkboxChecked: { backgroundColor: HC.cyan, borderColor: HC.cyan }, guideStepText: { color: 'rgba(255,255,255,0.8)', fontSize: 11, fontWeight: '700', flex: 1 }, guideStepTextChecked: { color: HC.cyan }, instruction: { color: HC.white, fontSize: 14, fontWeight: '700', marginBottom: 16 }, demoButton: { backgroundColor: HC.cyan, borderRadius: 16, paddingVertical: 15, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', gap: 8 }, demoText: { color: HC.ink, fontWeight: '800' }, photoLink: { color: 'rgba(255,255,255,0.72)', fontSize: 13, fontWeight: '700', marginTop: 17 }, });
