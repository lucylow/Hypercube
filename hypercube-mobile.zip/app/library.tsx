import { useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useCallback, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { Panel, StatusPill } from '@/components/hypercube-ui';
import { ScreenState } from '@/components/ui/screen-state';
import { HC } from '@/constants/hypercube';
import { UI } from '@/constants/ui';
import { clearAnalysisHistory, readAnalysisHistory, replaceAnalysisHistory } from '@/lib/analysis-storage';
import { exportAnalysisRecords, exportAnalysisSetCsv } from '@/lib/analysis-export';
import { appendExportHistory, readExportHistory, type ExportFormat, type ExportHistoryEntry } from '@/lib/export-history';
import { analysisSourceLabel, analysisStateLabel, verdictPresentation } from '@/shared/analysis-result';
import { filterAnalysisHistory, removeAnalysisRecords, sortAnalysisHistory, toggleVisibleSelection, type LibraryFilter, type LibrarySort } from '@/shared/library';
import type { AnalysisRecord } from '@/shared/ai-history';

const FILTERS: { key: LibraryFilter; label: string }[] = [
  { key: 'All', label: 'All' },
  { key: 'high_risk', label: 'High risk' },
  { key: 'needs_review', label: 'Needs review' },
  { key: 'low_risk', label: 'Low risk' },
];

const SORTS: { key: LibrarySort; label: string }[] = [
  { key: 'recent', label: 'Recent' },
  { key: 'confidence', label: 'Confidence' },
  { key: 'risk', label: 'Risk' },
];

export default function LibraryScreen() {
  const router = useRouter();
  const [records, setRecords] = useState<AnalysisRecord[]>([]);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<LibraryFilter>('All');
  const [sort, setSort] = useState<LibrarySort>('recent');
  const [loading, setLoading] = useState(true);
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [clearing, setClearing] = useState(false);
  const [undoSnapshot, setUndoSnapshot] = useState<AnalysisRecord[] | null>(null);
  const [exporting, setExporting] = useState(false);
  const [exportHistory, setExportHistory] = useState<ExportHistoryEntry[]>([]);
  const [retryRequest, setRetryRequest] = useState<{ records: AnalysisRecord[]; scope: 'filtered' | 'selected'; format: ExportFormat } | null>(null);

  const reload = useCallback(() => {
    let active = true;
    setLoading(true);
    void readAnalysisHistory().then((next) => {
      if (active) setRecords(next);
    }).finally(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, []);

  useFocusEffect(reload);

  useFocusEffect(useCallback(() => {
    void readExportHistory().then(setExportHistory);
  }, []));

  const visibleRecords = useMemo(() => {
    const filtered = filterAnalysisHistory(records, query, filter);
    return sortAnalysisHistory(filtered, sort);
  }, [records, query, filter, sort]);

  const toggleSelected = useCallback((recordId: string) => {
    setSelectedIds((current) => current.includes(recordId) ? current.filter((id) => id !== recordId) : [...current, recordId]);
  }, []);

  const toggleVisible = useCallback(() => {
    setSelectedIds((current) => toggleVisibleSelection(current, visibleRecords.map((record) => record.id)));
  }, [visibleRecords]);

  const executeExport = useCallback((request: { records: AnalysisRecord[]; scope: 'filtered' | 'selected'; format: ExportFormat }) => {
    setExporting(true);
    const exportTask = request.format === 'csv' ? exportAnalysisSetCsv(request.records, request.scope) : exportAnalysisRecords(request.records, request.scope);
    void exportTask.then((result) => {
      const entry: ExportHistoryEntry = { id: `${request.scope}-${request.format}-${Date.now()}`, createdAt: new Date().toISOString(), scope: request.scope, format: request.format, count: request.records.length, status: result, records: request.records };
      setRetryRequest(result === 'unavailable' ? request : null);
      setExportHistory((current) => [entry, ...current].slice(0, 10));
      void appendExportHistory(entry);
      if (result === 'unavailable') Alert.alert('Export unavailable', 'This device cannot share or download the selected reviews right now.');
    }).catch(() => {
      const entry: ExportHistoryEntry = { id: `${request.scope}-${request.format}-${Date.now()}`, createdAt: new Date().toISOString(), scope: request.scope, format: request.format, count: request.records.length, status: 'failed', records: request.records };
      setRetryRequest(request);
      setExportHistory((current) => [entry, ...current].slice(0, 10));
      void appendExportHistory(entry);
      Alert.alert('Export failed', 'The review set could not be exported.');
    }).finally(() => setExporting(false));
  }, []);

  const exportReviewSet = useCallback((scope: 'filtered' | 'selected', format: ExportFormat = 'json') => {
    const recordsToExport = scope === 'selected' ? records.filter((record) => selectedIds.includes(record.id)) : visibleRecords;
    if (!recordsToExport.length) return;
    const request = { records: recordsToExport, scope, format } as const;
    setRetryRequest(request);
    executeExport(request);
  }, [executeExport, records, selectedIds, visibleRecords]);

  const confirmDelete = useCallback((record: AnalysisRecord) => {
    Alert.alert('Delete saved review?', `This will remove ${record.code ?? 'this product scan'} from this device.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => {
        const snapshot = records;
        const next = records.filter((item) => item.id !== record.id);
        void replaceAnalysisHistory(next).then(() => { setUndoSnapshot(snapshot); setRecords(next); }).catch(() => Alert.alert('Could not delete review', 'The saved review is still in your library.'));
      } },
    ]);
  }, [records]);

  const confirmBulkDelete = useCallback(() => {
    if (!selectedIds.length) return;
    Alert.alert('Delete selected reviews?', `${selectedIds.length} saved review${selectedIds.length === 1 ? '' : 's'} will be removed from this device.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete selected', style: 'destructive', onPress: () => {
        const snapshot = records;
        const next = removeAnalysisRecords(records, selectedIds);
        void replaceAnalysisHistory(next).then(() => { setUndoSnapshot(snapshot); setRecords(next); setSelectedIds([]); setSelectMode(false); }).catch(() => Alert.alert('Could not delete reviews', 'The selected reviews are still in your library.'));
      } },
    ]);
  }, [records, selectedIds]);

  const undoDelete = useCallback(() => {
    if (!undoSnapshot) return;
    void replaceAnalysisHistory(undoSnapshot).then(() => { setRecords(undoSnapshot); setUndoSnapshot(null); }).catch(() => Alert.alert('Could not restore reviews', 'The deleted reviews could not be restored.'));
  }, [undoSnapshot]);

  const confirmClear = useCallback(() => {
    Alert.alert('Clear analysis library?', 'All saved reviews will be permanently removed from this device.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Clear library',
        style: 'destructive',
        onPress: () => {
          setClearing(true);
          void clearAnalysisHistory().then(() => setRecords([])).catch(() => {
            Alert.alert('Could not clear library', 'Your saved reviews are still available.');
          }).finally(() => setClearing(false));
        },
      },
    ]);
  }, []);

  if (loading) return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5"><ScreenState kind="loading" title="Loading library" description="Restoring saved authenticity reviews from this device." /></ScreenContainer>;

  return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3"><FlatList
    data={visibleRecords}
    keyExtractor={(item) => item.id}
    showsVerticalScrollIndicator={false}
    contentContainerStyle={styles.content}
    ListHeaderComponent={<View>
      <View style={styles.header}><View><Text style={styles.eyebrow}>LOCAL INTELLIGENCE</Text><Text style={styles.title}>Analysis library</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => router.back()} hitSlop={UI.control.hitSlop}><Ionicons name="close" size={24} color={HC.text} /></Pressable></View>
      <View style={styles.searchBox}><Ionicons name="search-outline" size={18} color={HC.muted} /><TextInput accessibilityLabel="Search saved analyses" value={query} onChangeText={setQuery} placeholder="Search code, focus, or summary" placeholderTextColor={HC.muted} style={styles.searchInput} returnKeyType="search" /></View>
      <FlatList horizontal data={FILTERS} keyExtractor={(item) => item.key} showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filters} renderItem={({ item }) => <Pressable accessibilityRole="button" accessibilityLabel={`Filter library by ${item.label}`} accessibilityState={{ selected: filter === item.key }} onPress={() => setFilter(item.key)} style={[styles.filter, filter === item.key && styles.filterActive]}><Text style={[styles.filterText, filter === item.key && styles.filterTextActive]}>{item.label}</Text></Pressable>} />
      <View style={styles.managementRow}><Text style={styles.count}>{selectMode ? `${selectedIds.length} selected` : `${visibleRecords.length} saved review${visibleRecords.length === 1 ? '' : 's'}`}</Text><View style={styles.managementActions}><Pressable accessibilityRole="button" accessibilityLabel="Export current filtered reviews" accessibilityState={{ disabled: !visibleRecords.length || exporting }} disabled={!visibleRecords.length || exporting} onPress={() => exportReviewSet('filtered')} style={({ pressed }) => [styles.manageButton, (!visibleRecords.length || exporting) && styles.disabled, pressed && styles.pressed]}><Ionicons name="download-outline" size={14} color={HC.blue} /><Text style={styles.manageText}>{exporting ? 'Exporting…' : 'Export view'}</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Export current filtered reviews as CSV" accessibilityState={{ disabled: !visibleRecords.length || exporting }} disabled={!visibleRecords.length || exporting} onPress={() => exportReviewSet('filtered', 'csv')} style={({ pressed }) => [styles.manageButton, (!visibleRecords.length || exporting) && styles.disabled, pressed && styles.pressed]}><Ionicons name="document-text-outline" size={14} color={HC.blue} /><Text style={styles.manageText}>CSV</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={selectMode ? 'Exit selection mode' : 'Select saved reviews'} onPress={() => { setSelectMode((current) => !current); setSelectedIds([]); }} style={({ pressed }) => [styles.manageButton, pressed && styles.pressed]}><Ionicons name={selectMode ? 'close-outline' : 'checkmark-circle-outline'} size={14} color={HC.blue} /><Text style={styles.manageText}>{selectMode ? 'Done' : 'Select'}</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Clear all saved reviews" accessibilityState={{ disabled: !records.length || clearing }} disabled={!records.length || clearing} onPress={confirmClear} style={({ pressed }) => [styles.clearButton, (!records.length || clearing) && styles.disabled, pressed && styles.pressed]}><Ionicons name="trash-outline" size={14} color={HC.danger} /><Text style={styles.clearText}>{clearing ? 'Clearing…' : 'Clear all'}</Text></Pressable></View></View>
      {selectMode && <View style={styles.selectionActions}><Pressable accessibilityRole="button" accessibilityLabel="Select or clear all visible saved reviews" accessibilityState={{ selected: visibleRecords.length > 0 && visibleRecords.every((record) => selectedIds.includes(record.id)) }} onPress={toggleVisible} style={({ pressed }) => [styles.secondaryAction, pressed && styles.pressed]}><Ionicons name="checkmark-done-outline" size={15} color={HC.blue} /><Text style={styles.secondaryActionText}>{visibleRecords.length > 0 && visibleRecords.every((record) => selectedIds.includes(record.id)) ? 'Clear visible' : 'Select visible'}</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Clear all selected reviews" accessibilityState={{ disabled: selectedIds.length === 0 }} disabled={!selectedIds.length} onPress={() => setSelectedIds([])} style={({ pressed }) => [styles.secondaryAction, !selectedIds.length && styles.disabled, pressed && styles.pressed]}><Ionicons name="close-circle-outline" size={15} color={HC.muted} /><Text style={styles.secondaryActionText}>Clear selection</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Export selected saved reviews" accessibilityState={{ disabled: selectedIds.length === 0 || exporting }} disabled={!selectedIds.length || exporting} onPress={() => exportReviewSet('selected')} style={({ pressed }) => [styles.secondaryAction, (!selectedIds.length || exporting) && styles.disabled, pressed && styles.pressed]}><Ionicons name="download-outline" size={15} color={HC.blue} /><Text style={styles.secondaryActionText}>{exporting ? 'Exporting…' : 'Export selected'}</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Export selected saved reviews as CSV" accessibilityState={{ disabled: selectedIds.length === 0 || exporting }} disabled={!selectedIds.length || exporting} onPress={() => exportReviewSet('selected', 'csv')} style={({ pressed }) => [styles.secondaryAction, (!selectedIds.length || exporting) && styles.disabled, pressed && styles.pressed]}><Ionicons name="document-text-outline" size={15} color={HC.blue} /><Text style={styles.secondaryActionText}>Export CSV</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel="Delete selected saved reviews" accessibilityState={{ disabled: selectedIds.length === 0 }} disabled={!selectedIds.length} onPress={confirmBulkDelete} style={({ pressed }) => [styles.bulkDelete, !selectedIds.length && styles.disabled, pressed && styles.pressed]}><Ionicons name="trash-outline" size={15} color={HC.white} /><Text style={styles.bulkDeleteText}>Delete selected ({selectedIds.length})</Text></Pressable></View>}
      {undoSnapshot && <View style={styles.undoBanner}><Text style={styles.undoText}>Review deletion completed</Text><Pressable accessibilityRole="button" accessibilityLabel="Undo review deletion" onPress={undoDelete} style={({ pressed }) => [styles.undoButton, pressed && styles.pressed]}><Text style={styles.undoButtonText}>Undo</Text></Pressable></View>}
      {retryRequest && <View style={styles.retryBanner}><View><Text style={styles.retryTitle}>Export needs attention</Text><Text style={styles.retryMeta}>{retryRequest.records.length} {retryRequest.format.toUpperCase()} review{retryRequest.records.length === 1 ? '' : 's'}</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Retry export" onPress={() => executeExport(retryRequest)} style={({ pressed }) => [styles.undoButton, pressed && styles.pressed]}><Text style={styles.undoButtonText}>Retry</Text></Pressable></View>}
      {exportHistory.length > 0 && <View style={styles.historyBox}><View style={styles.historyHeader}><Text style={styles.historyTitle}>Recent exports</Text><Pressable accessibilityRole="button" accessibilityLabel="View all export history" onPress={() => router.push('/export-history')}><Text style={styles.historyLink}>View all</Text></Pressable></View>{exportHistory.slice(0, 3).map((entry) => <View key={entry.id} style={styles.historyRow}><Text style={styles.historyMeta}>{entry.format.toUpperCase()} · {entry.scope} · {entry.count} review{entry.count === 1 ? '' : 's'}</Text><Text style={styles.historyStatus}>{entry.status === 'failed' || entry.status === 'unavailable' ? 'Needs retry' : new Date(entry.createdAt).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}</Text></View>)}</View>}
      <FlatList horizontal data={SORTS} keyExtractor={(item) => item.key} showsHorizontalScrollIndicator={false} contentContainerStyle={styles.sorts} renderItem={({ item }) => <Pressable accessibilityRole="button" accessibilityLabel={`Sort library by ${item.label}`} accessibilityState={{ selected: sort === item.key }} onPress={() => setSort(item.key)} style={[styles.sort, sort === item.key && styles.sortActive]}><Ionicons name={sort === item.key ? 'arrow-down' : 'swap-vertical-outline'} size={13} color={sort === item.key ? HC.blue : HC.muted} /><Text style={[styles.sortText, sort === item.key && styles.sortTextActive]}>{item.label}</Text></Pressable>} />
    </View>}
    renderItem={({ item }) => <AnalysisRow record={item} selected={selectedIds.includes(item.id)} selectMode={selectMode} onToggleSelect={() => toggleSelected(item.id)} onPress={() => router.push({ pathname: '/library/[recordId]', params: { recordId: item.id } })} onDelete={() => confirmDelete(item)} />}
    ListEmptyComponent={<ScreenState kind="empty" title={records.length ? 'No matching reviews' : 'No saved reviews yet'} description={records.length ? 'Try another search, verdict filter, or sort option.' : 'Save an AI analysis from the result screen to build your local library.'} />}
  /></ScreenContainer>;
}

function AnalysisRow({ record, selected, selectMode, onToggleSelect, onPress, onDelete }: { record: AnalysisRecord; selected: boolean; selectMode: boolean; onToggleSelect: () => void; onPress: () => void; onDelete: () => void }) {
  const presentation = verdictPresentation(record.analysis.verdict);
  const date = new Date(record.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  return <Panel style={[styles.row, selected && styles.rowSelected]}><View style={styles.rowTop}>{selectMode && <Pressable accessibilityRole="checkbox" accessibilityLabel={`Select ${record.code ?? 'product scan'} review`} accessibilityState={{ checked: selected }} onPress={onToggleSelect} hitSlop={UI.control.hitSlop} style={styles.checkbox}><Ionicons name={selected ? 'checkmark-circle' : 'ellipse-outline'} size={22} color={selected ? HC.blue : HC.muted} /></Pressable>}<Pressable accessibilityRole="button" accessibilityLabel={`Open ${presentation.label} analysis for ${record.code ?? 'product scan'}`} onPress={onPress} style={({ pressed }) => [styles.rowPress, pressed && { opacity: 0.72 }]}><View style={styles.icon}><Ionicons name="scan-outline" size={18} color={HC.blue} /></View><View style={styles.rowCopy}><Text style={styles.code}>{record.code ?? 'Product scan'}</Text><Text style={styles.meta}>{record.focus} · {date} · {analysisSourceLabel(record.analysis)}</Text></View><StatusPill label={presentation.label} tone={presentation.tone} /></Pressable>{!selectMode && <Pressable accessibilityRole="button" accessibilityLabel={`Delete ${record.code ?? 'product scan'} review`} onPress={onDelete} hitSlop={UI.control.hitSlop} style={({ pressed }) => [styles.deleteButton, pressed && styles.pressed]}><Ionicons name="trash-outline" size={17} color={HC.danger} /></Pressable>}</View><Pressable accessibilityRole="button" accessibilityLabel={`Open details for ${record.code ?? 'product scan'}`} onPress={onPress}><Text numberOfLines={2} style={styles.summary}>{record.analysis.summary}</Text><View style={styles.rowFooter}><Text style={styles.state}>{analysisStateLabel({ isProvisional: false, fallback: record.analysis.fallback })}</Text><Text style={styles.confidence}>{record.analysis.confidence}% confidence</Text></View></Pressable></Panel>;
}

const styles = StyleSheet.create({ content: { paddingBottom: UI.spacing.xxl }, header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: UI.spacing.lg }, eyebrow: { color: HC.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.1 }, title: { color: HC.text, fontSize: 27, fontWeight: '800', marginTop: 5 }, searchBox: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line, borderRadius: UI.radius.md, paddingHorizontal: 13, minHeight: 48 }, searchInput: { flex: 1, color: HC.text, fontSize: 14 }, filters: { gap: UI.spacing.sm, paddingVertical: UI.spacing.md }, filter: { paddingHorizontal: 13, paddingVertical: 9, borderRadius: UI.radius.pill, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line }, filterActive: { backgroundColor: HC.ink, borderColor: HC.ink }, filterText: { color: HC.muted, fontSize: 12, fontWeight: '800' }, filterTextActive: { color: HC.cyan }, managementRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 26 }, managementActions: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.md }, manageButton: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingVertical: 5 }, manageText: { color: HC.blue, fontSize: 12, fontWeight: '800' }, selectionActions: { gap: UI.spacing.sm, marginBottom: UI.spacing.sm }, secondaryAction: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line, borderRadius: UI.radius.md, paddingVertical: 9 }, secondaryActionText: { color: HC.blue, fontSize: 12, fontWeight: '800' }, bulkDelete: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: HC.danger, borderRadius: UI.radius.md, paddingVertical: 11 }, bulkDeleteText: { color: HC.white, fontSize: 12, fontWeight: '800' }, undoBanner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#E5F7F4', borderRadius: UI.radius.md, paddingHorizontal: 12, paddingVertical: 10, marginBottom: UI.spacing.sm }, undoText: { color: HC.ink, fontSize: 12, fontWeight: '700' }, undoButton: { paddingHorizontal: 8, paddingVertical: 4 }, undoButtonText: { color: HC.blue, fontSize: 12, fontWeight: '900' }, retryBanner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#FFF4DD', borderRadius: UI.radius.md, paddingHorizontal: 12, paddingVertical: 10, marginBottom: UI.spacing.sm }, retryTitle: { color: HC.ink, fontSize: 12, fontWeight: '800' }, retryMeta: { color: HC.muted, fontSize: 11, marginTop: 3 }, historyBox: { backgroundColor: HC.white, borderRadius: UI.radius.md, borderWidth: 1, borderColor: HC.line, paddingHorizontal: 12, paddingVertical: 10, marginBottom: UI.spacing.sm }, historyHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }, historyTitle: { color: HC.text, fontSize: 12, fontWeight: '800' }, historyLink: { color: HC.blue, fontSize: 11, fontWeight: '800' }, historyRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 }, historyMeta: { color: HC.muted, fontSize: 10, fontWeight: '700' }, historyStatus: { color: HC.blue, fontSize: 10, fontWeight: '800' }, count: { color: HC.muted, fontSize: 12, fontWeight: '700' }, clearButton: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingVertical: 5 }, clearText: { color: HC.danger, fontSize: 12, fontWeight: '800' }, disabled: { opacity: 0.4 }, sorts: { gap: UI.spacing.sm, paddingTop: UI.spacing.sm, paddingBottom: UI.spacing.md }, sort: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 7, borderRadius: UI.radius.pill, backgroundColor: '#EEF3FF' }, sortActive: { backgroundColor: '#DCE8FF' }, sortText: { color: HC.muted, fontSize: 11, fontWeight: '800' }, sortTextActive: { color: HC.blue }, row: { marginBottom: UI.spacing.sm }, rowSelected: { borderColor: HC.blue, borderWidth: 1 }, rowDeleting: { opacity: 0.55 }, checkbox: { width: 28, alignItems: 'center', justifyContent: 'center' }, rowTop: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm }, rowPress: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm }, icon: { width: 40, height: 40, borderRadius: UI.radius.sm, backgroundColor: '#EEF3FF', alignItems: 'center', justifyContent: 'center' }, rowCopy: { flex: 1 }, code: { color: HC.text, fontSize: 14, fontWeight: '800' }, meta: { color: HC.muted, fontSize: 11, marginTop: 4 }, deleteButton: { width: 32, height: 32, borderRadius: UI.radius.sm, alignItems: 'center', justifyContent: 'center' }, pressed: { opacity: 0.65 }, summary: { color: HC.text, fontSize: 13, lineHeight: 18, marginTop: UI.spacing.md }, rowFooter: { flexDirection: 'row', justifyContent: 'space-between', marginTop: UI.spacing.md }, state: { color: HC.muted, fontSize: 11, fontWeight: '700' }, confidence: { color: HC.blue, fontSize: 11, fontWeight: '800' }, });
