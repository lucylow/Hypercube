import { useCallback, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { ScreenContainer } from '@/components/screen-container';
import { Panel } from '@/components/hypercube-ui';
import { ScreenState } from '@/components/ui/screen-state';
import { HC } from '@/constants/hypercube';
import { UI } from '@/constants/ui';
import { exportAnalysisRecords, exportAnalysisSetCsv } from '@/lib/analysis-export';
import { clearExportHistory, deleteExportHistoryEntries, deleteExportHistoryEntry, isEvidenceAuditExport, readExportHistory, removeExportHistoryEntries, removeExportHistoryEntry, type ExportHistoryEntry } from '@/lib/export-history';

export default function ExportHistoryScreen() {
  const router = useRouter();
  const [history, setHistory] = useState<ExportHistoryEntry[]>([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [workingId, setWorkingId] = useState<string | null>(null);
  const [sort, setSort] = useState<'newest' | 'oldest' | 'status'>('newest');
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const load = useCallback(() => {
    setLoading(true);
    void readExportHistory().then(setHistory).finally(() => setLoading(false));
  }, []);
  useFocusEffect(load);

  const visible = useMemo(() => {
    const filtered = history.filter((entry) => `${entry.format} ${entry.scope} ${entry.status} ${entry.count}`.toLowerCase().includes(query.toLowerCase().trim()));
    return [...filtered].sort((a, b) => sort === 'oldest' ? a.createdAt.localeCompare(b.createdAt) : sort === 'status' ? a.status.localeCompare(b.status) || b.createdAt.localeCompare(a.createdAt) : b.createdAt.localeCompare(a.createdAt));
  }, [history, query, sort]);

  const retry = useCallback((entry: ExportHistoryEntry) => {
    if (isEvidenceAuditExport(entry)) {
      Alert.alert('Audit export retry', 'Open the evidence draft audit screen to generate a fresh JSON or CSV handoff from the latest local timeline.');
      return;
    }
    if (!entry.records?.length) {
      Alert.alert('Retry unavailable', 'This older export does not contain a local review snapshot.');
      return;
    }
    setWorkingId(entry.id);
    const task = entry.format === 'csv' ? exportAnalysisSetCsv(entry.records, entry.scope) : exportAnalysisRecords(entry.records, entry.scope);
    void task.then((result) => {
      setHistory((current) => current.map((item) => item.id === entry.id ? { ...item, status: result } : item));
      if (result === 'unavailable') Alert.alert('Export unavailable', 'Sharing or download is still unavailable on this device.');
    }).catch(() => Alert.alert('Retry failed', 'The export could not be completed.')).finally(() => setWorkingId(null));
  }, []);

  const confirmDelete = useCallback((entry: ExportHistoryEntry) => {
    Alert.alert('Delete export entry?', 'This removes the handoff record but does not affect saved analyses.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { void deleteExportHistoryEntry(entry.id).then(() => setHistory((current) => removeExportHistoryEntry(current, entry.id))); } },
    ]);
  }, []);

  const toggleSelected = useCallback((id: string) => {
    setSelectedIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }, []);

  const toggleVisible = useCallback(() => {
    const visibleIds = visible.map((entry) => entry.id);
    setSelectedIds((current) => visibleIds.length > 0 && visibleIds.every((id) => current.includes(id)) ? current.filter((id) => !visibleIds.includes(id)) : [...new Set([...current, ...visibleIds])]);
  }, [visible]);

  const confirmBulkDelete = useCallback(() => {
    if (!selectedIds.length) return;
    Alert.alert('Delete selected exports?', `${selectedIds.length} export record${selectedIds.length === 1 ? '' : 's'} will be removed from this device.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete selected', style: 'destructive', onPress: () => { void deleteExportHistoryEntries(selectedIds).then(() => { setHistory((current) => removeExportHistoryEntries(current, selectedIds)); setSelectedIds([]); setSelectMode(false); }); } },
    ]);
  }, [selectedIds]);

  const confirmClear = useCallback(() => {
    Alert.alert('Clear export history?', 'This removes export activity from this device. Saved analyses are not affected.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear history', style: 'destructive', onPress: () => { void clearExportHistory().then(() => { setHistory([]); setSelectedIds([]); }); } },
    ]);
  }, []);

  if (loading) return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5"><ScreenState kind="loading" title="Loading export history" description="Restoring local investigation handoffs." /></ScreenContainer>;

  const allVisibleSelected = visible.length > 0 && visible.every((entry) => selectedIds.includes(entry.id));

  return (
    <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3">
      <FlatList
        data={visible}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View>
            <View style={styles.header}>
              <View><Text style={styles.eyebrow}>INVESTIGATION HANDOFF</Text><Text style={styles.title}>Export history</Text></View>
              <Pressable accessibilityRole="button" accessibilityLabel="Go back" onPress={() => router.back()} hitSlop={UI.control.hitSlop}><Ionicons name="close" size={24} color={HC.text} /></Pressable>
            </View>
            <View style={styles.search}><Ionicons name="search-outline" size={18} color={HC.muted} /><TextInput accessibilityLabel="Search export history" value={query} onChangeText={setQuery} placeholder="Search format, scope, or status" placeholderTextColor={HC.muted} style={styles.input} /></View>
            <View style={styles.toolbar}>
              <Text style={styles.count}>{selectMode ? `${selectedIds.length} selected` : `${visible.length} export${visible.length === 1 ? '' : 's'}`}</Text>
              <View style={styles.toolbarActions}>
                <Pressable accessibilityRole="button" accessibilityLabel={selectMode ? 'Exit export selection mode' : 'Select export records'} onPress={() => { setSelectMode((current) => !current); setSelectedIds([]); }} style={styles.sortButton}><Ionicons name={selectMode ? 'close-outline' : 'checkmark-circle-outline'} size={14} color={HC.blue} /><Text style={styles.sortText}>{selectMode ? 'Done' : 'Select'}</Text></Pressable>
                <Pressable accessibilityRole="button" accessibilityLabel="Sort export history" onPress={() => setSort((current) => current === 'newest' ? 'oldest' : current === 'oldest' ? 'status' : 'newest')} style={styles.sortButton}><Ionicons name="swap-vertical-outline" size={14} color={HC.blue} /><Text style={styles.sortText}>{sort === 'newest' ? 'Newest' : sort === 'oldest' ? 'Oldest' : 'Status'}</Text></Pressable>
                <Pressable accessibilityRole="button" accessibilityLabel="Clear export history" accessibilityState={{ disabled: !history.length }} disabled={!history.length} onPress={confirmClear} style={({ pressed }) => [styles.clear, !history.length && styles.disabled, pressed && styles.pressed]}><Ionicons name="trash-outline" size={15} color={HC.danger} /><Text style={styles.clearText}>Clear history</Text></Pressable>
              </View>
            </View>
            {selectMode && <View style={styles.selectionBar}>
              <Pressable accessibilityRole="button" accessibilityLabel="Select or clear visible export records" onPress={toggleVisible} style={styles.sortButton}><Ionicons name="checkmark-done-outline" size={15} color={HC.blue} /><Text style={styles.sortText}>{allVisibleSelected ? 'Clear visible' : 'Select visible'}</Text></Pressable>
              <Pressable accessibilityRole="button" accessibilityLabel="Clear selected export records" accessibilityState={{ disabled: !selectedIds.length }} disabled={!selectedIds.length} onPress={() => setSelectedIds([])} style={[styles.sortButton, !selectedIds.length && styles.disabled]}><Text style={styles.sortText}>Clear selection</Text></Pressable>
              <Pressable accessibilityRole="button" accessibilityLabel="Delete selected export records" accessibilityState={{ disabled: !selectedIds.length }} disabled={!selectedIds.length} onPress={confirmBulkDelete} style={[styles.bulkDelete, !selectedIds.length && styles.disabled]}><Ionicons name="trash-outline" size={14} color={HC.white} /><Text style={styles.bulkDeleteText}>Delete ({selectedIds.length})</Text></Pressable>
            </View>}
          </View>
        }
        renderItem={({ item }) => (
          <Panel style={styles.card}>
            <View style={styles.cardTop}>
              {selectMode && <Pressable accessibilityRole="checkbox" accessibilityLabel="Select export record" accessibilityState={{ checked: selectedIds.includes(item.id) }} onPress={() => toggleSelected(item.id)} style={styles.checkbox}><Ionicons name={selectedIds.includes(item.id) ? 'checkmark-circle' : 'ellipse-outline'} size={21} color={selectedIds.includes(item.id) ? HC.blue : HC.muted} /></Pressable>}
              <View style={styles.icon}><Ionicons name={isEvidenceAuditExport(item) ? 'shield-checkmark-outline' : item.format === 'csv' ? 'document-text-outline' : 'code-slash-outline'} size={18} color={HC.blue} /></View>
              <View style={styles.copy}><Text style={styles.name}>{isEvidenceAuditExport(item) ? 'AUDIT' : item.format.toUpperCase()} · {item.scope}</Text><Text style={styles.meta}>{item.count} {isEvidenceAuditExport(item) ? `event${item.count === 1 ? '' : 's'}` : `review${item.count === 1 ? '' : 's'}`} · {new Date(item.createdAt).toLocaleString()}</Text></View>
              <Text style={[styles.status, (item.status === 'failed' || item.status === 'unavailable') && styles.statusBad]}>{item.status === 'downloaded' ? 'Downloaded' : item.status === 'shared' ? 'Shared' : 'Needs retry'}</Text>
              {isEvidenceAuditExport(item) && item.caseId && !selectMode && <Pressable accessibilityRole="button" accessibilityLabel="Open source evidence draft" onPress={() => router.push({ pathname: '/evidence-drafts/[caseId]', params: { caseId: item.caseId! } })} style={styles.openDraft}><Ionicons name="arrow-forward-circle-outline" size={16} color={HC.blue} /></Pressable>}
              {!selectMode && <Pressable accessibilityRole="button" accessibilityLabel="Delete export entry" onPress={() => confirmDelete(item)} hitSlop={UI.control.hitSlop} style={styles.delete}><Ionicons name="trash-outline" size={16} color={HC.danger} /></Pressable>}
            </View>
            {(item.status === 'failed' || item.status === 'unavailable') && <Pressable accessibilityRole="button" accessibilityLabel="Retry this export" onPress={() => retry(item)} style={({ pressed }) => [styles.retry, workingId === item.id && styles.disabled, pressed && styles.pressed]} disabled={workingId === item.id}><Ionicons name="refresh-outline" size={15} color={HC.blue} /><Text style={styles.retryText}>{workingId === item.id ? 'Retrying…' : 'Retry export'}</Text></Pressable>}
          </Panel>
        )}
        ListEmptyComponent={<ScreenState kind="empty" title={history.length ? 'No matching exports' : 'No exports yet'} description={history.length ? 'Try another format, scope, or status.' : 'Export a filtered review timeline from an evidence draft or review set from the Analysis Library.'} />}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingBottom: UI.spacing.xxl }, header: { marginBottom: UI.spacing.md }, eyebrow: { color: HC.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.1 }, title: { color: HC.text, fontSize: 27, fontWeight: '800', marginTop: 5 }, search: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm, backgroundColor: HC.white, borderWidth: 1, borderColor: HC.line, borderRadius: UI.radius.md, paddingHorizontal: 13, minHeight: 48, marginTop: UI.spacing.md }, input: { flex: 1, color: HC.text, fontSize: 14 }, toolbar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: UI.spacing.md }, toolbarActions: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.md }, sortButton: { flexDirection: 'row', alignItems: 'center', gap: 5 }, sortText: { color: HC.blue, fontSize: 11, fontWeight: '800' }, selectionBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: UI.spacing.sm, marginTop: UI.spacing.md, paddingVertical: 9, paddingHorizontal: 10, backgroundColor: '#EEF3FF', borderRadius: UI.radius.md }, count: { color: HC.muted, fontSize: 12, fontWeight: '700' }, clear: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingVertical: 6 }, clearText: { color: HC.danger, fontSize: 12, fontWeight: '800' }, disabled: { opacity: 0.4 }, pressed: { opacity: 0.65 }, bulkDelete: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: HC.danger, borderRadius: UI.radius.sm, paddingHorizontal: 8, paddingVertical: 6 }, bulkDeleteText: { color: HC.white, fontSize: 11, fontWeight: '800' }, card: { marginBottom: UI.spacing.sm }, cardTop: { flexDirection: 'row', alignItems: 'center', gap: UI.spacing.sm }, checkbox: { width: 25, alignItems: 'center' }, icon: { width: 40, height: 40, borderRadius: UI.radius.sm, backgroundColor: '#EEF3FF', alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1 }, name: { color: HC.text, fontSize: 13, fontWeight: '800' }, meta: { color: HC.muted, fontSize: 11, marginTop: 4 }, status: { color: HC.blue, fontSize: 11, fontWeight: '800' }, statusBad: { color: HC.danger }, delete: { padding: 4 }, openDraft: { padding: 4 }, retry: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, borderTopWidth: 1, borderTopColor: HC.line, marginTop: UI.spacing.md, paddingTop: UI.spacing.sm }, retryText: { color: HC.blue, fontSize: 12, fontWeight: '800' },
});
