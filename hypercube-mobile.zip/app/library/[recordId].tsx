import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { Panel, PrimaryButton, StatusPill } from '@/components/hypercube-ui';
import { ScreenState } from '@/components/ui/screen-state';
import { HC } from '@/constants/hypercube';
import { UI } from '@/constants/ui';
import { exportAnalysisRecord } from '@/lib/analysis-export';
import { readAnalysisHistory } from '@/lib/analysis-storage';
import { analysisSourceLabel, analysisStateLabel, verdictPresentation } from '@/shared/analysis-result';
import type { AnalysisRecord } from '@/shared/ai-history';

export default function LibraryAnalysisDetailScreen() {
  const router = useRouter();
  const { recordId } = useLocalSearchParams<{ recordId?: string }>();
  const [record, setRecord] = useState<AnalysisRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);

  useFocusEffect(useCallback(() => {
    let active = true;
    setLoading(true);
    void readAnalysisHistory().then((records) => {
      if (active) setRecord(records.find((item) => item.id === recordId) ?? null);
    }).finally(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, [recordId]));

  if (loading) return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5"><ScreenState kind="loading" title="Opening saved review" description="Restoring the original AI analysis." /></ScreenContainer>;
  if (!record) return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5"><ScreenState kind="error" title="Review not found" description="This saved analysis may have been cleared from the device." actionLabel="Back to library" onAction={() => router.back()} /></ScreenContainer>;

  const presentation = verdictPresentation(record.analysis.verdict);
  const handleExport = async () => {
    setExporting(true);
    setExportError(null);
    try {
      await exportAnalysisRecord(record);
    } catch (error) {
      setExportError(error instanceof Error ? error.message : 'Export failed. Try again.');
    } finally {
      setExporting(false);
    }
  };

  return <ScreenContainer containerClassName="bg-[#F6F8FB]" className="px-5 pt-3"><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}><Text style={styles.eyebrow}>SAVED REVIEW</Text><Text style={styles.title}>{record.code ?? 'Product scan'}</Text><Text style={styles.meta}>{record.focus} · {analysisSourceLabel(record.analysis)}</Text><Panel style={styles.verdict}><View style={styles.verdictTop}><Text style={styles.sectionLabel}>AI ASSESSMENT</Text><StatusPill label={presentation.label} tone={presentation.tone} /></View><Text style={styles.confidence}>{record.analysis.confidence}%</Text><Text style={styles.confidenceLabel}>confidence</Text><Text style={styles.summary}>{record.analysis.summary}</Text></Panel><Panel style={styles.panel}><Text style={styles.sectionLabel}>REVIEW STATE</Text><Text style={styles.state}>{analysisStateLabel({ isProvisional: false, fallback: record.analysis.fallback })}</Text><Text style={styles.detail}>Evidence quality: {record.analysis.evidenceQuality}</Text><Text style={styles.detail}>Saved: {new Date(record.createdAt).toLocaleString()}</Text></Panel>{record.analysis.limitations.length ? <Panel style={styles.panel}><Text style={styles.sectionLabel}>LIMITATIONS</Text>{record.analysis.limitations.map((item) => <Text key={item} style={styles.detail}>• {item}</Text>)}</Panel> : null}{exportError ? <Text accessibilityRole="alert" style={styles.error}>{exportError}</Text> : null}<PrimaryButton label={exporting ? 'Preparing export…' : 'Export saved review'} icon="share-outline" onPress={() => void handleExport()} disabled={exporting} accessibilityLabel="Export saved AI review" /><PrimaryButton label="Back to library" onPress={() => router.back()} /></ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({ content: { paddingBottom: UI.spacing.xxl }, eyebrow: { color: HC.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.1 }, title: { color: HC.text, fontSize: 28, fontWeight: '800', marginTop: 5 }, meta: { color: HC.muted, fontSize: 12, marginTop: 5 }, verdict: { marginTop: UI.spacing.xl, alignItems: 'center' }, verdictTop: { width: '100%', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, sectionLabel: { color: HC.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.1 }, confidence: { color: HC.text, fontSize: 48, fontWeight: '800', marginTop: UI.spacing.lg }, confidenceLabel: { color: HC.muted, fontSize: 12 }, summary: { color: HC.text, fontSize: 15, lineHeight: 21, textAlign: 'center', marginTop: UI.spacing.lg }, panel: { marginTop: UI.spacing.md }, state: { color: HC.text, fontSize: 16, fontWeight: '800', marginTop: UI.spacing.sm }, detail: { color: HC.muted, fontSize: 12, lineHeight: 18, marginTop: UI.spacing.sm }, error: { color: HC.danger, fontSize: 12, lineHeight: 18, marginVertical: UI.spacing.md }, });
