import { describe, expect, it } from 'vitest';
import { createScanResultRoute, createWebFallbackRoute } from '../shared/scan-routing';

describe('scan-to-result smoke routes', () => {
  it('routes a native barcode scan with code and focus', () => {
    expect(createScanResultRoute({ code: 'HYP-QR-1048', focus: 'serial' })).toEqual({
      pathname: '/scan/result',
      params: { code: 'HYP-QR-1048', focus: 'serial' },
    });
  });

  it('routes a native photo capture with photo URI and focus', () => {
    expect(createScanResultRoute({ photoUri: 'file:///evidence/product.jpg', focus: 'packaging' })).toEqual({
      pathname: '/scan/result',
      params: { photoUri: 'file:///evidence/product.jpg', focus: 'packaging' },
    });
  });

  it('serializes a bounded multi-photo evidence set for review handoff', () => {
    expect(createScanResultRoute({ photoUris: ['file:///one.jpg', 'file:///two.jpg'], focus: 'overall' })).toEqual({
      pathname: '/scan/result',
      params: { photoUris: JSON.stringify(['file:///one.jpg', 'file:///two.jpg']), focus: 'overall' },
    });
  });

  it('keeps the web fallback actionable without camera data', () => {
    expect(createWebFallbackRoute('overall')).toEqual({
      pathname: '/scan/result',
      params: { focus: 'overall' },
    });
  });
});
