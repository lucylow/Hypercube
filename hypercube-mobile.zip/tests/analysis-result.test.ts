import { describe, expect, it } from 'vitest';
import { analysisSourceLabel, analysisStateLabel, qualityTone, signalTone, verdictPresentation } from '../shared/analysis-result';

describe('AI result presentation helpers', () => {
  it('maps verdicts and signal statuses to stable UI tones', () => {
    expect(verdictPresentation('low_risk')).toEqual({ label: 'Low risk', tone: 'success' });
    expect(verdictPresentation('high_risk')).toEqual({ label: 'High risk', tone: 'danger' });
    expect(verdictPresentation('needs_review')).toEqual({ label: 'Needs review', tone: 'warning' });
    expect(signalTone('positive')).toBe('success');
    expect(signalTone('critical')).toBe('danger');
    expect(signalTone('neutral')).toBe('neutral');
    expect(qualityTone('strong')).toBe('success');
    expect(qualityTone('moderate')).toBe('warning');
    expect(qualityTone('weak')).toBe('danger');
  });

  it('maps source and state labels without exposing implementation details', () => {
    expect(analysisSourceLabel({ usedVision: true })).toBe('Product photo');
    expect(analysisSourceLabel({ usedVision: false })).toBe('Scan context');
    expect(analysisStateLabel({ fallback: false, isProvisional: true })).toBe('Working');
    expect(analysisStateLabel({ fallback: true, isProvisional: false })).toBe('Fallback');
    expect(analysisStateLabel({ fallback: false, isProvisional: false })).toBe('Reviewed');
  });
});
