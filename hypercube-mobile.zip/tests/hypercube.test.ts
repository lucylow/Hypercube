import { describe, expect, it } from 'vitest';
import { demoCases, recentScans } from '../constants/hypercube';

describe('Hypercube mobile demo domain', () => {
  it('contains a trustworthy low-risk scan example', () => {
    const scan = recentScans.find((item) => item.product === 'Air Max 90');
    expect(scan).toMatchObject({ result: 'Low risk', score: '84%' });
  });

  it('keeps cases in the expected operational states', () => {
    expect(demoCases.map((item) => item.status)).toEqual(['Open', 'Needs review', 'Resolved']);
  });

  it('uses immutable-looking case identifiers for demo navigation', () => {
    expect(demoCases.every((item) => /^HYP-\d+$/.test(item.id))).toBe(true);
  });
});
