import { describe, expect, it } from 'vitest';
import { filterAnalysisHistory, removeAnalysisRecord, removeAnalysisRecords, sortAnalysisHistory, toggleVisibleSelection } from '../shared/library';
import type { AnalysisRecord } from '../shared/ai-history';

const record = (id: string, verdict: 'low_risk' | 'needs_review' | 'high_risk', summary: string, createdAt = '2026-08-15T12:00:00.000Z', confidence = 70): AnalysisRecord => ({
  id,
  code: id,
  focus: 'overall',
  createdAt,
  analysis: {
    verdict,
    confidence,
    summary,
    recommendedAction: 'Review evidence',
    nextBestAction: { title: 'Capture more', rationale: 'Need more context', evidenceType: 'photo' },
    signals: [],
    photoQuality: { grade: 'strong', issues: [], usableForAnalysis: true },
    limitations: [],
    observedDetails: [],
    missingEvidence: [],
    evidenceQuality: 'strong',
    model: 'test',
    usedVision: true,
    fallback: false,
    focus: 'overall',
  },
});

describe('analysis library filtering and management', () => {
  const records = [
    record('HYP-1', 'high_risk', 'Seller mismatch', '2026-08-15T12:00:00.000Z', 70),
    record('HYP-2', 'low_risk', 'Packaging aligned', '2026-08-14T12:00:00.000Z', 92),
    record('HYP-3', 'needs_review', 'Logo needs closer capture', '2026-08-16T12:00:00.000Z', 55),
  ];

  it('filters by verdict and case-insensitive query', () => {
    expect(filterAnalysisHistory(records, '', 'high_risk').map((item) => item.id)).toEqual(['HYP-1']);
    expect(filterAnalysisHistory(records, 'packaging', 'All').map((item) => item.id)).toEqual(['HYP-2']);
  });

  it('returns no records for unmatched queries', () => {
    expect(filterAnalysisHistory(records, 'missing', 'All')).toHaveLength(0);
  });

  it('sorts recent reviews first without mutating the source array', () => {
    const sorted = sortAnalysisHistory(records, 'recent');
    expect(sorted.map((item) => item.id)).toEqual(['HYP-3', 'HYP-1', 'HYP-2']);
    expect(records.map((item) => item.id)).toEqual(['HYP-1', 'HYP-2', 'HYP-3']);
  });

  it('sorts by confidence and then by risk severity', () => {
    expect(sortAnalysisHistory(records, 'confidence').map((item) => item.id)).toEqual(['HYP-2', 'HYP-1', 'HYP-3']);
    expect(sortAnalysisHistory(records, 'risk').map((item) => item.id)).toEqual(['HYP-1', 'HYP-3', 'HYP-2']);
  });

  it('removes only the requested record and leaves the source unchanged', () => {
    expect(removeAnalysisRecord(records, 'HYP-2').map((item) => item.id)).toEqual(['HYP-1', 'HYP-3']);
    expect(records).toHaveLength(3);
  });

  it('removes a selected set without changing unrelated records', () => {
    expect(removeAnalysisRecords(records, ['HYP-1', 'missing']).map((item) => item.id)).toEqual(['HYP-2', 'HYP-3']);
    expect(records).toHaveLength(3);
  });

  it('toggles only the visible selection set and preserves hidden selections', () => {
    expect(toggleVisibleSelection(['hidden'], ['HYP-1', 'HYP-2'])).toEqual(['hidden', 'HYP-1', 'HYP-2']);
    expect(toggleVisibleSelection(['hidden', 'HYP-1', 'HYP-2'], ['HYP-1', 'HYP-2'])).toEqual(['hidden']);
    expect(toggleVisibleSelection(['hidden'], [])).toEqual(['hidden']);
  });
});
