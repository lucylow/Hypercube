import { describe, expect, it } from 'vitest';
import { formatEvidenceDraftSetCsv, formatEvidenceDraftSetExport } from '../shared/evidence-export';
import type { EvidenceDraft } from '../lib/evidence-model';

const draft: EvidenceDraft = {
  caseId: 'CASE-7',
  evidenceType: 'Product detail',
  note: 'Seal, label, and "serial" checked',
  photos: [{ id: 'photo-1', uri: 'file://photo.jpg', createdAt: '2026-08-15T20:00:00.000Z' }],
  syncState: 'failed',
  uploadProgress: 0,
  syncProgress: 0,
  syncAttemptCount: 2,
  lastAttemptAt: '2026-08-15T20:01:00.000Z',
  errorMessage: 'Network request timed out',
  recoveryHint: 'Reconnect and retry.',
  updatedAt: '2026-08-15T20:01:00.000Z',
};

describe('evidence draft export', () => {
  it('includes scope, count, progress, retry metadata, and notes in JSON', () => {
    const payload = JSON.parse(formatEvidenceDraftSetExport([draft], 'selected'));
    expect(payload.scope).toBe('selected');
    expect(payload.count).toBe(1);
    expect(payload.drafts[0]).toMatchObject({ caseId: 'CASE-7', syncProgress: 0, syncAttemptCount: 2, recoveryHint: 'Reconnect and retry.' });
  });

  it('escapes investigation text and preserves row ordering in CSV', () => {
    const csv = formatEvidenceDraftSetCsv([draft]);
    expect(csv).toContain('caseId');
    expect(csv).toContain('"Seal, label, and ""serial"" checked"');
    expect(csv.indexOf('CASE-7')).toBeGreaterThan(csv.indexOf('caseId'));
  });
});
