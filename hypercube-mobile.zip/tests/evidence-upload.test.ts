import { describe, expect, it } from 'vitest';
import { createEmptyEvidenceDraft, getEvidencePhotoUploadSummary, queueEvidencePhotoRetry } from '../lib/evidence-model';
import { evidencePhotoExtension, parseEvidencePhotoDataUrl } from '../shared/evidence-upload';

describe('evidence photo upload contract', () => {
  it('normalizes jpg data URLs and derives a stable extension', () => {
    const parsed = parseEvidencePhotoDataUrl('data:image/jpg;base64,aGVsbG8=');
    expect(parsed).toEqual({ mimeType: 'image/jpeg', base64: 'aGVsbG8=' });
    expect(evidencePhotoExtension(parsed.mimeType)).toBe('jpg');
  });

  it('accepts supported image formats', () => {
    expect(parseEvidencePhotoDataUrl('data:image/png;base64,aGVsbG8=').mimeType).toBe('image/png');
    expect(parseEvidencePhotoDataUrl('data:image/webp;base64,aGVsbG8=').mimeType).toBe('image/webp');
  });

  it('queues one failed photo for retry without changing uploaded photos', () => {
    const draft = createEmptyEvidenceDraft('CASE-RETRY');
    draft.photos = [
      { id: 'uploaded', uri: 'file://uploaded.jpg', createdAt: '2026-01-01T00:00:00.000Z', remoteUrl: '/manus-storage/uploaded', uploadState: 'uploaded' },
      { id: 'failed', uri: 'file://failed.jpg', createdAt: '2026-01-01T00:00:00.000Z', uploadState: 'failed', uploadError: 'timeout' },
    ];
    const queued = queueEvidencePhotoRetry(draft, 'failed');
    expect(queued.syncState).toBe('queued');
    expect(queued.photos[0].remoteUrl).toBe('/manus-storage/uploaded');
    expect(queued.photos[1].uploadState).toBe('pending');
    expect(queued.photos[1].uploadError).toBeUndefined();
  });

  it('summarizes partial upload state for investigator recovery', () => {
    const draft = createEmptyEvidenceDraft('CASE-UPLOAD');
    draft.photos = [
      { id: 'one', uri: 'file://one.jpg', createdAt: '2026-01-01T00:00:00.000Z', remoteUrl: '/manus-storage/one', uploadState: 'uploaded' },
      { id: 'two', uri: 'file://two.jpg', createdAt: '2026-01-01T00:00:00.000Z', uploadState: 'failed', uploadError: 'timeout' },
      { id: 'three', uri: 'file://three.jpg', createdAt: '2026-01-01T00:00:00.000Z', uploadState: 'pending' },
    ];
    expect(getEvidencePhotoUploadSummary(draft)).toEqual({ total: 3, uploaded: 1, pending: 1, failed: 1 });
  });

  it('rejects non-image and malformed payloads', () => {
    expect(() => parseEvidencePhotoDataUrl('data:text/plain;base64,aGVsbG8=')).toThrow('base64 image data URL');
    expect(() => parseEvidencePhotoDataUrl('not-a-data-url')).toThrow('base64 image data URL');
  });
});
