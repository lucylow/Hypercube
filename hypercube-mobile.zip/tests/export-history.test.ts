import { describe, expect, it } from 'vitest';
import { isEvidenceAuditExport, prependExportHistory, removeExportHistoryEntries, removeExportHistoryEntry, type ExportHistoryEntry } from '../lib/export-history';

const entry = (id: string): ExportHistoryEntry => ({
  id,
  createdAt: '2026-08-15T12:00:00.000Z',
  scope: 'filtered',
  format: 'json',
  count: 2,
  status: 'downloaded',
});

describe('export history', () => {
  it('retains an audit export case ID for direct source navigation', () => {
    const audit = { ...entry('audit-123'), caseId: 'CASE-123' };
    expect(audit.caseId).toBe('CASE-123');
    expect(isEvidenceAuditExport(audit)).toBe(true);
  });

  it('classifies persisted audit exports without confusing review exports', () => {
    expect(isEvidenceAuditExport(entry('audit-123'))).toBe(true);
    expect(isEvidenceAuditExport(entry('review-123'))).toBe(false);
  });

  it('prepends new entries and removes duplicate IDs', () => {
    expect(prependExportHistory([entry('old'), entry('same')], entry('same')).map((item) => item.id)).toEqual(['same', 'old']);
  });

  it('keeps the history bounded', () => {
    expect(prependExportHistory([entry('a'), entry('b')], entry('c'), 2).map((item) => item.id)).toEqual(['c', 'a']);
  });

  it('removes one entry without mutating the source history', () => {
    const history = [entry('a'), entry('b')];
    expect(removeExportHistoryEntry(history, 'a').map((item) => item.id)).toEqual(['b']);
    expect(history.map((item) => item.id)).toEqual(['a', 'b']);
  });

  it('removes a selected set and ignores missing IDs', () => {
    expect(removeExportHistoryEntries([entry('a'), entry('b'), entry('c')], ['a', 'missing', 'c']).map((item) => item.id)).toEqual(['b']);
  });
});
