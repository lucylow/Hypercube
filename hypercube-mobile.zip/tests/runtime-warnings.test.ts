import { describe, expect, it } from 'vitest';
import { isKnownExpoDependencyWarning } from '../lib/runtime-warnings';

describe('Expo runtime warning classification', () => {
  it('recognizes the known React Native Web deprecations', () => {
    expect(isKnownExpoDependencyWarning('props.pointerEvents is deprecated. Use style.pointerEvents')).toBe(true);
    expect(isKnownExpoDependencyWarning('"shadow*" style props are deprecated. Use "boxShadow"')).toBe(true);
  });

  it('does not hide unrelated runtime errors', () => {
    expect(isKnownExpoDependencyWarning('TypeError: Cannot read properties of undefined')).toBe(false);
    expect(isKnownExpoDependencyWarning('Network request failed')).toBe(false);
  });
});
