import { describe, expect, it } from 'vitest';
import { appendAnalysisRecord, createAnalysisRecord } from '../shared/ai-history';
import { fallbackAuthenticityAnalysis } from '../shared/ai';

describe('Hypercube AI analysis history', () => {
  it('creates a stable record with focus and timestamp', () => {
    const analysis = fallbackAuthenticityAnalysis({ model: 'test-model', usedVision: false, focus: 'serial' });
    const record = createAnalysisRecord({ code: 'HYP-123', focus: 'serial', analysis, now: '2026-08-15T17:45:00.000Z' });
    expect(record.id).toBe('HYP-123-2026-08-15T17:45:00.000Z');
    expect(record.focus).toBe('serial');
  });

  it('prepends new records and removes duplicate ids', () => {
    const analysis = fallbackAuthenticityAnalysis({ model: 'test-model', usedVision: false });
    const first = createAnalysisRecord({ code: 'HYP-123', focus: 'overall', analysis, now: '2026-08-15T17:45:00.000Z' });
    const replacement = createAnalysisRecord({ code: 'HYP-123', focus: 'overall', analysis, now: '2026-08-15T17:45:00.000Z' });
    const history = appendAnalysisRecord([first], replacement);
    expect(history).toHaveLength(1);
    expect(history[0]).toBe(replacement);
  });
});
