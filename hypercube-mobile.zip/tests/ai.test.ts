import { describe, expect, it } from 'vitest';
import { fallbackAuthenticityAnalysis, normalizeAuthenticityAnalysis } from '../shared/ai';

describe('Hypercube AI analysis normalization', () => {
  it('clamps confidence and preserves structured signals', () => {
    const result = normalizeAuthenticityAnalysis({
      verdict: 'high_risk',
      confidence: 122,
      evidenceQuality: 'strong',
      photoQuality: { grade: 'strong', issues: [], usableForAnalysis: true },
      summary: 'Packaging diverges from reference samples.',
      signals: [{ title: 'Logo mismatch', status: 'critical', explanation: 'The mark is misaligned.' }],
      recommendedAction: 'Open a case.',
      limitations: ['Only one image was available.'],
    }, { model: 'test-model', usedVision: true });
    expect(result.verdict).toBe('high_risk');
    expect(result.confidence).toBe(100);
    expect(result.signals[0].status).toBe('critical');
    expect(result.usedVision).toBe(true);
  });

  it('returns cautious defaults for malformed model output', () => {
    const result = normalizeAuthenticityAnalysis({}, { model: 'test-model', usedVision: false });
    expect(result.verdict).toBe('needs_review');
    expect(result.confidence).toBe(50);
    expect(result.signals.length).toBeGreaterThan(0);
  });

  it('caps confidence when evidence quality is weak', () => {
    const result = normalizeAuthenticityAnalysis({ verdict: 'low_risk', confidence: 96, evidenceQuality: 'weak', observedDetails: ['Only a partial label is visible.'], missingEvidence: ['Full package photo'] }, { model: 'test-model', usedVision: true, focus: 'packaging' });
    expect(result.confidence).toBe(70);
    expect(result.focus).toBe('packaging');
    expect(result.missingEvidence).toContain('Full package photo');
  });

  it('softens unsupported risk bands and adds focus-specific evidence requests', () => {
    const result = normalizeAuthenticityAnalysis({
      verdict: 'high_risk',
      confidence: 92,
      evidenceQuality: 'moderate',
      signals: [{ title: 'Packaging concern', status: 'warning', explanation: 'A comparison is needed.' }],
      missingEvidence: [],
    }, { model: 'test-model', usedVision: true, focus: 'serial' });
    expect(result.verdict).toBe('needs_review');
    expect(result.limitations.some((item) => item.includes('softened'))).toBe(true);
    expect(result.missingEvidence).toContain('Readable serial, QR, or NFC detail');
  });

  it('does not allow non-vision input to produce a final risk verdict', () => {
    const result = normalizeAuthenticityAnalysis({ verdict: 'low_risk', confidence: 88, evidenceQuality: 'strong', signals: [{ title: 'Looks consistent', status: 'positive', explanation: 'Text only.' }] }, { model: 'test-model', usedVision: false });
    expect(result.verdict).toBe('needs_review');
    expect(result.confidence).toBeLessThanOrEqual(70);
  });

  it('normalizes a model next-best action and preserves its evidence type', () => {
    const result = normalizeAuthenticityAnalysis({
      verdict: 'needs_review',
      nextBestAction: { title: 'Capture the hologram', rationale: 'The hologram edge is not visible.', evidenceType: 'Hologram close-up' },
    }, { model: 'test-model', usedVision: true, focus: 'packaging' });
    expect(result.nextBestAction.title).toBe('Capture the hologram');
    expect(result.nextBestAction.evidenceType).toBe('Hologram close-up');
  });

  it('provides safe focus-specific next evidence when the model omits the action', () => {
    const result = fallbackAuthenticityAnalysis({ model: 'test-model', usedVision: false, focus: 'provenance' });
    expect(result.nextBestAction.title).toContain('purchase');
    expect(result.nextBestAction.evidenceType).toContain('record');
  });

  it('caps confidence and exposes concrete photo-quality issues', () => {
    const result = normalizeAuthenticityAnalysis({
      verdict: 'high_risk',
      confidence: 96,
      evidenceQuality: 'strong',
      signals: [{ title: 'Blurred label', status: 'critical', explanation: 'The label is not readable.' }],
      photoQuality: { grade: 'weak', issues: ['Motion blur', 'Glare across identifier'], usableForAnalysis: false },
    }, { model: 'test-model', usedVision: true, focus: 'serial' });
    expect(result.confidence).toBe(55);
    expect(result.photoQuality.issues).toContain('Motion blur');
    expect(result.photoQuality.usableForAnalysis).toBe(false);
  });

  it('normalizes structured visual checks and defaults invalid values safely', () => {
    const result = normalizeAuthenticityAnalysis({
      photoQuality: { grade: 'moderate', usableForAnalysis: true, visualChecks: { sharpness: 'strong', lighting: 'weak', framing: 'moderate', identifierReadability: 'invalid' } },
    }, { model: 'test-model', usedVision: true });
    expect(result.photoQuality.visualChecks).toEqual({ sharpness: 'strong', lighting: 'weak', framing: 'moderate', identifierReadability: 'weak' });
  });

  it('normalizes cross-photo consistency only for multi-image evidence sets', () => {
    const result = normalizeAuthenticityAnalysis({ crossPhotoConsistency: { status: 'mixed', issues: ['Logo spacing differs across views.'] } }, { model: 'test-model', usedVision: true, imageCount: 2 });
    expect(result.crossPhotoConsistency).toEqual({ status: 'mixed', issues: ['Logo spacing differs across views.'] });
    const single = normalizeAuthenticityAnalysis({ crossPhotoConsistency: { status: 'mixed', issues: ['Should be ignored for one image.'] } }, { model: 'test-model', usedVision: true, imageCount: 1 });
    expect(single.crossPhotoConsistency).toBeUndefined();
    const malformed = normalizeAuthenticityAnalysis({}, { model: 'test-model', usedVision: true, imageCount: 3 });
    expect(malformed.crossPhotoConsistency?.status).toBe('insufficient');
  });

  it('normalizes persisted evidence review metadata for the analysis record', () => {
    const result = normalizeAuthenticityAnalysis({}, { model: 'test-model', usedVision: true, imageCount: 2, reviewMetadata: { imageCount: 2, reviewedIndexes: [0, 1], reviewStartedAt: '2026-08-15T12:00:00.000Z', reviewCompletedAt: '2026-08-15T12:01:00.000Z', actions: ['review:0', 'reorder:1:0'] } });
    expect(result.reviewMetadata?.reviewedIndexes).toEqual([0, 1]);
    expect(result.reviewMetadata?.actions).toContain('reorder:1:0');
  });

  it('normalizes reference comparison only when reference images are supplied', () => {
    const result = normalizeAuthenticityAnalysis({ referenceComparison: { status: 'mismatch', issues: ['Logo geometry differs from the reference aid.'] } }, { model: 'test-model', usedVision: true, imageCount: 2, referenceImageCount: 1, provenanceHash: 'abc123' });
    expect(result.referenceComparison?.status).toBe('mismatch');
    expect(result.provenanceHash).toBe('abc123');
    const withoutReference = normalizeAuthenticityAnalysis({ referenceComparison: { status: 'mismatch', issues: ['Ignore'] } }, { model: 'test-model', usedVision: true, imageCount: 2 });
    expect(withoutReference.referenceComparison).toBeUndefined();
  });

  it('marks service failures as fallback states', () => {
    const result = fallbackAuthenticityAnalysis({ model: 'test-model', usedVision: true, reason: 'Timeout' });
    expect(result.fallback).toBe(true);
    expect(result.verdict).toBe('needs_review');
    expect(result.limitations[0]).toContain('fallback');
  });
});
