import { describe, expect, it } from 'vitest';
import { appendEvidenceSyncEvent, buildEvidenceAuditCsv, createEmptyEvidenceDraft, filterEvidenceSyncEvents, sortEvidenceSyncEvents, type EvidenceDraft } from '../lib/evidence-model';

describe('evidence sync history', () => {
  it('supports auditable photo preview events in newest-first history', () => {
    const draft = createEmptyEvidenceDraft('CASE-PREVIEW');
    const audited = appendEvidenceSyncEvent(draft, { id: 'preview-1', occurredAt: '2026-08-15T12:00:00.000Z', status: 'previewed', message: 'Investigator previewed the stored evidence photo.' });
    expect(sortEvidenceSyncEvents(audited.syncHistory ?? [])[0].status).toBe('previewed');
  });

  it('filters photo activity without mutating the audit history', () => {
    const events = [
      { id: 'preview', occurredAt: '2026-01-02T09:00:00.000Z', status: 'previewed' as const, message: 'Previewed' },
      { id: 'sync', occurredAt: '2026-01-01T09:00:00.000Z', status: 'synced' as const, message: 'Synced' },
    ];
    expect(filterEvidenceSyncEvents(events, 'photo').map((event) => event.id)).toEqual(['preview']);
    expect(filterEvidenceSyncEvents(events, 'handoff').map((event) => event.id)).toEqual(['sync']);
    expect(events).toHaveLength(2);
  });

  it('formats a CSV audit export with escaped metadata and event rows', () => {
    const draft: EvidenceDraft = { ...createEmptyEvidenceDraft('CASE-CSV'), evidenceType: 'Product detail', lastReceiptId: 'receipt-1', photos: [{ id: 'photo-1', uri: 'file://one', createdAt: '2026-01-01T00:00:00.000Z', remoteUrl: 'https://cdn/photo', remoteKey: 'evidence/photo-1', integrityHash: 'sha256-abc', uploadState: 'uploaded' }] };
    const csv = buildEvidenceAuditCsv(draft, [{ id: 'event-1', occurredAt: '2026-01-02T00:00:00.000Z', status: 'synced', message: 'Uploaded, verified' }]);
    expect(csv.split('\\n')[0]).toContain('case_id');
    expect(csv).toContain('"Product detail"');
    expect(csv).toContain('"Uploaded, verified"');
    expect(csv).toContain('sha256-abc');
    expect(csv).toContain('evidence/photo-1');
  });

  it('appends events without mutating the draft and retains the latest ten events', () => {
    const draft = createEmptyEvidenceDraft('CASE-42');
    let current = draft;
    for (let index = 0; index < 12; index += 1) {
      current = appendEvidenceSyncEvent(current, {
        id: `event-${index}`,
        occurredAt: new Date(2026, 0, index + 1).toISOString(),
        status: 'failed',
        message: `Attempt ${index}`,
      });
    }
    expect(draft.syncHistory).toEqual([]);
    expect(current.syncHistory).toHaveLength(10);
    expect(current.syncHistory?.[0].id).toBe('event-2');
    expect(current.syncHistory?.[9].id).toBe('event-11');
  });

  it('sorts audit events newest first without mutating the source array', () => {
    const events = [
      { id: 'older', occurredAt: '2026-01-01T09:00:00.000Z', status: 'queued' as const, message: 'Queued' },
      { id: 'newer', occurredAt: '2026-01-03T09:00:00.000Z', status: 'synced' as const, message: 'Synced' },
      { id: 'middle', occurredAt: '2026-01-02T09:00:00.000Z', status: 'failed' as const, message: 'Failed' },
    ];
    const ordered = sortEvidenceSyncEvents(events);
    expect(ordered.map((event) => event.id)).toEqual(['newer', 'middle', 'older']);
    expect(events.map((event) => event.id)).toEqual(['older', 'newer', 'middle']);
  });

  it('includes persisted review metadata in audit exports', () => {
    const draft: EvidenceDraft = { ...createEmptyEvidenceDraft('CASE-REVIEW'), reviewedPhotoIds: ['photo-1'], reviewStartedAt: '2026-01-01T10:00:00.000Z', reviewCompletedAt: '2026-01-01T10:02:00.000Z', photos: [{ id: 'photo-1', uri: 'file://one', createdAt: '2026-01-01T00:00:00.000Z' }] };
    const csv = buildEvidenceAuditCsv(draft, [{ id: 'review-1', occurredAt: '2026-01-01T10:02:00.000Z', status: 'reviewed', message: 'Reviewed photo 1' }]);
    expect(csv).toContain('reviewed_photo_ids');
    expect(csv).toContain('photo-1');
    expect(csv).toContain('review-1');
  });

  it('preserves server receipt identifiers on the draft model', () => {
    const draft = createEmptyEvidenceDraft('CASE-43');
    const withReceipt = { ...draft, lastReceiptId: 'evidence-user-123' };
    expect(withReceipt.lastReceiptId).toBe('evidence-user-123');
  });
});
