import { describe, expect, it } from 'vitest';
import { formatCaseSummaryExport, type CaseSummary } from '../shared/case-export';

const sample: CaseSummary = {
  id: 'HYP-1048',
  product: 'Air Max 90',
  risk: 'High risk',
  location: 'Tokyo',
  summary: 'Multiple signals need review.',
  rationale: 'Logo differs from reference.',
  assignee: 'Maya Chen',
  status: 'OPEN',
  events: [{ title: 'Scan completed', body: 'QR capture analyzed', time: 'Today' }],
};

describe('case export', () => {
  it('creates a structured, parseable handoff payload', () => {
    const payload = JSON.parse(formatCaseSummaryExport(sample));
    expect(payload.source).toBe('hypercube-mobile');
    expect(payload.case).toEqual(sample);
    expect(payload.exportedAt).toMatch(/T/);
  });
});
