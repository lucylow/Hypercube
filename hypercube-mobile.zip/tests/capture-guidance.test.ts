import { describe, expect, it } from 'vitest';
import { getCaptureGuide } from '../shared/capture-guidance';

describe('focus-aware capture guidance', () => {
  it('provides serial-specific steps for identifier analysis', () => {
    const guide = getCaptureGuide('serial');
    expect(guide.title).toContain('identifier');
    expect(guide.steps).toContain('Keep the full code in frame');
  });

  it('provides provenance-specific steps for purchase evidence', () => {
    const guide = getCaptureGuide('provenance');
    expect(guide.steps).toContain('Receipt or order record');
    expect(guide.tip).toContain('records');
  });
});
