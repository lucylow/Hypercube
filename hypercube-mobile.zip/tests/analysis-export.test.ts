import { describe, expect, it } from 'vitest';
import { formatAnalysisExport, formatAnalysisSetCsv, formatAnalysisSetExport } from '../shared/analysis-export';
import { createAnalysisRecord } from '../shared/ai-history';
import { fallbackAuthenticityAnalysis } from '../shared/ai';

describe('AI analysis export', () => {
  it('produces portable JSON with the Hypercube export envelope', () => {
    const record = createAnalysisRecord({
      code: 'HYP-QR-1048',
      focus: 'serial',
      analysis: fallbackAuthenticityAnalysis({ model: 'test-model', usedVision: false, focus: 'serial', reason: 'test' }),
    });
    const parsed = JSON.parse(formatAnalysisExport(record));
    expect(parsed.exportedBy).toBe('Hypercube Mobile');
    expect(parsed.record.code).toBe('HYP-QR-1048');
    expect(parsed.record.focus).toBe('serial');
    expect(parsed.record.analysis.verdict).toBe('needs_review');
  });

  it('formats a review set as CSV with escaped investigation text', () => {
    const record = createAnalysisRecord({ code: 'HYP-CSV', focus: 'serial', analysis: { ...fallbackAuthenticityAnalysis({ model: 'test-model', usedVision: true, focus: 'serial', reason: 'test' }), summary: 'Mismatch, "high risk"' } });
    const csv = formatAnalysisSetCsv([record]);
    expect(csv.split('\\n')).toHaveLength(2);
    expect(csv).toContain('id,code,focus,createdAt,verdict,confidence,summary,recommendedAction,source');
    expect(csv).toContain('"Mismatch, ""high risk"""');
  });

  it('formats a review set with scope and count metadata', () => {
    const first = createAnalysisRecord({ code: 'HYP-1', focus: 'serial', analysis: fallbackAuthenticityAnalysis({ model: 'test-model', usedVision: false, focus: 'serial', reason: 'test' }), now: '2026-08-15T12:00:00.000Z' });
    const second = createAnalysisRecord({ code: 'HYP-2', focus: 'logo', analysis: fallbackAuthenticityAnalysis({ model: 'test-model', usedVision: false, focus: 'logo', reason: 'test' }), now: '2026-08-15T13:00:00.000Z' });
    const parsed = JSON.parse(formatAnalysisSetExport([first, second], 'selected'));
    expect(parsed.scope).toBe('selected');
    expect(parsed.count).toBe(2);
    expect(parsed.records.map((record: { id: string }) => record.id)).toEqual([first.id, second.id]);
  });
});
