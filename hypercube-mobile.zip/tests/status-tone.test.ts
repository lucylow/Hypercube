import { describe, expect, it } from 'vitest';
import { evidenceSyncTone, riskLabel, riskTone, syncLabel } from '../shared/status-tone';

describe('shared status tone helpers', () => {
  it('maps case risk labels consistently', () => {
    expect(riskTone('High risk')).toBe('danger');
    expect(riskTone('Review')).toBe('warning');
    expect(riskTone('Needs review')).toBe('warning');
    expect(riskTone('Low risk')).toBe('success');
    expect(riskTone('Unknown')).toBe('neutral');
    expect(riskLabel('High risk')).toBe('High risk — inspect');
    expect(riskLabel('Unknown')).toBe('Needs review');
  });

  it('maps evidence sync states conservatively', () => {
    expect(evidenceSyncTone('queued')).toBe('success');
    expect(evidenceSyncTone('synced')).toBe('success');
    expect(evidenceSyncTone('failed')).toBe('danger');
    expect(evidenceSyncTone('draft')).toBe('neutral');
    expect(evidenceSyncTone('uploading')).toBe('neutral');
    expect(syncLabel('queued')).toBe('Ready to sync');
    expect(syncLabel('synced')).toBe('Synced');
    expect(syncLabel('failed')).toBe('Upload failed');
    expect(syncLabel('draft')).toBe('Local draft');
  });
});
