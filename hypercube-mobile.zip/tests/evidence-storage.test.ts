import { describe, expect, it } from 'vitest';
import { createEmptyEvidenceDraft, isEvidenceReadyForUpload, reorderEvidencePhotos, sortEvidenceDrafts } from '../lib/evidence-model';
import type { EvidencePhoto } from '../lib/evidence-model';

const photos: EvidencePhoto[] = [
  { id: 'one', uri: 'file://one.jpg', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'two', uri: 'file://two.jpg', createdAt: '2026-01-01T00:00:01.000Z' },
  { id: 'three', uri: 'file://three.jpg', createdAt: '2026-01-01T00:00:02.000Z' },
];

describe('evidence storage helpers', () => {
  it('creates a draft with safe local defaults', () => {
    const draft = createEmptyEvidenceDraft('HYP-1048');
    expect(draft.caseId).toBe('HYP-1048');
    expect(draft.photos).toEqual([]);
    expect(draft.syncState).toBe('draft');
    expect(draft.uploadProgress).toBe(0);
  });

  it('requires both a note and a photo before upload', () => {
    const draft = createEmptyEvidenceDraft('HYP-1048');
    expect(isEvidenceReadyForUpload(draft)).toBe(false);
    expect(isEvidenceReadyForUpload({ ...draft, note: 'Logo mismatch', photos })).toBe(true);
  });

  it('orders drafts newest first without mutating the original list', () => {
    const drafts = [
      { ...createEmptyEvidenceDraft('OLD'), updatedAt: '2026-08-01T10:00:00.000Z' },
      { ...createEmptyEvidenceDraft('NEW'), updatedAt: '2026-08-02T10:00:00.000Z' },
    ];
    const sorted = sortEvidenceDrafts(drafts);
    expect(sorted.map((draft) => draft.caseId)).toEqual(['NEW', 'OLD']);
    expect(drafts.map((draft) => draft.caseId)).toEqual(['OLD', 'NEW']);
  });

  it('reorders photos without mutating the original list', () => {
    const reordered = reorderEvidencePhotos(photos, 0, 2);
    expect(reordered.map((photo) => photo.id)).toEqual(['two', 'three', 'one']);
    expect(photos.map((photo) => photo.id)).toEqual(['one', 'two', 'three']);
    expect(reorderEvidencePhotos(photos, -1, 2)).toBe(photos);
  });
});
