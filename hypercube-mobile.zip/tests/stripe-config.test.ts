import { describe, expect, it, afterEach } from 'vitest';
import { BILLING_PLANS, canClaimEvidenceUsage, createCustomerPortalSession, getPlan, getPlanUsageLimits, isStripeConfigured } from '../server/stripe-billing';
import { paymentStatusFromInvoiceEvent, statusFromStripe } from '../server/stripe-webhook';

describe('Stripe configuration boundaries', () => {
  afterEach(() => {
    delete process.env.HYPERCUBE_STRIPE_SECRET_KEY;
    delete process.env.HYPERCUBE_STRIPE_WEBHOOK_SECRET;
  });

  it('exposes the basic Free, Professional, and Team prices', () => {
    expect(BILLING_PLANS.free.amountCents).toBe(0);
    expect(BILLING_PLANS.professional.amountCents).toBe(2900);
    expect(BILLING_PLANS.team.amountCents).toBe(9900);
    expect(getPlan('professional')?.name).toBe('Professional');
  });

  it('reports Stripe as unavailable until both server secrets exist', () => {
    expect(isStripeConfigured()).toBe(false);
  });
  it('returns no portal session when Stripe is unavailable', async () => {
    await expect(createCustomerPortalSession({ stripeCustomerId: 'cus_test', returnUrl: 'https://example.com/return' })).resolves.toBeNull();
  });

  it('maps Stripe invoice events to recoverable payment states', () => {
    expect(paymentStatusFromInvoiceEvent('invoice.paid')).toBe('paid');
    expect(paymentStatusFromInvoiceEvent('invoice.payment_failed')).toBe('failed');
    expect(paymentStatusFromInvoiceEvent('invoice.payment_action_required')).toBe('requires_action');
    expect(paymentStatusFromInvoiceEvent('customer.subscription.updated')).toBeNull();
  });

  it('maps Stripe subscription statuses to server entitlement states', () => {
    expect(statusFromStripe('active')).toBe('active');
    expect(statusFromStripe('past_due')).toBe('past_due');
    expect(statusFromStripe('canceled')).toBe('canceled');
    expect(statusFromStripe('incomplete')).toBe('incomplete');
    expect(statusFromStripe('paused')).toBe('paused');
  });

  it('exposes server-authoritative evidence usage limits and rejects overages', () => {
    expect(getPlanUsageLimits('free')).toEqual({ evidenceDraftLimit: 5, evidencePhotoLimit: 25 });
    expect(canClaimEvidenceUsage({ evidenceDrafts: 4, evidencePhotos: 20 }, getPlanUsageLimits('free'), 5)).toBe(true);
    expect(canClaimEvidenceUsage({ evidenceDrafts: 5, evidencePhotos: 20 }, getPlanUsageLimits('free'), 1)).toBe(false);
    expect(canClaimEvidenceUsage({ evidenceDrafts: 4, evidencePhotos: 24 }, getPlanUsageLimits('free'), 2)).toBe(false);
    expect(getPlanUsageLimits('unknown')).toEqual(getPlanUsageLimits('free'));
  });

  it('keeps Stripe credentials server-only by using non-VITE environment names', () => {
    expect('HYPERCUBE_STRIPE_SECRET_KEY'.startsWith('VITE_')).toBe(false);
    expect('HYPERCUBE_STRIPE_WEBHOOK_SECRET'.startsWith('VITE_')).toBe(false);
    expect('HYPERCUBE_STRIPE_PRICE_PROFESSIONAL'.startsWith('VITE_')).toBe(false);
  });
});

export {};
