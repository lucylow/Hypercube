import { describe, expect, it } from 'vitest';
import { classifyEvidenceSyncError, evidenceSyncErrorLabel } from '../shared/evidence-sync';

describe('evidence sync error helpers', () => {
  it('classifies actionable error categories', () => {
    expect(classifyEvidenceSyncError('Network request timed out')).toBe('network');
    expect(classifyEvidenceSyncError('Permission denied for file')).toBe('permission');
    expect(classifyEvidenceSyncError('Device storage is full')).toBe('storage');
    expect(classifyEvidenceSyncError('A required note is missing')).toBe('validation');
    expect(classifyEvidenceSyncError('Unexpected upload failure')).toBe('unknown');
    expect(classifyEvidenceSyncError()).toBeNull();
  });

  it('provides stable user-facing labels', () => {
    expect(evidenceSyncErrorLabel('network')).toBe('Network issue');
    expect(evidenceSyncErrorLabel('storage')).toBe('Device storage issue');
    expect(evidenceSyncErrorLabel(null)).toBeNull();
  });
});
