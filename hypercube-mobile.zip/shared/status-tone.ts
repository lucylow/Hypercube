export type StatusTone = 'success' | 'warning' | 'danger' | 'neutral';

export function riskLabel(risk: string): string {
  if (risk === 'High risk') return 'High risk — inspect';
  if (risk === 'Review' || risk === 'Needs review') return 'Needs review';
  if (risk === 'Low risk') return 'Low risk';
  return 'Needs review';
}

export function syncLabel(syncState: 'draft' | 'uploading' | 'queued' | 'failed' | 'synced'): string {
  if (syncState === 'queued') return 'Ready to sync';
  if (syncState === 'synced') return 'Synced';
  if (syncState === 'failed') return 'Upload failed';
  if (syncState === 'uploading') return 'Uploading';
  return 'Local draft';
}

export function riskTone(risk: string): StatusTone {
  if (risk === 'High risk') return 'danger';
  if (risk === 'Review' || risk === 'Needs review') return 'warning';
  if (risk === 'Low risk') return 'success';
  return 'neutral';
}

export function evidenceSyncTone(syncState: 'draft' | 'uploading' | 'queued' | 'failed' | 'synced'): StatusTone {
  if (syncState === 'queued' || syncState === 'synced') return 'success';
  if (syncState === 'failed') return 'danger';
  return 'neutral';
}
