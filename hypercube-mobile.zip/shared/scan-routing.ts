import type { AnalysisFocus } from './ai';

export type ScanResultRoute = {
  pathname: '/scan/result';
  params: {
    code?: string;
    photoUri?: string;
    photoUris?: string;
    reviewMetadata?: string;
    referenceUris?: string;
    focus: AnalysisFocus;
  };
};

export function createScanResultRoute(input: { focus: AnalysisFocus; code?: string; photoUri?: string; photoUris?: string[]; reviewMetadata?: object; referenceUris?: string[] }): ScanResultRoute {
  return {
    pathname: '/scan/result',
    params: {
      focus: input.focus,
      ...(input.code ? { code: input.code } : {}),
      ...(input.photoUri ? { photoUri: input.photoUri } : {}),
      ...(input.photoUris?.length ? { photoUris: JSON.stringify(input.photoUris.slice(0, 4)) } : {}),
      ...(input.reviewMetadata ? { reviewMetadata: JSON.stringify(input.reviewMetadata) } : {}),
      ...(input.referenceUris?.length ? { referenceUris: JSON.stringify(input.referenceUris.slice(0, 3)) } : {}),
    },
  };
}

export function createWebFallbackRoute(focus: AnalysisFocus = 'overall'): ScanResultRoute {
  return createScanResultRoute({ focus });
}
