import type { AnalysisRecord } from './ai-history';

export type LibraryFilter = 'All' | 'high_risk' | 'needs_review' | 'low_risk';
export type LibrarySort = 'recent' | 'confidence' | 'risk';

const RISK_ORDER: Record<LibraryFilter, number> = {
  All: 0,
  low_risk: 1,
  needs_review: 2,
  high_risk: 3,
};

export function filterAnalysisHistory(records: AnalysisRecord[], query: string, filter: LibraryFilter): AnalysisRecord[] {
  const normalizedQuery = query.trim().toLowerCase();
  return records.filter((record) => {
    const matchesQuery = !normalizedQuery || [record.code, record.focus, record.analysis.verdict, record.analysis.summary]
      .filter(Boolean)
      .some((value) => value!.toLowerCase().includes(normalizedQuery));
    const matchesFilter = filter === 'All' || record.analysis.verdict === filter;
    return matchesQuery && matchesFilter;
  });
}

export function sortAnalysisHistory(records: AnalysisRecord[], sort: LibrarySort): AnalysisRecord[] {
  return [...records].sort((left, right) => {
    if (sort === 'confidence') {
      return right.analysis.confidence - left.analysis.confidence || compareDates(right.createdAt, left.createdAt);
    }
    if (sort === 'risk') {
      return riskScore(right.analysis.verdict) - riskScore(left.analysis.verdict) || compareDates(right.createdAt, left.createdAt);
    }
    return compareDates(right.createdAt, left.createdAt);
  });
}

export function removeAnalysisRecord(records: AnalysisRecord[], recordId: string): AnalysisRecord[] {
  return records.filter((record) => record.id !== recordId);
}

export function removeAnalysisRecords(records: AnalysisRecord[], recordIds: string[]): AnalysisRecord[] {
  const ids = new Set(recordIds);
  return records.filter((record) => !ids.has(record.id));
}

export function toggleVisibleSelection(selectedIds: string[], visibleIds: string[]): string[] {
  const selected = new Set(selectedIds);
  const allVisibleSelected = visibleIds.length > 0 && visibleIds.every((id) => selected.has(id));
  visibleIds.forEach((id) => allVisibleSelected ? selected.delete(id) : selected.add(id));
  return [...selected];
}

function riskScore(verdict: string): number {
  return RISK_ORDER[verdict as LibraryFilter] ?? 0;
}

function compareDates(left: string, right: string): number {
  return new Date(left).getTime() - new Date(right).getTime();
}
