export type AuthenticityVerdict = 'low_risk' | 'needs_review' | 'high_risk';
export type AuthenticitySignalStatus = 'positive' | 'warning' | 'critical' | 'neutral';
export type EvidenceQuality = 'strong' | 'moderate' | 'weak';
export type AnalysisFocus = 'overall' | 'logo' | 'packaging' | 'serial' | 'provenance';
export type AnalysisFeedback = 'helpful' | 'needs_more_context';

export type AuthenticitySignal = {
  title: string;
  status: AuthenticitySignalStatus;
  explanation: string;
};

export type NextBestAction = {
  title: string;
  rationale: string;
  evidenceType: string;
};

export type VisualChecks = {
  sharpness: EvidenceQuality;
  lighting: EvidenceQuality;
  framing: EvidenceQuality;
  identifierReadability: EvidenceQuality;
};

export type CrossPhotoConsistency = { status: 'consistent' | 'mixed' | 'insufficient'; issues: string[] };

export type ReferenceComparison = { status: 'matched' | 'mismatch' | 'insufficient' | 'unavailable'; issues: string[] };

export type EvidenceReviewMetadata = {
  imageCount: number;
  reviewedIndexes: number[];
  reviewStartedAt: string;
  reviewCompletedAt?: string;
  actions: string[];
};

export type PhotoQuality = {
  grade: EvidenceQuality;
  issues: string[];
  usableForAnalysis: boolean;
  visualChecks?: VisualChecks;
};

export type AuthenticityAnalysis = {
  verdict: AuthenticityVerdict;
  confidence: number;
  summary: string;
  signals: AuthenticitySignal[];
  recommendedAction: string;
  nextBestAction: NextBestAction;
  photoQuality: PhotoQuality;
  limitations: string[];
  observedDetails: string[];
  missingEvidence: string[];
  evidenceQuality: EvidenceQuality;
  model: string;
  usedVision: boolean;
  fallback: boolean;
  focus: AnalysisFocus;
  crossPhotoConsistency?: CrossPhotoConsistency;
  reviewMetadata?: EvidenceReviewMetadata;
  referenceComparison?: ReferenceComparison;
  provenanceHash?: string;
};

const verdicts: AuthenticityVerdict[] = ['low_risk', 'needs_review', 'high_risk'];
const signalStatuses: AuthenticitySignalStatus[] = ['positive', 'warning', 'critical', 'neutral'];
const evidenceQualities: EvidenceQuality[] = ['strong', 'moderate', 'weak'];
const analysisFocuses: AnalysisFocus[] = ['overall', 'logo', 'packaging', 'serial', 'provenance'];

const focusEvidence: Record<AnalysisFocus, string[]> = {
  overall: ['Verified reference image', 'Product label or serial close-up'],
  logo: ['High-resolution logo close-up'],
  packaging: ['Packaging seam, typography, and label close-up'],
  serial: ['Readable serial, QR, or NFC detail'],
  provenance: ['Purchase record or verified provenance trail'],
};

function text(value: unknown, fallback: string, maxLength = 280): string {
  return typeof value === 'string' && value.trim() ? value.trim().slice(0, maxLength) : fallback;
}

function stringList(value: unknown, fallback: string[], maxItems: number, maxLength: number): string[] {
  if (!Array.isArray(value)) return fallback;
  const items = value.filter((item): item is string => typeof item === 'string' && Boolean(item.trim())).slice(0, maxItems).map((item) => item.trim().slice(0, maxLength));
  return items.length ? items : fallback;
}

function defaultPhotoQuality(usedVision: boolean): PhotoQuality {
  return usedVision
    ? { grade: 'moderate', issues: ['Photo quality was not fully verified. Check focus, glare, and framing before relying on the result.'], usableForAnalysis: true, visualChecks: { sharpness: 'moderate', lighting: 'moderate', framing: 'moderate', identifierReadability: 'weak' } }
    : { grade: 'weak', issues: ['No product photo was supplied.'], usableForAnalysis: false, visualChecks: { sharpness: 'weak', lighting: 'weak', framing: 'weak', identifierReadability: 'weak' } };
}

function defaultNextBestAction(focus: AnalysisFocus, usedVision: boolean): NextBestAction {
  const actions: Record<AnalysisFocus, NextBestAction> = {
    overall: { title: 'Capture a full product reference set', rationale: 'A front, label, and serial view gives the reviewer enough context to compare the item without guessing.', evidenceType: 'Full product photo set' },
    logo: { title: 'Capture a sharp logo close-up', rationale: 'Logo geometry, spacing, and edge quality are easier to assess in a straight-on close-up.', evidenceType: 'Logo close-up' },
    packaging: { title: 'Capture packaging seams and typography', rationale: 'Seams, print alignment, and label details can reveal inconsistencies that a wide shot hides.', evidenceType: 'Packaging detail photo' },
    serial: { title: 'Capture the serial or QR/NFC area', rationale: 'A readable identifier is needed before the reviewer can assess code placement or consistency.', evidenceType: 'Serial or code close-up' },
    provenance: { title: 'Add purchase or provenance evidence', rationale: 'Seller, receipt, and chain-of-custody details help distinguish an unusual item from a counterfeit signal.', evidenceType: 'Receipt, seller, or provenance record' },
  };
  return usedVision ? actions[focus] : { ...actions[focus], rationale: 'Add a product image first, then collect this evidence so the review is grounded in visible details.' };
}

function mergeEvidence(items: string[], required: string[], maxItems: number): string[] {
  const result = [...items];
  for (const item of required) {
    if (!result.some((existing) => existing.toLowerCase().includes(item.toLowerCase()))) result.push(item);
  }
  return result.slice(0, maxItems);
}

export function normalizeAuthenticityAnalysis(value: unknown, context: { model: string; usedVision: boolean; fallback?: boolean; focus?: AnalysisFocus; imageCount?: number; reviewMetadata?: EvidenceReviewMetadata; referenceImageCount?: number; provenanceHash?: string }): AuthenticityAnalysis {
  const input = (value && typeof value === 'object' ? value : {}) as Record<string, unknown>;
  const requestedVerdict = verdicts.includes(input.verdict as AuthenticityVerdict) ? input.verdict as AuthenticityVerdict : 'needs_review';
  const requestedConfidence = typeof input.confidence === 'number' && Number.isFinite(input.confidence) ? input.confidence : 50;
  const evidenceQuality = evidenceQualities.includes(input.evidenceQuality as EvidenceQuality) ? input.evidenceQuality as EvidenceQuality : context.usedVision ? 'moderate' : 'weak';
  const qualityCap = evidenceQuality === 'weak' || !context.usedVision ? 70 : evidenceQuality === 'moderate' ? 85 : 100;
  const signals = Array.isArray(input.signals) ? input.signals.slice(0, 6).map((signal) => {
    const item = (signal && typeof signal === 'object' ? signal : {}) as Record<string, unknown>;
    return {
      title: text(item.title, 'Signal requires review', 80),
      status: signalStatuses.includes(item.status as AuthenticitySignalStatus) ? item.status as AuthenticitySignalStatus : 'neutral',
      explanation: text(item.explanation, 'The model could not provide a reliable explanation for this signal.'),
    };
  }) : [];

  const hasCriticalSignal = signals.some((signal) => signal.status === 'critical');
  const hasPositiveSignal = signals.some((signal) => signal.status === 'positive');
  const verdict = !context.usedVision || evidenceQuality === 'weak' || (requestedVerdict === 'high_risk' && !hasCriticalSignal) || (requestedVerdict === 'low_risk' && !hasPositiveSignal)
    ? 'needs_review'
    : requestedVerdict;
  const gateLimitation = verdict !== requestedVerdict
    ? 'The requested risk band was softened because the supplied evidence did not support a confident final classification.'
    : undefined;
  const limitations = stringList(input.limitations, ['AI review is a risk signal, not a legal authenticity determination.'], 4, 180);
  if (gateLimitation && !limitations.includes(gateLimitation)) limitations.push(gateLimitation);
  const selectedFocus = analysisFocuses.includes(input.focus as AnalysisFocus) ? input.focus as AnalysisFocus : context.focus ?? 'overall';
  const imageCount = context.imageCount ?? (context.usedVision ? 1 : 0);
  const rawConsistency = (input.crossPhotoConsistency && typeof input.crossPhotoConsistency === 'object' ? input.crossPhotoConsistency : {}) as Record<string, unknown>;
  const rawReference = (input.referenceComparison && typeof input.referenceComparison === 'object' ? input.referenceComparison : {}) as Record<string, unknown>;
  const referenceComparison: ReferenceComparison | undefined = context.referenceImageCount && context.referenceImageCount > 0 ? { status: rawReference.status === 'matched' || rawReference.status === 'mismatch' || rawReference.status === 'insufficient' ? rawReference.status : 'insufficient', issues: stringList(rawReference.issues, ['The supplied reference set did not support a reliable comparison.'], 4, 180) } : undefined;
  const rawReview = (input.reviewMetadata && typeof input.reviewMetadata === 'object' ? input.reviewMetadata : context.reviewMetadata) as Partial<EvidenceReviewMetadata> | undefined;
  const reviewMetadata = rawReview && typeof rawReview.reviewStartedAt === 'string' ? { imageCount: Math.max(0, Math.min(4, Number(rawReview.imageCount) || imageCount)), reviewedIndexes: Array.isArray(rawReview.reviewedIndexes) ? rawReview.reviewedIndexes.filter((item): item is number => Number.isInteger(item) && item >= 0 && item < 4).slice(0, 4) : [], reviewStartedAt: rawReview.reviewStartedAt.slice(0, 40), reviewCompletedAt: typeof rawReview.reviewCompletedAt === 'string' ? rawReview.reviewCompletedAt.slice(0, 40) : undefined, actions: stringList(rawReview.actions, [], 10, 80) } : undefined;
  const crossPhotoConsistency: CrossPhotoConsistency | undefined = imageCount > 1 ? {
    status: rawConsistency.status === 'consistent' || rawConsistency.status === 'mixed' || rawConsistency.status === 'insufficient' ? rawConsistency.status : 'insufficient',
    issues: stringList(rawConsistency.issues, ['The image set did not provide enough overlap for a reliable cross-photo comparison.'], 4, 180),
  } : undefined;
  const missingEvidence = mergeEvidence(stringList(input.missingEvidence, context.usedVision ? ['Verified reference image'] : ['Product photo', 'Verified reference image'], 5, 180), focusEvidence[selectedFocus], 5);
  const modelPhotoQuality = (input.photoQuality && typeof input.photoQuality === 'object' ? input.photoQuality : {}) as Record<string, unknown>;
  const defaultQuality = defaultPhotoQuality(context.usedVision);
  const photoGrade = evidenceQualities.includes(modelPhotoQuality.grade as EvidenceQuality) ? modelPhotoQuality.grade as EvidenceQuality : defaultQuality.grade;
  const photoIssues = stringList(modelPhotoQuality.issues, defaultQuality.issues, 4, 180);
  const modelChecks = (modelPhotoQuality.visualChecks && typeof modelPhotoQuality.visualChecks === 'object' ? modelPhotoQuality.visualChecks : {}) as Record<string, unknown>;
  const defaultChecks = defaultQuality.visualChecks;
  const visualChecks = defaultChecks ? {
    sharpness: evidenceQualities.includes(modelChecks.sharpness as EvidenceQuality) ? modelChecks.sharpness as EvidenceQuality : defaultChecks.sharpness,
    lighting: evidenceQualities.includes(modelChecks.lighting as EvidenceQuality) ? modelChecks.lighting as EvidenceQuality : defaultChecks.lighting,
    framing: evidenceQualities.includes(modelChecks.framing as EvidenceQuality) ? modelChecks.framing as EvidenceQuality : defaultChecks.framing,
    identifierReadability: evidenceQualities.includes(modelChecks.identifierReadability as EvidenceQuality) ? modelChecks.identifierReadability as EvidenceQuality : defaultChecks.identifierReadability,
  } : undefined;
  const photoQuality: PhotoQuality = {
    grade: photoGrade,
    issues: photoIssues,
    usableForAnalysis: typeof modelPhotoQuality.usableForAnalysis === 'boolean' ? modelPhotoQuality.usableForAnalysis : defaultQuality.usableForAnalysis,
    visualChecks,
  };
  const photoQualityCap = !photoQuality.usableForAnalysis || photoQuality.grade === 'weak' ? 55 : photoQuality.grade === 'moderate' ? 85 : 100;
  const modelAction = (input.nextBestAction && typeof input.nextBestAction === 'object' ? input.nextBestAction : {}) as Record<string, unknown>;
  const defaultAction = defaultNextBestAction(selectedFocus, context.usedVision);
  const nextBestAction: NextBestAction = {
    title: text(modelAction.title, defaultAction.title, 100),
    rationale: text(modelAction.rationale, defaultAction.rationale, 220),
    evidenceType: text(modelAction.evidenceType, defaultAction.evidenceType, 100),
  };

  return {
    verdict,
    confidence: Math.max(0, Math.min(qualityCap, photoQualityCap, Math.round(requestedConfidence))),
    summary: text(input.summary, 'Review the product signals before making a final authenticity decision.'),
    signals: signals.length ? signals : [{ title: 'Insufficient evidence', status: 'warning', explanation: 'Add clearer product photos or provenance details for a more useful comparison.' }],
    recommendedAction: text(input.recommendedAction, 'Compare the item with a verified reference and keep the evidence attached to the case.'),
    nextBestAction,
    photoQuality,
    limitations,
    observedDetails: stringList(input.observedDetails, ['No reliable visual details were returned.'], 5, 180),
    missingEvidence,
    evidenceQuality,
    model: context.model,
    usedVision: context.usedVision,
    fallback: context.fallback ?? false,
    focus: selectedFocus,
    crossPhotoConsistency,
    reviewMetadata,
    referenceComparison,
    provenanceHash: context.provenanceHash,
  };
}

export function fallbackAuthenticityAnalysis(context: { model: string; usedVision: boolean; reason?: string; focus?: AnalysisFocus }): AuthenticityAnalysis {
  return normalizeAuthenticityAnalysis({
    verdict: 'needs_review',
    confidence: 42,
    evidenceQuality: context.usedVision ? 'moderate' : 'weak',
    summary: 'The AI reviewer is unavailable, so Hypercube saved a cautious review state instead of guessing.',
    signals: [
      { title: 'Manual review required', status: 'warning', explanation: context.reason ?? 'The analysis service did not return a complete result.' },
      { title: 'Evidence preserved', status: 'positive', explanation: 'Your scan metadata and attached photos remain available for investigator review.' },
    ],
    observedDetails: [],
    missingEvidence: context.usedVision ? ['Verified reference image'] : ['Product photo', 'Verified reference image'],
    recommendedAction: 'Add a clearer logo, label, or serial photo and try the analysis again.',
    nextBestAction: defaultNextBestAction(context.focus ?? 'overall', context.usedVision),
    photoQuality: defaultPhotoQuality(context.usedVision),
    limitations: ['This result is a fallback state and should not be treated as an authenticity verdict.'],
  }, { model: context.model, usedVision: context.usedVision, fallback: true, focus: context.focus });
}
