export type CaseTimelineEvent = {
  title: string;
  body: string;
  time: string;
};

export type CaseSummary = {
  id: string;
  product: string;
  risk: string;
  location: string;
  summary: string;
  rationale: string;
  assignee: string;
  status: string;
  events: CaseTimelineEvent[];
};

export function formatCaseSummaryExport(caseSummary: CaseSummary): string {
  return JSON.stringify({
    exportedAt: new Date().toISOString(),
    source: 'hypercube-mobile',
    case: caseSummary,
  }, null, 2);
}
