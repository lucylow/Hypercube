import type { AnalysisFocus } from './ai';

export type CaptureGuide = {
  title: string;
  tip: string;
  steps: string[];
};

const GUIDES: Record<AnalysisFocus, CaptureGuide> = {
  overall: {
    title: 'Build a complete evidence set',
    tip: 'Keep the product centered and use even light so the reviewer can compare more than one surface.',
    steps: ['Front product view', 'Brand label or logo', 'Serial, QR, or NFC area'],
  },
  logo: {
    title: 'Capture the logo precisely',
    tip: 'Hold the phone parallel to the mark and avoid glare or motion blur.',
    steps: ['Fill the frame with the logo', 'Keep edges and spacing visible', 'Avoid reflections and shadows'],
  },
  packaging: {
    title: 'Capture packaging details',
    tip: 'Packaging inconsistencies often appear at seams, print alignment, and label edges.',
    steps: ['Show the full package face', 'Capture seams and label edges', 'Include typography at close range'],
  },
  serial: {
    title: 'Capture the identifier',
    tip: 'The code must be readable without cropping the surrounding placement context.',
    steps: ['Keep the full code in frame', 'Use steady, even lighting', 'Include nearby label context'],
  },
  provenance: {
    title: 'Capture provenance evidence',
    tip: 'Pair the product image with records that establish where and when it was purchased.',
    steps: ['Product and seller context', 'Receipt or order record', 'Date, source, or chain-of-custody detail'],
  },
};

export function getCaptureGuide(focus: AnalysisFocus): CaptureGuide {
  return GUIDES[focus];
}
