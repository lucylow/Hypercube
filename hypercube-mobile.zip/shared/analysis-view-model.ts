import type { AnalysisFeedback, AnalysisFocus, AuthenticityAnalysis } from './ai';
import { analysisSourceLabel, analysisStateLabel, verdictPresentation } from './analysis-result';

export type AnalysisViewModel = {
  verdict: ReturnType<typeof verdictPresentation>;
  sourceLabel: string;
  stateLabel: string;
  subtitle: string;
  metaLabel: string;
  showRetry: boolean;
  focus: AnalysisFocus;
  feedback: AnalysisFeedback | null;
};

export function createAnalysisViewModel(input: {
  analysis: AuthenticityAnalysis;
  focus: AnalysisFocus;
  isProvisional: boolean;
  feedback: AnalysisFeedback | null;
  hasError: boolean;
}): AnalysisViewModel {
  const { analysis, focus, isProvisional, feedback, hasError } = input;
  const subtitle = isProvisional
    ? 'This is a cautious provisional review while AI compares the evidence. Review the signals before making a final decision.'
    : analysis.fallback
      ? 'AI is temporarily unavailable. This cautious fallback keeps your evidence reviewable without guessing.'
      : analysis.usedVision
        ? 'Vision analysis used the attached product photo. Review each signal before making a final decision.'
        : 'Text and scan-context analysis completed. Add a product photo for stronger visual evidence.';
  return {
    verdict: verdictPresentation(analysis.verdict),
    sourceLabel: analysisSourceLabel(analysis),
    stateLabel: analysisStateLabel({ fallback: analysis.fallback, isProvisional }),
    subtitle,
    metaLabel: isProvisional ? 'AI review in progress' : analysis.fallback ? 'Fallback review state' : `Analyzed with ${analysis.model}`,
    showRetry: Boolean(hasError || (analysis.fallback && !isProvisional)),
    focus,
    feedback,
  };
}
