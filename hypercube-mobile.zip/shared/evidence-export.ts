import type { EvidenceDraft } from '@/lib/evidence-model';

export type EvidenceExportScope = 'selected' | 'filtered';

function csvCell(value: unknown): string {
  const text = value == null ? '' : String(value);
  return `"${text.replace(/"/g, '""')}"`;
}

function metadata(draft: EvidenceDraft) {
  return {
    caseId: draft.caseId,
    evidenceType: draft.evidenceType,
    note: draft.note,
    photoCount: draft.photos.length,
    syncState: draft.syncState,
    syncProgress: draft.syncProgress ?? 0,
    syncAttemptCount: draft.syncAttemptCount ?? 0,
    lastAttemptAt: draft.lastAttemptAt ?? null,
    nextRetryAt: draft.nextRetryAt ?? null,
    errorMessage: draft.errorMessage ?? null,
    recoveryHint: draft.recoveryHint ?? null,
    updatedAt: draft.updatedAt,
  };
}

export function formatEvidenceDraftSetExport(drafts: EvidenceDraft[], scope: EvidenceExportScope): string {
  return JSON.stringify({ exportedAt: new Date().toISOString(), scope, count: drafts.length, drafts: drafts.map(metadata) }, null, 2);
}

export function formatEvidenceDraftSetCsv(drafts: EvidenceDraft[]): string {
  const headers = ['caseId', 'evidenceType', 'photoCount', 'syncState', 'syncProgress', 'syncAttemptCount', 'lastAttemptAt', 'nextRetryAt', 'errorMessage', 'recoveryHint', 'updatedAt', 'note'];
  const rows = drafts.map((draft) => {
    const item = metadata(draft);
    return [item.caseId, item.evidenceType, item.photoCount, item.syncState, item.syncProgress, item.syncAttemptCount, item.lastAttemptAt, item.nextRetryAt, item.errorMessage, item.recoveryHint, item.updatedAt, item.note].map(csvCell).join(',');
  });
  return [headers.map(csvCell).join(','), ...rows].join('\n');
}
