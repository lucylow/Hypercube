import type { AnalysisRecord } from './ai-history';

export function formatAnalysisExport(record: AnalysisRecord): string {
  return JSON.stringify({
    exportedBy: 'Hypercube Mobile',
    exportedAt: new Date().toISOString(),
    record,
  }, null, 2);
}

export function formatAnalysisSetExport(records: AnalysisRecord[], scope: 'filtered' | 'selected'): string {
  return JSON.stringify({
    exportedBy: 'Hypercube Mobile',
    exportedAt: new Date().toISOString(),
    scope,
    count: records.length,
    records,
  }, null, 2);
}

export function formatAnalysisSetCsv(records: AnalysisRecord[]): string {
  const header = ['id', 'code', 'focus', 'createdAt', 'verdict', 'confidence', 'summary', 'recommendedAction', 'source'].join(',');
  const rows = records.map((record) => [
    record.id,
    record.code ?? '',
    record.focus,
    record.createdAt,
    record.analysis.verdict,
    record.analysis.confidence,
    record.analysis.summary,
    record.analysis.recommendedAction,
    record.analysis.usedVision ? 'vision' : 'fallback',
  ].map(csvCell).join(','));
  return [header, ...rows].join('\\n');
}

function csvCell(value: string | number): string {
  return `"${String(value).replace(/"/g, '""')}"`;
}
