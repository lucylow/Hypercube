import type { AnalysisFocus, AuthenticityAnalysis } from './ai';

export type AnalysisRecord = {
  id: string;
  code?: string;
  focus: AnalysisFocus;
  createdAt: string;
  analysis: AuthenticityAnalysis;
};

export function createAnalysisRecord(input: { code?: string; focus: AnalysisFocus; analysis: AuthenticityAnalysis; now?: string }): AnalysisRecord {
  const createdAt = input.now ?? new Date().toISOString();
  return {
    id: `${input.code ?? 'scan'}-${createdAt}`,
    code: input.code,
    focus: input.focus,
    createdAt,
    analysis: input.analysis,
  };
}

export function appendAnalysisRecord(history: AnalysisRecord[], record: AnalysisRecord, limit = 20): AnalysisRecord[] {
  return [record, ...history.filter((item) => item.id !== record.id)].slice(0, limit);
}
