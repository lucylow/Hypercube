import type { AuthenticityAnalysis, AuthenticitySignalStatus } from './ai';

export type ResultTone = 'success' | 'warning' | 'danger' | 'neutral';

export function signalTone(status: AuthenticitySignalStatus): ResultTone {
  if (status === 'positive') return 'success';
  if (status === 'warning') return 'warning';
  if (status === 'critical') return 'danger';
  return 'neutral';
}

export function verdictPresentation(verdict: AuthenticityAnalysis['verdict']): { label: string; tone: Exclude<ResultTone, 'neutral'> } {
  if (verdict === 'low_risk') return { label: 'Low risk', tone: 'success' };
  if (verdict === 'high_risk') return { label: 'High risk', tone: 'danger' };
  return { label: 'Needs review', tone: 'warning' };
}

export function qualityTone(quality: 'strong' | 'moderate' | 'weak'): Exclude<ResultTone, 'neutral'> {
  return quality === 'strong' ? 'success' : quality === 'moderate' ? 'warning' : 'danger';
}

export function analysisSourceLabel(analysis: Pick<AuthenticityAnalysis, 'usedVision'>): string {
  return analysis.usedVision ? 'Product photo' : 'Scan context';
}

export function analysisStateLabel(input: { isProvisional: boolean; fallback: boolean }): string {
  if (input.fallback) return 'Fallback';
  if (input.isProvisional) return 'Working';
  return 'Reviewed';
}
