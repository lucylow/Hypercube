export type EvidenceSyncErrorCategory = 'network' | 'storage' | 'permission' | 'validation' | 'unknown';

export function classifyEvidenceSyncError(message?: string): EvidenceSyncErrorCategory | null {
  if (!message?.trim()) return null;
  const normalized = message.toLowerCase();
  if (/(network|offline|timeout|timed out|connection|fetch)/.test(normalized)) return 'network';
  if (/(permission|denied|unauthorized|forbidden)/.test(normalized)) return 'permission';
  if (/(storage|disk|file|filesystem)/.test(normalized)) return 'storage';
  if (/(required|invalid|missing|validation)/.test(normalized)) return 'validation';
  return 'unknown';
}

export function evidenceSyncErrorLabel(category: EvidenceSyncErrorCategory | null): string | null {
  if (!category) return null;
  return {
    network: 'Network issue',
    storage: 'Device storage issue',
    permission: 'Permission issue',
    validation: 'Review required',
    unknown: 'Sync issue',
  }[category];
}
