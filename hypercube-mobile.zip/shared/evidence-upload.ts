export type EvidencePhotoPayload = {
  mimeType: string;
  base64: string;
};

const DATA_URL_PATTERN = /^data:(image\/(?:jpeg|jpg|png|webp|heic));base64,([A-Za-z0-9+/=]+)$/i;

export function parseEvidencePhotoDataUrl(dataUrl: string): EvidencePhotoPayload {
  const match = DATA_URL_PATTERN.exec(dataUrl);
  if (!match) throw new Error('Evidence photo must be a base64 image data URL.');
  const [, mimeType, base64] = match;
  if (base64.length > 8_000_000) throw new Error('Evidence photo exceeds the 6 MB upload limit.');
  return { mimeType: mimeType.toLowerCase() === 'image/jpg' ? 'image/jpeg' : mimeType.toLowerCase(), base64 };
}

export function evidencePhotoExtension(mimeType: string): string {
  return mimeType === 'image/png' ? 'png' : mimeType === 'image/webp' ? 'webp' : mimeType === 'image/heic' ? 'heic' : 'jpg';
}
