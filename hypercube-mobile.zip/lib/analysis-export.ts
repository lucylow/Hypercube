import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { Platform } from 'react-native';
import type { AnalysisRecord } from '@/shared/ai-history';
import { formatAnalysisExport, formatAnalysisSetCsv, formatAnalysisSetExport } from '@/shared/analysis-export';

function filename(record: AnalysisRecord): string {
  const safeCode = (record.code || 'scan').replace(/[^a-z0-9-_]+/gi, '-').replace(/^-|-$/g, '').toLowerCase();
  return `hypercube-${safeCode || 'scan'}-${record.createdAt.slice(0, 10)}.json`;
}

export async function exportAnalysisRecords(records: AnalysisRecord[], scope: 'filtered' | 'selected'): Promise<'shared' | 'downloaded' | 'unavailable'> {
  const name = `hypercube-${scope}-reviews-${new Date().toISOString().slice(0, 10)}.json`;
  const content = formatAnalysisSetExport(records, scope);

  if (Platform.OS === 'web') {
    if (typeof document === 'undefined') return 'unavailable';
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return 'downloaded';
  }

  const uri = `${FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? ''}${name}`;
  if (!uri) return 'unavailable';
  await FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 });
  if (!(await Sharing.isAvailableAsync())) return 'unavailable';
  await Sharing.shareAsync(uri, { dialogTitle: 'Export Hypercube reviews', mimeType: 'application/json' });
  return 'shared';
}

export async function exportAnalysisSetCsv(records: AnalysisRecord[], scope: 'filtered' | 'selected'): Promise<'shared' | 'downloaded' | 'unavailable'> {
  const name = `hypercube-${scope}-reviews-${new Date().toISOString().slice(0, 10)}.csv`;
  const content = formatAnalysisSetCsv(records);

  if (Platform.OS === 'web') {
    if (typeof document === 'undefined') return 'unavailable';
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return 'downloaded';
  }

  const uri = `${FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? ''}${name}`;
  if (!uri) return 'unavailable';
  await FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 });
  if (!(await Sharing.isAvailableAsync())) return 'unavailable';
  await Sharing.shareAsync(uri, { dialogTitle: 'Export Hypercube CSV', mimeType: 'text/csv' });
  return 'shared';
}

export async function exportAnalysisRecord(record: AnalysisRecord): Promise<'shared' | 'downloaded' | 'unavailable'> {
  const name = filename(record);
  const content = formatAnalysisExport(record);

  if (Platform.OS === 'web') {
    if (typeof document === 'undefined') return 'unavailable';
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return 'downloaded';
  }

  const uri = `${FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? ''}${name}`;
  if (!uri) return 'unavailable';
  await FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 });
  if (!(await Sharing.isAvailableAsync())) return 'unavailable';
  await Sharing.shareAsync(uri, { dialogTitle: 'Export Hypercube analysis', mimeType: 'application/json' });
  return 'shared';
}
