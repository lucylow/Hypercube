import * as BackgroundTask from 'expo-background-task';
import * as Network from 'expo-network';
import * as TaskManager from 'expo-task-manager';
import { createTRPCClient } from '@/lib/trpc';
import { listEvidenceDrafts, saveEvidenceDraft } from '@/lib/evidence-storage';
import { appendEvidenceSyncEvent, type EvidenceDraft } from '@/lib/evidence-model';
import { readEvidencePhotoDataUrl } from '@/lib/evidence-upload';

export const EVIDENCE_SYNC_TASK = 'hypercube-evidence-sync';

function retryAt(attempt: number): string {
  const delayMinutes = Math.min(60, 2 ** Math.min(attempt, 5));
  return new Date(Date.now() + delayMinutes * 60_000).toISOString();
}

function event(status: 'queued' | 'uploading' | 'synced' | 'failed' | 'offline', message: string, receiptId?: string) {
  return { id: `sync-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, occurredAt: new Date().toISOString(), status, message, receiptId } as const;
}

function withProgress(draft: EvidenceDraft, patch: Partial<EvidenceDraft>): EvidenceDraft {
  return { ...draft, ...patch, updatedAt: new Date().toISOString() };
}

export async function syncQueuedEvidenceDrafts(): Promise<'synced' | 'offline' | 'failed' | 'empty'> {
  const network = await Network.getNetworkStateAsync();
  const queued = (await listEvidenceDrafts()).filter((draft) => draft.syncState === 'queued' || draft.syncState === 'failed');
  if (!queued.length) return 'empty';
  if (!network.isInternetReachable) {
    await Promise.all(queued.map((draft) => saveEvidenceDraft(appendEvidenceSyncEvent(withProgress(draft, {
      nextRetryAt: retryAt(draft.syncAttemptCount ?? 0),
      recoveryHint: 'Reconnect to the internet; the app will retry automatically.',
    }), event('offline', 'Sync deferred because internet is not reachable.')))));
    return 'offline';
  }

  const client = createTRPCClient();
  let failed = false;
  for (const draft of queued) {
    const attempt = (draft.syncAttemptCount ?? 0) + 1;
    const started = withProgress(draft, {
      syncState: 'uploading',
      syncProgress: 20,
      syncAttemptCount: attempt,
      lastAttemptAt: new Date().toISOString(),
      errorMessage: undefined,
      recoveryHint: undefined,
      nextRetryAt: undefined,
    });
    await saveEvidenceDraft(appendEvidenceSyncEvent(started, event('uploading', 'Sync attempt started.')));
    let working = started;
    let activePhotoId: string | undefined;
    try {
      const pendingPhotos = working.photos.filter((photo) => !photo.remoteUrl);
      for (let index = 0; index < pendingPhotos.length; index += 1) {
        const photo = pendingPhotos[index];
        activePhotoId = photo.id;
        working = withProgress(working, { photos: working.photos.map((item) => item.id === photo.id ? { ...item, uploadState: 'uploading', uploadError: undefined } : item) });
        await saveEvidenceDraft(working);
        const dataUrl = await readEvidencePhotoDataUrl(photo.uri);
        const uploaded = await client.evidence.uploadPhoto.mutate({ caseId: working.caseId, photoId: photo.id, dataUrl });
        working = withProgress(working, {
          syncProgress: 20 + Math.round(((index + 1) / pendingPhotos.length) * 60),
          photos: working.photos.map((item) => item.id === photo.id ? { ...item, remoteUrl: uploaded.url, remoteKey: uploaded.key, integrityHash: uploaded.integrityHash, uploadState: 'uploaded', uploadError: undefined } : item),
        });
        await saveEvidenceDraft(appendEvidenceSyncEvent(working, event('uploading', `Uploaded evidence photo ${index + 1} of ${pendingPhotos.length}.`)));
      }
      const receipt = await client.evidence.syncDraft.mutate({ caseId: working.caseId, evidenceType: working.evidenceType, note: working.note, photoCount: working.photos.length, photoUrls: working.photos.flatMap((photo) => photo.remoteUrl ? [photo.remoteUrl] : []), updatedAt: working.updatedAt });
      if (!receipt.accepted) {
        failed = true;
        await saveEvidenceDraft(appendEvidenceSyncEvent(withProgress(working, { syncState: 'failed', syncProgress: 80, errorMessage: receipt.reason, recoveryHint: 'Open Plan and usage, upgrade if needed, then retry this evidence draft.', nextRetryAt: retryAt(attempt) }), event('failed', 'Server blocked this handoff because the plan limit was reached.')));
        continue;
      }
      await saveEvidenceDraft(appendEvidenceSyncEvent(withProgress(working, { syncState: 'synced', syncProgress: 100, lastReceiptId: receipt.receiptId }), event('synced', 'Server accepted evidence metadata and photos.', receipt.receiptId)));
    } catch (error) {
      failed = true;
      await saveEvidenceDraft(appendEvidenceSyncEvent(withProgress(working, {
        syncState: 'failed',
        photos: activePhotoId ? working.photos.map((photo) => photo.id === activePhotoId ? { ...photo, uploadState: 'failed', uploadError: error instanceof Error ? error.message : 'Photo upload failed.' } : photo) : working.photos,
        syncProgress: 0,
        errorMessage: error instanceof Error ? error.message : 'Evidence sync failed.',
        recoveryHint: 'Check your connection or sign in again, then retry this draft.',
        nextRetryAt: retryAt(attempt),
      }), event('failed', 'Sync attempt failed; recovery action is available.')));
    }
  }
  return failed ? 'failed' : 'synced';
}

TaskManager.defineTask(EVIDENCE_SYNC_TASK, async () => {
  try {
    const result = await syncQueuedEvidenceDrafts();
    return result === 'failed' ? BackgroundTask.BackgroundTaskResult.Failed : BackgroundTask.BackgroundTaskResult.Success;
  } catch {
    return BackgroundTask.BackgroundTaskResult.Failed;
  }
});

export async function registerEvidenceBackgroundSync(): Promise<void> {
  const registered = await TaskManager.isTaskRegisteredAsync(EVIDENCE_SYNC_TASK);
  if (!registered) await BackgroundTask.registerTaskAsync(EVIDENCE_SYNC_TASK);
}
