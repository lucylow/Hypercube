import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AnalysisRecord } from '@/shared/ai-history';

export type ExportFormat = 'json' | 'csv';
export type ExportStatus = 'shared' | 'downloaded' | 'unavailable' | 'failed';

export type ExportHistoryEntry = {
  id: string;
  createdAt: string;
  scope: 'filtered' | 'selected';
  format: ExportFormat;
  count: number;
  status: ExportStatus;
  records?: AnalysisRecord[];
  caseId?: string;
};

const STORAGE_KEY = '@hypercube/export-history/v1';
const HISTORY_LIMIT = 10;

export function isEvidenceAuditExport(entry: ExportHistoryEntry): boolean {
  return entry.id.startsWith('audit-');
}

export async function readExportHistory(): Promise<ExportHistoryEntry[]> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed as ExportHistoryEntry[] : [];
  } catch {
    return [];
  }
}

export function prependExportHistory(history: ExportHistoryEntry[], entry: ExportHistoryEntry, limit = HISTORY_LIMIT): ExportHistoryEntry[] {
  return [entry, ...history.filter((item) => item.id !== entry.id)].slice(0, limit);
}

export async function appendExportHistory(entry: ExportHistoryEntry): Promise<void> {
  const history = await readExportHistory();
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(prependExportHistory(history, entry)));
}

export function removeExportHistoryEntry(history: ExportHistoryEntry[], entryId: string): ExportHistoryEntry[] {
  return history.filter((entry) => entry.id !== entryId);
}

export function removeExportHistoryEntries(history: ExportHistoryEntry[], entryIds: string[]): ExportHistoryEntry[] {
  const ids = new Set(entryIds);
  return history.filter((entry) => !ids.has(entry.id));
}

export async function deleteExportHistoryEntry(entryId: string): Promise<void> {
  const history = await readExportHistory();
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(removeExportHistoryEntry(history, entryId)));
}

export async function deleteExportHistoryEntries(entryIds: string[]): Promise<void> {
  const history = await readExportHistory();
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(removeExportHistoryEntries(history, entryIds)));
}

export async function clearExportHistory(): Promise<void> {
  await AsyncStorage.removeItem(STORAGE_KEY);
}
