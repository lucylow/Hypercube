const IGNORED_RUNTIME_WARNINGS = ['props.pointerEvents is deprecated', '"shadow*" style props are deprecated'];
let warningFilterInstalled = false;

export function isKnownExpoDependencyWarning(message: string): boolean {
  return IGNORED_RUNTIME_WARNINGS.some((warning) => message.includes(warning));
}

export function installKnownExpoDependencyWarningFilter(): void {
  if (warningFilterInstalled) return;
  warningFilterInstalled = true;
  const originalWarn = console.warn;
  console.warn = (...args: unknown[]) => {
    const message = args.map(String).join(' ');
    if (isKnownExpoDependencyWarning(message)) return;
    originalWarn(...args);
  };
}

export const knownExpoDependencyWarnings = [...IGNORED_RUNTIME_WARNINGS];
