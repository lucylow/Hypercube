import * as FileSystem from 'expo-file-system/legacy';
import { Platform } from 'react-native';

function mimeTypeForUri(uri: string): string {
  const extension = uri.split('.').pop()?.split('?')[0]?.toLowerCase();
  if (extension === 'png') return 'image/png';
  if (extension === 'webp') return 'image/webp';
  if (extension === 'heic') return 'image/heic';
  return 'image/jpeg';
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error ?? new Error('Could not read evidence photo.'));
  });
}

export async function readEvidencePhotoDataUrl(uri: string): Promise<string> {
  if (uri.startsWith('data:image/')) return uri;
  if (Platform.OS === 'web') {
    return blobToDataUrl(await fetch(uri).then((response) => {
      if (!response.ok) throw new Error('Evidence photo could not be read.');
      return response.blob();
    }));
  }
  const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
  return `data:${mimeTypeForUri(uri)};base64,${base64}`;
}
