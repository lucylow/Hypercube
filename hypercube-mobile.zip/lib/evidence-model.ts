export type EvidenceType = 'Product detail' | 'Document';
export type EvidenceSyncState = 'draft' | 'uploading' | 'failed' | 'queued' | 'synced';

export type EvidenceSyncEvent = {
  id: string;
  occurredAt: string;
  status: 'queued' | 'uploading' | 'synced' | 'failed' | 'offline' | 'previewed' | 'reviewed' | 'retaken' | 'removed' | 'reordered' | 'submitted';
  message: string;
  receiptId?: string;
};

export type EvidencePhoto = {
  id: string;
  uri: string;
  createdAt: string;
  remoteUrl?: string;
  remoteKey?: string;
  integrityHash?: string;
  uploadState?: 'pending' | 'uploading' | 'uploaded' | 'failed';
  uploadError?: string;
};

export type EvidenceDraft = {
  caseId: string;
  evidenceType: EvidenceType;
  note: string;
  photos: EvidencePhoto[];
  syncState: EvidenceSyncState;
  uploadProgress: number;
  errorMessage?: string;
  updatedAt: string;
  lastAttemptAt?: string;
  syncProgress?: number;
  syncAttemptCount?: number;
  nextRetryAt?: string;
  recoveryHint?: string;
  syncHistory?: EvidenceSyncEvent[];
  lastReceiptId?: string;
  reviewedPhotoIds?: string[];
  reviewStartedAt?: string;
  reviewCompletedAt?: string;
};

function now() {
  return new Date().toISOString();
}

export function createEmptyEvidenceDraft(caseId: string): EvidenceDraft {
  return {
    caseId,
    evidenceType: 'Product detail',
    note: '',
    photos: [],
    syncState: 'draft',
    uploadProgress: 0,
    updatedAt: now(),
    syncProgress: 0,
    syncAttemptCount: 0,
    syncHistory: [],
    reviewedPhotoIds: [],
  };
}

export type EvidenceSyncHistoryFilter = 'all' | 'handoff' | 'photo';

export function sortEvidenceSyncEvents(events: EvidenceSyncEvent[]): EvidenceSyncEvent[] {
  return [...events].sort((a, b) => b.occurredAt.localeCompare(a.occurredAt));
}

export function filterEvidenceSyncEvents(events: EvidenceSyncEvent[], filter: EvidenceSyncHistoryFilter): EvidenceSyncEvent[] {
  if (filter === 'all') return [...events];
  if (filter === 'photo') return events.filter((event) => event.status === 'previewed');
  return events.filter((event) => event.status !== 'previewed');
}

export function buildEvidenceAuditExport(draft: EvidenceDraft, events: EvidenceSyncEvent[]) {
  return {
    caseId: draft.caseId,
    evidenceType: draft.evidenceType,
    updatedAt: draft.updatedAt,
    lastReceiptId: draft.lastReceiptId ?? null,
    photoCount: draft.photos.length,
    uploadedPhotoCount: getEvidencePhotoUploadSummary(draft).uploaded,
    review: { reviewedPhotoIds: draft.reviewedPhotoIds ?? [], reviewStartedAt: draft.reviewStartedAt ?? null, reviewCompletedAt: draft.reviewCompletedAt ?? null, photoOrder: draft.photos.map((photo) => photo.id) },
    events: sortEvidenceSyncEvents(events).map((event) => ({ ...event })),
  };
}

function csvCell(value: string | number | null) {
  return `"${String(value ?? '').replace(/"/g, '""')}"`;
}

export function buildEvidenceAuditCsv(draft: EvidenceDraft, events: EvidenceSyncEvent[]): string {
  const rows = [
    ['case_id', 'evidence_type', 'updated_at', 'last_receipt_id', 'photo_count', 'uploaded_photo_count', 'reviewed_photo_ids', 'review_started_at', 'review_completed_at', 'photo_order', 'photo_manifest', 'event_id', 'event_time', 'status', 'message', 'event_receipt_id'],
    ...sortEvidenceSyncEvents(events).map((event) => [draft.caseId, draft.evidenceType, draft.updatedAt, draft.lastReceiptId ?? '', draft.photos.length, getEvidencePhotoUploadSummary(draft).uploaded, JSON.stringify(draft.reviewedPhotoIds ?? []), draft.reviewStartedAt ?? '', draft.reviewCompletedAt ?? '', JSON.stringify(draft.photos.map((photo) => photo.id)), JSON.stringify(draft.photos.map((photo) => ({ id: photo.id, createdAt: photo.createdAt, uploadState: photo.uploadState, remoteKey: photo.remoteKey ?? null, integrityHash: photo.integrityHash ?? null })),), event.id, event.occurredAt, event.status, event.message, event.receiptId ?? '']),
  ];
  return rows.map((row) => row.map((cell) => csvCell(cell)).join(',')).join('\\n');
}

export function appendEvidenceSyncEvent(draft: EvidenceDraft, event: EvidenceSyncEvent): EvidenceDraft {
  const history = [...(draft.syncHistory ?? []), event].slice(-10);
  return { ...draft, syncHistory: history };
}

export function queueEvidencePhotoRetry(draft: EvidenceDraft, photoId: string): EvidenceDraft {
  if (!draft.photos.some((photo) => photo.id === photoId)) return draft;
  return {
    ...draft,
    syncState: 'queued',
    errorMessage: undefined,
    recoveryHint: undefined,
    photos: draft.photos.map((photo) => photo.id === photoId ? { ...photo, uploadState: 'pending', uploadError: undefined } : photo),
  };
}

export function getEvidencePhotoUploadSummary(draft: EvidenceDraft): { total: number; uploaded: number; pending: number; failed: number } {
  return draft.photos.reduce((summary, photo) => {
    summary.total += 1;
    if (photo.remoteUrl || photo.uploadState === 'uploaded') summary.uploaded += 1;
    else if (photo.uploadState === 'failed') summary.failed += 1;
    else summary.pending += 1;
    return summary;
  }, { total: 0, uploaded: 0, pending: 0, failed: 0 });
}

export function sortEvidenceDrafts(drafts: EvidenceDraft[]): EvidenceDraft[] {
  return [...drafts].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export function reorderEvidencePhotos(photos: EvidencePhoto[], fromIndex: number, toIndex: number): EvidencePhoto[] {
  if (fromIndex === toIndex || fromIndex < 0 || toIndex < 0 || fromIndex >= photos.length || toIndex >= photos.length) return photos;
  const next = [...photos];
  const [moved] = next.splice(fromIndex, 1);
  next.splice(toIndex, 0, moved);
  return next;
}

export function isEvidenceReadyForUpload(draft: EvidenceDraft): boolean {
  return draft.photos.length > 0 && draft.note.trim().length > 0;
}
