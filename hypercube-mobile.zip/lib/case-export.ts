import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { Platform } from 'react-native';
import { formatCaseSummaryExport, type CaseSummary } from '@/shared/case-export';

export async function exportCaseSummary(caseSummary: CaseSummary): Promise<'shared' | 'downloaded' | 'unavailable'> {
  const name = `hypercube-case-${caseSummary.id.toLowerCase().replace(/[^a-z0-9-]+/g, '-')}.json`;
  const content = formatCaseSummaryExport(caseSummary);

  if (Platform.OS === 'web') {
    if (typeof document === 'undefined') return 'unavailable';
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return 'downloaded';
  }

  const uri = `${FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? ''}${name}`;
  if (!uri) return 'unavailable';
  await FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 });
  if (!(await Sharing.isAvailableAsync())) return 'unavailable';
  await Sharing.shareAsync(uri, { dialogTitle: 'Export Hypercube case', mimeType: 'application/json' });
  return 'shared';
}
