import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import { Platform } from 'react-native';

export type { EvidenceDraft, EvidencePhoto, EvidenceSyncState, EvidenceType } from './evidence-model';
import { sortEvidenceDrafts, type EvidenceDraft, type EvidencePhoto } from './evidence-model';

const STORAGE_KEY = 'hypercube:evidence-drafts:v1';

function now() {
  return new Date().toISOString();
}

function createPhotoId() {
  return `photo-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

async function readAllDrafts(): Promise<Record<string, EvidenceDraft>> {
  const raw = await AsyncStorage.getItem(STORAGE_KEY);
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, EvidenceDraft>;
  } catch {
    return {};
  }
}

export async function loadEvidenceDraft(caseId: string): Promise<EvidenceDraft | null> {
  const drafts = await readAllDrafts();
  return drafts[caseId] ?? null;
}

export async function listEvidenceDrafts(): Promise<EvidenceDraft[]> {
  const drafts = await readAllDrafts();
  return sortEvidenceDrafts(Object.values(drafts));
}

export async function saveEvidenceDraft(draft: EvidenceDraft): Promise<void> {
  const drafts = await readAllDrafts();
  drafts[draft.caseId] = { ...draft, updatedAt: now() };
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(drafts));
}

export async function createEvidencePhoto(uri: string): Promise<EvidencePhoto> {
  const id = createPhotoId();
  let localUri = uri;

  if (Platform.OS !== 'web' && FileSystem.documentDirectory) {
    const extension = uri.split('.').pop()?.split('?')[0] || 'jpg';
    const destination = `${FileSystem.documentDirectory}hypercube-evidence-${id}.${extension}`;
    try {
      await FileSystem.copyAsync({ from: uri, to: destination });
      localUri = destination;
    } catch {
      // Keep the original picker URI as a fallback when the platform cannot copy it.
    }
  }

  return { id, uri: localUri, createdAt: now() };
}

export async function deleteEvidencePhoto(photo: EvidencePhoto): Promise<void> {
  if (Platform.OS === 'web' || !photo.uri.startsWith('file://')) return;
  try {
    const info = await FileSystem.getInfoAsync(photo.uri);
    if (info.exists) await FileSystem.deleteAsync(photo.uri, { idempotent: true });
  } catch {
    // A missing local file should not block draft cleanup.
  }
}

export async function clearEvidenceDraft(caseId: string): Promise<void> {
  const drafts = await readAllDrafts();
  const draft = drafts[caseId];
  if (draft) await Promise.all(draft.photos.map(deleteEvidencePhoto));
  delete drafts[caseId];
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(drafts));
}

