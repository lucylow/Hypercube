import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { Platform } from 'react-native';
import type { EvidenceDraft } from '@/lib/evidence-model';
import { formatEvidenceDraftSetCsv, formatEvidenceDraftSetExport, type EvidenceExportScope } from '@/shared/evidence-export';

export type EvidenceExportResult = 'shared' | 'downloaded' | 'unavailable';

async function exportContent(content: string, name: string, mimeType: string, title: string): Promise<EvidenceExportResult> {
  if (Platform.OS === 'web') {
    if (typeof document === 'undefined') return 'unavailable';
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return 'downloaded';
  }
  const uri = `${FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? ''}${name}`;
  if (!uri) return 'unavailable';
  await FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 });
  if (!(await Sharing.isAvailableAsync())) return 'unavailable';
  await Sharing.shareAsync(uri, { dialogTitle: title, mimeType });
  return 'shared';
}

export function exportEvidenceDraftsJson(drafts: EvidenceDraft[], scope: EvidenceExportScope): Promise<EvidenceExportResult> {
  return exportContent(formatEvidenceDraftSetExport(drafts, scope), `hypercube-${scope}-evidence-drafts-${new Date().toISOString().slice(0, 10)}.json`, 'application/json', 'Export evidence drafts');
}

export function exportEvidenceDraftsCsv(drafts: EvidenceDraft[], scope: EvidenceExportScope): Promise<EvidenceExportResult> {
  return exportContent(formatEvidenceDraftSetCsv(drafts), `hypercube-${scope}-evidence-drafts-${new Date().toISOString().slice(0, 10)}.csv`, 'text/csv', 'Export evidence draft CSV');
}
