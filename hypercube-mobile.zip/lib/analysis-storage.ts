import AsyncStorage from '@react-native-async-storage/async-storage';
import { appendAnalysisRecord, type AnalysisRecord } from '@/shared/ai-history';
import { removeAnalysisRecord } from '@/shared/library';

const STORAGE_KEY = '@hypercube/analysis-history/v1';

export async function readAnalysisHistory(): Promise<AnalysisRecord[]> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed as AnalysisRecord[] : [];
  } catch {
    return [];
  }
}

export async function saveAnalysisRecord(record: AnalysisRecord): Promise<void> {
  const history = await readAnalysisHistory();
  const next = appendAnalysisRecord(history, record);
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
}

export async function replaceAnalysisHistory(history: AnalysisRecord[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(history));
}

export async function deleteAnalysisRecord(recordId: string): Promise<void> {
  const history = await readAnalysisHistory();
  const next = removeAnalysisRecord(history, recordId);
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
}

export async function clearAnalysisHistory(): Promise<void> {
  await AsyncStorage.removeItem(STORAGE_KEY);
}
